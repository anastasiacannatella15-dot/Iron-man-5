package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitMark;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderArmEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Prima persona: la mano/braccio mostra il guanto della tuta (come in terza persona) e, quando spari il repulsore,
 * il braccio destro si alza.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID, value = Dist.CLIENT)
public final class FirstPersonArm {
    private static float raise;
    /** renderRightHand rilancia lo stesso evento: senza questa guardia si entra in un loop infinito (era il crash). */
    private static boolean rendering;

    private FirstPersonArm() {
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        float target = ClientState.isArmUp(mc.player.getId()) ? 1f : 0f;
        raise += (target - raise) * 0.35f;
    }

    @SubscribeEvent
    public static void onArm(RenderArmEvent e) {
        if (rendering) return;
        AbstractClientPlayer p = e.getPlayer();
        SuitMark mark = FlightRender.suitMark(p);
        if (mark == null) return;
        e.setCanceled(true);

        Minecraft mc = Minecraft.getInstance();
        PoseStack ps = e.getPoseStack();
        boolean right = e.getArm() == HumanoidArm.RIGHT;
        ps.pushPose();
        if (right && raise > 0.01f) {
            ps.mulPose(Axis.XP.rotationDegrees(-35f * raise)); // braccio destro alzato verso il bersaglio
            ps.translate(0.0f, 0.0f, -0.15f * raise);
        }
        PlayerRenderer pr = (PlayerRenderer) mc.getEntityRenderDispatcher().getRenderer(p);
        rendering = true;
        try {
            if (right) pr.renderRightHand(ps, e.getMultiBufferSource(), e.getPackedLight(), p);
            else pr.renderLeftHand(ps, e.getMultiBufferSource(), e.getPackedLight(), p);
        } finally {
            rendering = false;
        }

        // guanto/braccio dell'armatura sopra la pelle
        HumanoidModel<LivingEntity> model = SuitModels.get(mark, EquipmentSlot.CHEST);
        var arm = right ? model.rightArm : model.leftArm;
        arm.visible = true;
        arm.xRot = 0f;
        arm.yRot = 0f;
        arm.zRot = 0f;
        ResourceLocation tex = new ResourceLocation(IronManMod.MODID, "textures/models/armor/" + mark.id + "_model.png");
        arm.render(ps, e.getMultiBufferSource().getBuffer(RenderType.entityTranslucent(tex)), e.getPackedLight(), OverlayTexture.NO_OVERLAY);
        ps.popPose();
    }
}
