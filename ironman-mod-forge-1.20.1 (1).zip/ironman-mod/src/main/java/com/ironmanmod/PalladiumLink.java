package com.ironmanmod;

import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.fml.ModList;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Collega il Mjolnir a Palladium: le gemme inserite danno i poteri veri della mod Infinity di Pugmeowla
 * (infinity:power_stone, space_stone, ...) finche' tieni il martello in mano; quando lo lasci i poteri vengono tolti.
 * Usa il comando /superpower di Palladium (sintassi verificata sul suo codice).
 */
public final class PalladiumLink {
    private static final String KEY = "MjGranted";

    private PalladiumLink() {}

    public static boolean present() {
        return ModList.get().isLoaded("palladium");
    }

    private static boolean run(ServerPlayer p, String op, String id) {
        var server = p.getServer();
        if (server == null) return false;
        var src = p.createCommandSourceStack().withPermission(4).withSuppressedOutput();
        try {
            // sintassi verificata sul codice di Palladium 4.5.9: /superpower <add|remove> <potere> [entita']
            return server.getCommands().performPrefixedCommand(src, "superpower " + op + " " + id) > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** Allinea i poteri Palladium del giocatore alle gemme che ha in mano (lista vuota = togli tutto). */
    public static void sync(ServerPlayer p, List<String> gems) {
        if (!present()) return;
        var data = p.getPersistentData();
        Set<String> have = new HashSet<>();
        ListTag cur = data.getList(KEY, 8);
        for (int i = 0; i < cur.size(); i++) have.add(cur.getString(i));
        Set<String> want = new HashSet<>(gems);
        if (have.equals(want)) return;
        List<String> now = new ArrayList<>(have);
        for (String g : want) {
            if (!have.contains(g) && run(p, "add", MjolnirGems.MOD + ":" + g + "_stone")) now.add(g);
        }
        for (String g : have) {
            if (!want.contains(g)) {
                run(p, "remove", MjolnirGems.MOD + ":" + g + "_stone");
                now.remove(g);
            }
        }
        ListTag out = new ListTag();
        for (String g : now) out.add(StringTag.valueOf(g));
        data.put(KEY, out);
    }
}
