package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * La valigetta della Mark 5 (Iron Man 2): l'unico modo per avere la Mark 5. Clic destro: la valigetta viene posata a terra davanti a te
 * (vedi BriefcaseEntity), si apre e l'armatura ti si monta addosso pezzo per pezzo. Shift + clic destro con la valigetta vuota
 * mentre porti la Mark 5: l'armatura rientra nella valigetta.
 */
public class BriefcaseItem extends Item {
    public static final EquipmentSlot[] SLOTS = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
    public static final ArmorItem.Type[] TYPES = {ArmorItem.Type.BOOTS, ArmorItem.Type.LEGGINGS, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.HELMET};

    public BriefcaseItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
    }

    public static boolean isEmptyCase(ItemStack s) {
        return s.getTag() != null && s.getTag().getBoolean("Empty");
    }

    /** Il pezzo arriva addosso: quello che indossavi finisce nell'inventario. */
    public static void equip(ServerPlayer p, int i) {
        EquipmentSlot s = SLOTS[i];
        ItemStack old = p.getItemBySlot(s);
        if (!old.isEmpty() && !p.getInventory().add(old.copy())) p.drop(old.copy(), false);
        p.setItemSlot(s, new ItemStack(IronManMod.ARMOR.get(SuitMark.MARK_5).get(TYPES[i]).get()));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (level.isClientSide || !(p instanceof ServerPlayer sp)) return InteractionResultHolder.success(st);
        if (BriefcaseEntity.busy(sp)) return InteractionResultHolder.fail(st);
        boolean wearing = SuitData.classicSet(sp) == SuitMark.MARK_5;
        if (sp.isShiftKeyDown()) {
            if (!isEmptyCase(st)) {
                SuitData.msg(sp, "msg.ironmanmod.bc_full");
            } else if (!wearing) {
                SuitData.msg(sp, "msg.ironmanmod.bc_nosuit");
            } else {
                for (EquipmentSlot s : SLOTS) sp.setItemSlot(s, ItemStack.EMPTY); // l'armatura rientra nella valigetta
                st.getOrCreateTag().remove("Empty");
                ServerLevel sl = sp.serverLevel();
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 1, sp.getZ(), 60, 0.5, 0.9, 0.5, 0.3);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 0.7f);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PISTON_CONTRACT, SoundSource.PLAYERS, 1.0f, 1.2f);
                SuitData.msg(sp, "msg.ironmanmod.bc_off");
            }
            return InteractionResultHolder.success(st);
        }
        if (isEmptyCase(st)) {
            SuitData.msg(sp, "msg.ironmanmod.bc_empty");
            return InteractionResultHolder.fail(st);
        }
        if (wearing) {
            SuitData.msg(sp, "msg.ironmanmod.bc_already");
            return InteractionResultHolder.fail(st);
        }
        ItemStack held = st.copy();
        held.getOrCreateTag().putBoolean("Empty", true); // tornera' vuota: l'armatura e' addosso a te
        sp.setItemInHand(hand, ItemStack.EMPTY);
        BriefcaseEntity.place(sp, held);
        return InteractionResultHolder.success(ItemStack.EMPTY);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable(isEmptyCase(stack) ? "tooltip.ironmanmod.bc_empty" : "tooltip.ironmanmod.bc_full")
                .withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
