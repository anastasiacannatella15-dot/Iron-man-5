package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = IronManMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModBus {
    private static final String CAT = "key.categories.ironmanmod";

    public static final KeyMapping TRANSFORM = new KeyMapping("key.ironmanmod.transform", InputConstants.KEY_G, CAT);
    public static final KeyMapping REPULSOR = new KeyMapping("key.ironmanmod.repulsor", InputConstants.KEY_R, CAT);
    public static final KeyMapping UNIBEAM = new KeyMapping("key.ironmanmod.unibeam", InputConstants.KEY_V, CAT);
    public static final KeyMapping MISSILES = new KeyMapping("key.ironmanmod.missiles", InputConstants.KEY_B, CAT);

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(TRANSFORM);
        e.register(REPULSOR);
        e.register(UNIBEAM);
        e.register(MISSILES);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("ironman_hud", ClientHud::render);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        for (com.ironmanmod.SuitMark m : com.ironmanmod.SuitMark.values()) {
            for (net.minecraft.world.entity.EquipmentSlot s : SuitModels.SLOTS) {
                e.registerLayerDefinition(SuitModels.loc(m, s), () -> SuitModels.create(m, s));
            }
        }
    }
}
