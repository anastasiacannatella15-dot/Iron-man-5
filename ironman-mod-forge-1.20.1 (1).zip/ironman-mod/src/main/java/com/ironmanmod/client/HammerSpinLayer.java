package com.ironmanmod.client;

import com.ironmanmod.MjolnirItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * In terza persona (e per gli altri giocatori) il martello/Stormbreaker che gira si vede ruotare nella mano, come Thor.
 * L'oggetto "normale" in mano e' reso invisibile dal modello mentre si usa (vedi la proprieta' "spinning").
 */
public class HammerSpinLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public HammerSpinLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!p.isUsingItem()) return;
        ItemStack st = p.getUseItem();
        if (!(st.getItem() instanceof MjolnirItem)) return;
        HumanoidArm arm = p.getUsedItemHand() == InteractionHand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();
        boolean left = arm == HumanoidArm.LEFT;
        ps.pushPose();
        getParentModel().translateToHand(arm, ps);
        ps.mulPose(Axis.XP.rotationDegrees(-90f));
        ps.mulPose(Axis.YP.rotationDegrees(180f));
        ps.translate((left ? -1 : 1) / 16.0f, 0.125f, -0.625f);
        // se e' in aria (volo) il martello va avanti, nella direzione in cui punti, e il giocatore lo segue
        if (!p.onGround()) ps.translate(0f, 0.7f, 0f);
        ps.mulPose(Axis.XP.rotationDegrees((p.tickCount + partialTick) * 48f)); // la testa gira attorno alla mano
        ps.translate(0f, -0.2f, 0f);
        Minecraft.getInstance().getItemRenderer().renderStatic(st, ItemDisplayContext.FIXED, light,
                OverlayTexture.NO_OVERLAY, ps, buf, p.level(), p.getId());
        ps.popPose();
    }
}
