package com.ironmanmod.client;

import com.ironmanmod.SuitMark;
import com.ironmanmod.net.Net;
import net.minecraft.client.Minecraft;

import java.util.HashMap;
import java.util.Map;

/** Copia lato client dello stato dell'armatura (arriva dal server ogni mezzo secondo). */
public final class ClientState {
    public static int active;
    public static int selected = 42;
    public static int phase;
    public static int t;
    public static int dur = 60;
    public static int energy;
    public static int maxEnergy = 1;
    public static int owned;
    /** entityId -> tick di gioco fino a cui il braccio destro resta alzato. */
    private static final Map<Integer, Long> ARM = new HashMap<>();

    private ClientState() {
    }

    public static void apply(Net.SyncPacket p) {
        active = p.active;
        selected = p.selected;
        phase = p.phase;
        t = p.t;
        dur = Math.max(1, p.dur);
        energy = p.energy;
        maxEnergy = Math.max(1, p.maxEnergy);
        owned = p.owned;
    }

    public static void armUp(int entityId, int ticks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) ARM.put(entityId, mc.level.getGameTime() + ticks);
    }

    public static boolean isArmUp(int entityId) {
        Long until = ARM.get(entityId);
        Minecraft mc = Minecraft.getInstance();
        if (until == null || mc.level == null) return false;
        if (mc.level.getGameTime() > until) {
            ARM.remove(entityId);
            return false;
        }
        return true;
    }

    public static SuitMark activeMark() {
        return phase == 0 && active > 0 ? SuitMark.byNumber(active) : null;
    }
}
