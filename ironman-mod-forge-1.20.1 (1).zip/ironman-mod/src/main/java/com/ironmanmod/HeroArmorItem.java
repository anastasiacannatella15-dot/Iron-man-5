package com.ironmanmod;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import java.util.function.Consumer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

/** Pezzo di armatura normale (Mark 42): si craftta, si indossa a mano, ha durabilita' e si ripara. */
public class HeroArmorItem extends ArmorItem {
    public final SuitMark mark;

    public HeroArmorItem(SuitMark mark, ArmorItem.Type type) {
        super(mark, type, new Item.Properties().rarity(Rarity.RARE));
        this.mark = mark;
    }

    @Override
    public String getArmorTexture(ItemStack stack, net.minecraft.world.entity.Entity entity, net.minecraft.world.entity.EquipmentSlot slot, String type) {
        return "ironmanmod:textures/models/armor/" + mark.id + "_model.png";
    }

    @Override
    public void initializeClient(Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer) {
        consumer.accept(new net.minecraftforge.client.extensions.common.IClientItemExtensions() {
            @Override
            public net.minecraft.client.model.HumanoidModel<?> getHumanoidArmorModel(LivingEntity e, ItemStack st,
                    net.minecraft.world.entity.EquipmentSlot slot, net.minecraft.client.model.HumanoidModel<?> original) {
                return com.ironmanmod.client.SuitModels.get(mark, slot);
            }
        });
    }
}
