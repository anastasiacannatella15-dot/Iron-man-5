package com.ironmanmod;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Mjolnir: tieni premuto il tasto destro per farlo girare, salta per volare. Maiusc + clic destro lo lega a te.
 * Poteri (tasti): lancia, richiama, fulmine, tempesta di fulmini. A terra resta in piedi e si prende con il tasto destro.
 */
public class MjolnirItem extends Item {
    public MjolnirItem() {
        this(new Item.Properties().stacksTo(1).durability(10).rarity(Rarity.EPIC).fireResistant()); // 10 = secondi di raggio del Potere prima che si spezzi
    }

    protected MjolnirItem(Item.Properties props) {
        super(props);
    }

    public static UUID owner(ItemStack s) {
        var t = s.getTag();
        return t != null && t.hasUUID("Owner") ? t.getUUID("Owner") : null;
    }

    public static String ownerName(ItemStack s) {
        var t = s.getTag();
        return t != null && t.contains("OwnerName") ? t.getString("OwnerName") : "?";
    }

    /** Puo' usarlo / prenderlo chi e' il proprietario, o chiunque se non e' legato. */
    public static boolean worthy(ItemStack s, Player p) {
        UUID o = owner(s);
        return o == null || o.equals(p.getUUID()) || p.isCreative();
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (!worthy(st, p)) {
            if (!level.isClientSide) p.displayClientMessage(Component.translatable("msg.ironmanmod.mj_unworthy", ownerName(st)), true);
            return InteractionResultHolder.fail(st);
        }
        if (p.isShiftKeyDown()) {
            // 1) una Gemma dell'Infinito (mano secondaria o inventario) viene incastonata nel martello
            ItemStack gem = ItemStack.EMPTY;
            String stone = null;
            if (MjolnirGems.stoneOf(p.getOffhandItem()) != null && !MjolnirGems.has(st, MjolnirGems.stoneOf(p.getOffhandItem()))) {
                gem = p.getOffhandItem();
                stone = MjolnirGems.stoneOf(gem);
            } else {
                for (ItemStack it : p.getInventory().items) {
                    String n = MjolnirGems.stoneOf(it);
                    if (n != null && !MjolnirGems.has(st, n)) {
                        gem = it;
                        stone = n;
                        break;
                    }
                }
            }
            if (stone != null) {
                if (!level.isClientSide) {
                    MjolnirGems.add(st, stone);
                    if (level instanceof net.minecraft.server.level.ServerLevel sl) MjolnirGems.onInsert(sl, p, stone, st);
                    if (!p.isCreative()) gem.shrink(1);
                    p.displayClientMessage(Component.translatable("msg.ironmanmod.mj_gem_in", Component.translatable("item.infinity." + stone + "_stone")), true);
                    level.playSound(null, p.getX(), p.getY(), p.getZ(), net.minecraft.sounds.SoundEvents.BEACON_POWER_SELECT, net.minecraft.sounds.SoundSource.PLAYERS, 1.0f, 1.6f);
                }
                return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
            }
            // 2) con il martello che ha gemme, la mano secondaria vuota e il nome gia' messo: l'ultima gemma esce
            if (owner(st) != null && p.getOffhandItem().isEmpty() && !MjolnirGems.list(st).isEmpty()) {
                if (!level.isClientSide) {
                    ItemStack out = MjolnirGems.removeLast(st);
                    if (!out.isEmpty() && !p.getInventory().add(out)) p.drop(out, false);
                    p.displayClientMessage(Component.translatable("msg.ironmanmod.mj_gem_out"), true);
                }
                return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
            }
            // 3) altrimenti: il tuo nome sotto il nome del martello
            if (!level.isClientSide) {
                st.getOrCreateTag().putUUID("Owner", p.getUUID());
                st.getOrCreateTag().putString("OwnerName", p.getGameProfile().getName());
                p.displayClientMessage(Component.translatable("msg.ironmanmod.mj_bound", p.getGameProfile().getName()), true);
            }
            return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
        }
        p.startUsingItem(hand);
        return InteractionResultHolder.consume(st);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.CUSTOM;
    }

    @Override
    public void onUseTick(Level level, LivingEntity e, ItemStack stack, int remaining) {
        if (level.isClientSide || !(e instanceof Player p)) return;
        p.fallDistance = 0f; // girando e volando niente danni da caduta
        p.getPersistentData().putLong("mj_nofall", level.getGameTime() + 100);
        if (level instanceof ServerLevel sl && p.tickCount % 2 == 0) {
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.2, p.getZ(), 4, 0.6, 0.6, 0.6, 0.1);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        UUID o = owner(stack);
        if (o != null) tip.add(Component.translatable("tooltip.ironmanmod.mj_owner", ownerName(stack)).withStyle(net.minecraft.ChatFormatting.GOLD, net.minecraft.ChatFormatting.ITALIC));
        else tip.add(Component.translatable("tooltip.ironmanmod.mj_unbound").withStyle(net.minecraft.ChatFormatting.GRAY));
        tip.add(Component.translatable("tooltip.ironmanmod.mj_dmg", (int) MjolnirGems.strike(stack, false), (int) MjolnirGems.strike(stack, true)).withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
        var gl = MjolnirGems.list(stack);
        if (!gl.isEmpty()) {
            var names = Component.empty();
            for (int i = 0; i < gl.size(); i++) {
                if (i > 0) names.append(", ");
                names.append(Component.translatable("item.infinity." + gl.get(i) + "_stone"));
            }
            tip.add(Component.translatable("tooltip.ironmanmod.mj_gems", names).withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE));
        }
        if (stack.getTag() != null && stack.getTag().getBoolean("Locked")) tip.add(Component.translatable("msg.ironmanmod.mj_locked_tip").withStyle(net.minecraft.ChatFormatting.RED));
        tip.add(Component.translatable("tooltip.ironmanmod.mj_hint").withStyle(net.minecraft.ChatFormatting.DARK_AQUA));
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot != EquipmentSlot.MAINHAND) return super.getDefaultAttributeModifiers(slot);
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier", 11.0, AttributeModifier.Operation.ADDITION));
        b.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier", -2.9, AttributeModifier.Operation.ADDITION));
        return b.build();
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public HumanoidModel.ArmPose getArmPose(LivingEntity e, InteractionHand hand, ItemStack stack) {
                return e.isUsingItem() && e.getUsedItemHand() == hand ? HumanoidModel.ArmPose.THROW_SPEAR : null;
            }

            @Override
            public boolean applyForgeHandTransform(PoseStack ps, LocalPlayer p, HumanoidArm arm, ItemStack stack,
                                                   float partialTick, float equipProcess, float swingProcess) {
                if (!p.isUsingItem()) return false;
                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                // come Thor: il manico resta nella mano e la testa del martello gira in cerchio attorno al polso
                ps.translate(side * 0.45f, -0.55f, -0.75f);
                ps.mulPose(Axis.XP.rotationDegrees((p.tickCount + partialTick) * 48f));
                ps.translate(0f, 0.38f, 0f);
                return true;
            }
        });
    }
}
