package com.ironmanmod;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.ModList;

import java.lang.reflect.Method;
import java.util.Optional;
import java.util.function.Predicate;

/** Trova il Mark 50 / 85 indossato: nello slot del petto oppure in Curios (slot "body"). Curios e' opzionale. */
public final class ReactorLookup {
    private static boolean tried;
    private static Method getInventory;   // CuriosApi.getCuriosInventory(LivingEntity)
    private static Method findFirst;      // ICuriosItemHandler.findFirstCurio(Predicate)
    private static Method stack;          // SlotResult.stack()
    private static Method getHelper;      // vecchie versioni: CuriosApi.getCuriosHelper()
    private static Method helperFind;     // CuriosHelper.findFirstCurio(LivingEntity, Predicate)

    private ReactorLookup() {
    }

    public static ReactorItem find(LivingEntity e) {
        ItemStack chest = e.getItemBySlot(EquipmentSlot.CHEST);
        if (chest.getItem() instanceof ReactorItem ri) return ri;
        ItemStack c = curios(e);
        return c.getItem() instanceof ReactorItem ri ? ri : null;
    }

    public static SuitMark mark(LivingEntity e) {
        ReactorItem r = find(e);
        return r == null ? null : r.mark;
    }

    private static ItemStack curios(LivingEntity e) {
        if (!ModList.get().isLoaded("curios")) return ItemStack.EMPTY;
        try {
            init();
            Predicate<ItemStack> pred = s -> s.getItem() instanceof ReactorItem;
            Object handler = null;
            Object result = null;
            if (getInventory != null) {
                Object inv = getInventory.invoke(null, e);
                // Forge 1.20.1: LazyOptional; altre versioni: Optional
                if (inv instanceof net.minecraftforge.common.util.LazyOptional<?> lo) handler = lo.resolve().orElse(null);
                else if (inv instanceof Optional<?> op) handler = op.orElse(null);
                if (handler != null) {
                    result = ((Optional<?>) findFirst.invoke(handler, pred)).orElse(null);
                    if (result == null) {
                        // alternativa: scorri tutti gli slot Curios
                        Object eq = handler.getClass().getMethod("getEquippedCurios").invoke(handler);
                        if (eq instanceof net.minecraftforge.items.IItemHandler ih) {
                            for (int i = 0; i < ih.getSlots(); i++) if (pred.test(ih.getStackInSlot(i))) return ih.getStackInSlot(i);
                        }
                    }
                }
            } else if (getHelper != null) {
                Object helper = getHelper.invoke(null);
                result = ((Optional<?>) helperFind.invoke(helper, e, pred)).orElse(null);
            }
            if (result != null) return (ItemStack) stack.invoke(result);
        } catch (Throwable ignored) {
            // Curios in una versione diversa: niente supporto, ma niente crash
        }
        return ItemStack.EMPTY;
    }

    private static void init() {
        if (tried) return;
        tried = true;
        try {
            Class<?> api = Class.forName("top.theillusivec4.curios.api.CuriosApi");
            stack = Class.forName("top.theillusivec4.curios.api.SlotResult").getMethod("stack");
            try {
                getInventory = api.getMethod("getCuriosInventory", LivingEntity.class);
                findFirst = Class.forName("top.theillusivec4.curios.api.type.capability.ICuriosItemHandler")
                        .getMethod("findFirstCurio", Predicate.class);
            } catch (ReflectiveOperationException ex) {
                getInventory = null;
                getHelper = api.getMethod("getCuriosHelper");
                helperFind = Class.forName("top.theillusivec4.curios.api.type.capability.ICuriosHelper")
                        .getMethod("findFirstCurio", LivingEntity.class, Predicate.class);
            }
        } catch (Throwable t) {
            getInventory = null;
            getHelper = null;
        }
    }
}
