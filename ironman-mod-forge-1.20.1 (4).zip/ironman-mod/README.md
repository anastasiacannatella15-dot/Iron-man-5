# Iron Man 1.7.0 — Mark 42 / Mark 50 / Mark 85

Minecraft **1.20.1** · Forge **47.3.0** · Java **17**

La versione si cambia in `gradle.properties` (`mod_version`): il .jar si chiama `iron-man-<versione>.jar`.

## Come ottenere il .jar

**Metodo consigliato (con il wrapper Gradle ufficiale):**
1. Scarica il "Mdk" di Forge 1.20.1 (47.3.0) da https://files.minecraftforge.net e scompattalo.
2. Copia dentro la sua cartella il mio `src/` e il mio `build.gradle` (sovrascrivi quelli dell'MDK).
3. Apri un terminale nella cartella ed esegui:
   - Windows: `gradlew build`
   - Linux/Mac: `./gradlew build`
4. Il file finito è in `build/libs/iron-man-1.7.0.jar` → mettilo nella cartella `mods` di Minecraft.

**Alternativa:** con JDK 17 e Gradle 8.1.x installati, esegui `gradle build` direttamente in questa cartella.

## Modello 3D
Le armature usano un vero modello 3D (spalline, pettorali, ginocchiere, stivali, casco con mento e orecchie che sporgono dal corpo), senza librerie extra. Texture in `textures/models/armor/markXX_model.png`.

## Come si gioca

**Mark 42 — armatura normale, senza nanotech.** Si craftta pezzo per pezzo (diamanti + oro, stessa forma dell'armatura di diamante)
e si indossa a mano. Con tutti e 4 i pezzi addosso hai volo, repulsori e missili. Ha 20 punti armor, tenacia 2,5 e il 10% di danno in meno:
un po' meglio del diamante.

**Mark 50 e Mark 85 — nanotech.** Servono gli item **Mark 50** / **Mark 85** (hanno l'icona del reattore Arc della tuta),
da **indossare nello slot del petto** oppure in **Curios (slot body)**. Il bottone di trasformazione compare in alto a sinistra solo quando lo indossi.
- Mark 50: diamanti + oro + stella del Nether al centro (`DGD / GRG / DGD`)
- Mark 85: lingotti di netherite + stelle del Nether + blocchi di diamante + Mark 50 al centro (`NSN / DRD / NSN`)
- Trasformazione in stile Infinity War: le nanoparticelle partono dal petto e corrono fino a mani, piedi e testa (0,5 secondi, la tuta compare tutta insieme).

**Tasti** (modificabili in Opzioni → Controlli → Iron Man):

| Tasto | Azione |
|-------|--------|
| **G** | Trasformati / rimuovi l'armatura (0,5 secondi) |
| **R** | Repulsore: braccio destro alzato, raggio giallo di 1,5 s (tienilo premuto per continuare a sparare) |
| **V** | Unibeam dal petto, dura 1,5 s (solo Mark 50 e 85, non la 42) |
| **B** | Micro-missili di fuoco (4 / 6 / 8 bersagli) |

**Volo**: doppio salto per volare. Vai avanti e il corpo si inclina come nei film, con i repulsori accesi nelle gambe. Tieni **Sprint + W** mentre voli per il volo supersonico. L'energia si consuma volando e sparando e si ricarica a terra.

## Protezione e danno

| | Mark 42 | Mark 50 | Mark 85 |
|---|---|---|---|
| Armor (casco/petto/gambali/stivali) | 3/8/6/3 = 20 | 2/6/5/2 = 15 | 3/8/6/3 = 20 |
| Tenacia (per pezzo) | 2,5 | 5 | 6 |
| Resistenza al knockback (totale) | 0 | 2 | 2 |
| Danno subito (extra) | -10% | normale | -75% (circa il doppio della netherite con Protezione IV) |
| Repulsore (fuoco) | 10 | 13 | 16 |
| Unibeam (totale in 1,5 s) | no | 30 | 40 |
| Micro-missili | 4 | 6 | 8 |

I raggi danno fuoco. Nota: in Minecraft diamante e netherite hanno entrambi 20 punti armor,
le differenze tra i modelli vengono quindi da tenacia e riduzione del danno.

## Mjölnir (martello)
Ricetta: 5 lingotti di netherite, 1 stella del Nether, 1 blaze rod (`NNN / NSN / .R.`).
- **Tieni premuto il tasto destro**: il martello gira. **Salta** mentre tieni premuto e voli nella direzione in cui guardi (Sprint per andare piu' veloce). Niente danni da caduta.
- **Maiusc + tasto destro**: lo leghi a te, il tuo nome compare sotto il nome del martello. Solo tu puoi usarlo e sollevarlo.
- **Se lo droppi** resta in piedi a terra. Passandoci sopra non lo prendi: devi fare **tasto destro** sopra di lui.
- **Z** lancia · **X** richiama (torna da solo nel tuo inventario, anche attraverso i blocchi) · **C** fulmine dove guardi · **H** tempesta di fulmini tutto intorno a te.
- Sei immune ai suoi fulmini. Danno in mischia 14, lancio 16, fulmine 14 piu' fuoco.

## Morte
Se muori senza keepInventory, l'armatura nanotech sparisce e droppa la tua armatura originale.

## Uru, meteorite e Matrice del Mjölnir (1.7.0)
- **Meteorite**: struttura nel mondo normale (circa 1 chunk su 50, sulla superficie): cratere bruciato con una roccia scura che ha un cuore di **Blocchi di Uru**. Appare solo nei chunk NUOVI (esplora terreno mai visitato). Il blocco di Uru si rompe con piccone di diamante/netherite.
- **Matrice del Mjölnir** (`mjolnir_cast`): si trova nelle casse del **fabbro (weaponsmith) dei villaggi** (50% di probabilità).
- **Con Tinkers' Construct**: fondi Uru (lingotti/blocchi) nella fonderia, poi versa **3 secchi (3000 mB) di Uru fuso** sul tavolo di colata con la Matrice → ottieni il **Mjölnir**.
- **Senza Tinkers**: ricetta a banco `uru_block ×5 + matrice + blaze rod`.
- Nota: le ricette Tinkers sono scritte a memoria e non testate; se non funzionano mandami il `latest.log`.

## 1.7.0 — Spider, Iron Man (sentinella), FRIDAY/JARVIS
- **Texture armature**: Mark 50, Mark 85 e Iron Man usano le tue skin 64x64 (`textures/models/armor/*_model.png`, layout skin base). Per cambiarle sostituisci i PNG.
- **Armatura "Iron Man"** (ex Mark 42, classica rosso/oro, craft con lingotti di **titanio**): con tutti e 4 i pezzi hai volo/repulsore/missili e **JARVIS**.
- **Sentinella** (tasto J con l'armatura Iron Man completa): l'armatura esce da te, ti segue e spara ai mostri, 50 di vita; se muore droppa i pezzi. **Tasto destro** = si apre la schiena; **cammina verso di lei** e la indossi.
- **FRIDAY** (Mark 50/85) / **JARVIS** (Iron Man): schermata HUD in prima persona. **Shift+V** accende/spegne; **Shift+F** scansione dei mob; tenendo **Shift** i tasti in alto a sinistra si nascondono.
- **Tuta Ragno** (design originale, 4 pezzi in cuoio+cordicelle) e **Web Shooter** (indossalo nello slot **charm** di Curios): fluido 0/5000 mB, +50 mB per cordicella nel banco di lavoro (Web Shooter + cordicelle). **N** (tieni premuto, guardando un punto alto) = ti dondoli/vieni tirato verso il punto; **M** = spara una ragnatela che fa danno e rallenta.
- **Titanio**: Titanio Grezzo si trova nei meteoriti insieme all'Uru (si fonde in lingotti).
- **Trasformazione**: onda + spirale di nanoparticelle dal reattore; in prima persona il braccio scende verso il reattore, in terza persona la mano va al petto.
