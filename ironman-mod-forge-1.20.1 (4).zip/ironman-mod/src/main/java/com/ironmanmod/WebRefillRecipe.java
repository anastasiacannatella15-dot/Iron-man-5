package com.ironmanmod;

import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

/** Web Shooter + cordicelle nel banco di lavoro = +50 mB di fluido ragnatela per cordicella. */
public class WebRefillRecipe extends CustomRecipe {
    public WebRefillRecipe(ResourceLocation id, CraftingBookCategory cat) {
        super(id, cat);
    }

    @Override
    public boolean matches(CraftingContainer c, Level l) {
        int shooters = 0, strings = 0;
        for (int i = 0; i < c.getContainerSize(); i++) {
            ItemStack s = c.getItem(i);
            if (s.isEmpty()) continue;
            if (s.getItem() instanceof WebShooterItem) shooters++;
            else if (s.is(Items.STRING)) strings++;
            else return false;
        }
        return shooters == 1 && strings >= 1;
    }

    @Override
    public ItemStack assemble(CraftingContainer c, RegistryAccess access) {
        ItemStack out = ItemStack.EMPTY;
        int strings = 0;
        for (int i = 0; i < c.getContainerSize(); i++) {
            ItemStack s = c.getItem(i);
            if (s.getItem() instanceof WebShooterItem) out = s.copy();
            else if (s.is(Items.STRING)) strings++;
        }
        if (out.isEmpty()) return ItemStack.EMPTY;
        out.setCount(1);
        WebShooterItem.setFluid(out, WebShooterItem.fluid(out) + strings * WebShooterItem.PER_STRING);
        return out;
    }

    @Override
    public boolean canCraftInDimensions(int w, int h) {
        return w * h >= 2;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModContent.WEB_REFILL.get();
    }
}
