package com.ironmanmod;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;

import java.util.function.Consumer;

/** Pezzo della tuta ragno (armatura normale). */
public class SpiderArmorItem extends ArmorItem {
    public SpiderArmorItem(ArmorItem.Type type) {
        super(SpiderMaterial.WEB, type, new Item.Properties().rarity(Rarity.RARE));
    }

    @Override
    public String getArmorTexture(ItemStack stack, net.minecraft.world.entity.Entity entity, net.minecraft.world.entity.EquipmentSlot slot, String type) {
        return "ironmanmod:textures/models/armor/spider_model.png";
    }

    @Override
    public void initializeClient(Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer) {
        consumer.accept(new net.minecraftforge.client.extensions.common.IClientItemExtensions() {
            @Override
            public net.minecraft.client.model.HumanoidModel<?> getHumanoidArmorModel(LivingEntity e, ItemStack st,
                    net.minecraft.world.entity.EquipmentSlot slot, net.minecraft.client.model.HumanoidModel<?> original) {
                return com.ironmanmod.client.SuitModels.get("spider", slot);
            }
        });
    }
}
