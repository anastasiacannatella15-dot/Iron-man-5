package com.ironmanmod;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;

import java.util.List;

/** Lancia-ragnatele: contiene fluido ragnatela (0..5000 mB). Si indossa nello slot charm di Curios. */
public class WebShooterItem extends Item {
    public static final int MAX = 5000;
    public static final int PER_STRING = 50;

    public WebShooterItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
    }

    public static int fluid(ItemStack s) {
        CompoundTag t = s.getTag();
        return t == null ? 0 : Math.max(0, Math.min(MAX, t.getInt("web")));
    }

    public static void setFluid(ItemStack s, int v) {
        s.getOrCreateTag().putInt("web", Math.max(0, Math.min(MAX, v)));
    }

    @Override
    public void appendHoverText(ItemStack s, Level l, List<Component> tip, net.minecraft.world.item.TooltipFlag f) {
        tip.add(Component.translatable("tooltip.ironmanmod.web_fluid", fluid(s), MAX).withStyle(ChatFormatting.AQUA));
        tip.add(Component.translatable("tooltip.ironmanmod.web_hint").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public boolean isBarVisible(ItemStack s) {
        return true;
    }

    @Override
    public int getBarWidth(ItemStack s) {
        return Math.round(13.0f * fluid(s) / MAX);
    }

    @Override
    public int getBarColor(ItemStack s) {
        return 0xE8F4FF;
    }
}
