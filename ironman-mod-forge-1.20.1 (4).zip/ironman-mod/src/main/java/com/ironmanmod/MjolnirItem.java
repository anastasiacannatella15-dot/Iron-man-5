package com.ironmanmod;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Mjolnir: tieni premuto il tasto destro per farlo girare, salta per volare. Maiusc + clic destro lo lega a te.
 * Poteri (tasti): lancia, richiama, fulmine, tempesta di fulmini. A terra resta in piedi e si prende con il tasto destro.
 */
public class MjolnirItem extends Item {
    public MjolnirItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
    }

    public static UUID owner(ItemStack s) {
        var t = s.getTag();
        return t != null && t.hasUUID("Owner") ? t.getUUID("Owner") : null;
    }

    public static String ownerName(ItemStack s) {
        var t = s.getTag();
        return t != null && t.contains("OwnerName") ? t.getString("OwnerName") : "?";
    }

    /** Puo' usarlo / prenderlo chi e' il proprietario, o chiunque se non e' legato. */
    public static boolean worthy(ItemStack s, Player p) {
        UUID o = owner(s);
        return o == null || o.equals(p.getUUID()) || p.isCreative();
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (!worthy(st, p)) {
            if (!level.isClientSide) p.displayClientMessage(Component.translatable("msg.ironmanmod.mj_unworthy", ownerName(st)), true);
            return InteractionResultHolder.fail(st);
        }
        if (p.isShiftKeyDown()) { // il tuo nome sotto il nome del martello
            if (!level.isClientSide) {
                st.getOrCreateTag().putUUID("Owner", p.getUUID());
                st.getOrCreateTag().putString("OwnerName", p.getGameProfile().getName());
                p.displayClientMessage(Component.translatable("msg.ironmanmod.mj_bound", p.getGameProfile().getName()), true);
            }
            return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
        }
        p.startUsingItem(hand);
        return InteractionResultHolder.consume(st);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.CUSTOM;
    }

    @Override
    public void onUseTick(Level level, LivingEntity e, ItemStack stack, int remaining) {
        if (level.isClientSide || !(e instanceof Player p)) return;
        p.fallDistance = 0f; // girando e volando niente danni da caduta
        p.getPersistentData().putLong("mj_nofall", level.getGameTime() + 100);
        if (level instanceof ServerLevel sl && p.tickCount % 2 == 0) {
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.2, p.getZ(), 4, 0.6, 0.6, 0.6, 0.1);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        UUID o = owner(stack);
        if (o != null) tip.add(Component.translatable("tooltip.ironmanmod.mj_owner", ownerName(stack)).withStyle(net.minecraft.ChatFormatting.GOLD, net.minecraft.ChatFormatting.ITALIC));
        else tip.add(Component.translatable("tooltip.ironmanmod.mj_unbound").withStyle(net.minecraft.ChatFormatting.GRAY));
        tip.add(Component.translatable("tooltip.ironmanmod.mj_hint").withStyle(net.minecraft.ChatFormatting.DARK_AQUA));
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot != EquipmentSlot.MAINHAND) return super.getDefaultAttributeModifiers(slot);
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier", 13.0, AttributeModifier.Operation.ADDITION));
        b.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier", -2.9, AttributeModifier.Operation.ADDITION));
        return b.build();
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public HumanoidModel.ArmPose getArmPose(LivingEntity e, InteractionHand hand, ItemStack stack) {
                return e.isUsingItem() && e.getUsedItemHand() == hand ? HumanoidModel.ArmPose.THROW_SPEAR : null;
            }

            @Override
            public boolean applyForgeHandTransform(PoseStack ps, LocalPlayer p, HumanoidArm arm, ItemStack stack,
                                                   float partialTick, float equipProcess, float swingProcess) {
                if (!p.isUsingItem()) return false;
                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                ps.translate(side * 0.3f, -0.3f, -0.8f);
                ps.mulPose(Axis.YP.rotationDegrees((p.tickCount + partialTick) * 40f)); // il martello gira
                return true;
            }
        });
    }
}
