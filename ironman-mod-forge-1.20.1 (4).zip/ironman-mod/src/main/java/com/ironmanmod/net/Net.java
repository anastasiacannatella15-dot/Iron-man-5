package com.ironmanmod.net;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitData;
import com.ironmanmod.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class Net {
    public static final int A_TRANSFORM = 0;
    public static final int A_CYCLE = 1;
    public static final int A_REPULSOR = 2;
    public static final int A_UNIBEAM = 3;
    public static final int A_MISSILES = 4;
    public static final int A_WEB_ON = 20;
    public static final int A_WEB_OFF = 21;
    public static final int A_WEB_SHOT = 22;
    public static final int A_SENTINEL = 23;

    private static final String PROTOCOL = "2";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(IronManMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Net() {
    }

    public static void init() {
        int id = 0;
        CH.registerMessage(id++, ActionPacket.class, ActionPacket::encode, ActionPacket::decode, ActionPacket::handle);
        CH.registerMessage(id++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
        CH.registerMessage(id++, PosePacket.class, PosePacket::encode, PosePacket::decode, PosePacket::handle);
    }

    public static void sendAction(int action) {
        CH.sendToServer(new ActionPacket(action));
    }

    /** Dice a tutti i giocatori vicini che questo giocatore alza il braccio destro (sta sparando) per N tick. */
    public static void sendPose(ServerPlayer p, int ticks) {
        CH.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new PosePacket(p.getId(), ticks));
    }

    /** Client -> server: un tasto premuto. */
    public static class ActionPacket {
        public final int action;

        public ActionPacket(int action) {
            this.action = action;
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(action);
        }

        public static ActionPacket decode(FriendlyByteBuf buf) {
            return new ActionPacket(buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> {
                ServerPlayer sp = c.getSender();
                if (sp != null) SuitData.handleAction(sp, action);
            });
            c.setPacketHandled(true);
        }
    }

    /** Server -> client: stato dell'armatura per l'HUD. */
    public static class SyncPacket {
        public final int active, selected, phase, t, dur, energy, maxEnergy, owned;

        public SyncPacket(int active, int selected, int phase, int t, int dur, int energy, int maxEnergy, int owned) {
            this.active = active;
            this.selected = selected;
            this.phase = phase;
            this.t = t;
            this.dur = dur;
            this.energy = energy;
            this.maxEnergy = maxEnergy;
            this.owned = owned;
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(active);
            buf.writeVarInt(selected);
            buf.writeVarInt(phase);
            buf.writeVarInt(t);
            buf.writeVarInt(dur);
            buf.writeVarInt(energy);
            buf.writeVarInt(maxEnergy);
            buf.writeVarInt(owned);
        }

        public static SyncPacket decode(FriendlyByteBuf buf) {
            return new SyncPacket(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                    buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.apply(this)));
            c.setPacketHandled(true);
        }
    }

    /** Server -> client: animazione del braccio destro alzato (repulsore). */
    public static class PosePacket {
        public final int entityId, ticks;

        public PosePacket(int entityId, int ticks) {
            this.entityId = entityId;
            this.ticks = ticks;
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(entityId);
            buf.writeVarInt(ticks);
        }

        public static PosePacket decode(FriendlyByteBuf buf) {
            return new PosePacket(buf.readVarInt(), buf.readVarInt());
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.armUp(entityId, ticks)));
            c.setPacketHandled(true);
        }
    }
}
