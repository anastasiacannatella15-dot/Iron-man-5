package com.ironmanmod;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;

/** Materiale della tuta ragno: leggera, come il ferro ma agile. */
public enum SpiderMaterial implements ArmorMaterial {
    WEB;

    @Override
    public int getDurabilityForType(ArmorItem.Type t) {
        return switch (t) {
            case BOOTS -> 13 * 25;
            case LEGGINGS -> 15 * 25;
            case CHESTPLATE -> 16 * 25;
            case HELMET -> 11 * 25;
        };
    }

    @Override
    public int getDefenseForType(ArmorItem.Type t) {
        return switch (t) {
            case BOOTS -> 2;
            case LEGGINGS -> 5;
            case CHESTPLATE -> 6;
            case HELMET -> 2;
        };
    }

    @Override
    public int getEnchantmentValue() {
        return 15;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_LEATHER;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(Items.LEATHER);
    }

    @Override
    public String getName() {
        return IronManMod.MODID + ":spider";
    }

    @Override
    public float getToughness() {
        return 1.0f;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.0f;
    }
}
