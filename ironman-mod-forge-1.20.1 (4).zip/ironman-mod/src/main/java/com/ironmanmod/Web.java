package com.ironmanmod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Poteri ragnatela: dondolarsi (tieni premuto) e sparare ragnatele che fanno danno e rallentano. */
public final class Web {
    private static final DustParticleOptions WHITE = new DustParticleOptions(new Vector3f(0.96f, 0.97f, 1.0f), 0.7f);
    private static final DustParticleOptions SHOT = new DustParticleOptions(new Vector3f(0.9f, 0.93f, 1.0f), 1.1f);
    private static final int SWING_COST = 25;
    private static final int SHOT_COST = 10;
    private static final double RANGE = 70.0;

    private record Anchor(Vec3 pos, double len) {
    }

    private static final Map<UUID, Anchor> ANCHORS = new HashMap<>();

    private Web() {
    }

    /** Il Web Shooter nello slot charm di Curios; senza Curios va bene anche nella mano secondaria. */
    public static ItemStack shooter(Player p) {
        ItemStack s = ReactorLookup.curios(p, x -> x.getItem() instanceof WebShooterItem);
        if (!s.isEmpty()) return s;
        if (p.getOffhandItem().getItem() instanceof WebShooterItem) return p.getOffhandItem();
        return ItemStack.EMPTY;
    }

    public static boolean fullSuit(Player p) {
        return p.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof SpiderArmorItem
                && p.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof SpiderArmorItem
                && p.getItemBySlot(EquipmentSlot.LEGS).getItem() instanceof SpiderArmorItem
                && p.getItemBySlot(EquipmentSlot.FEET).getItem() instanceof SpiderArmorItem;
    }

    private static boolean take(ServerPlayer p, ItemStack s, int mb) {
        if (p.isCreative()) return true;
        int f = WebShooterItem.fluid(s);
        if (f < mb) {
            SuitData.msg(p, "msg.ironmanmod.no_web");
            return false;
        }
        WebShooterItem.setFluid(s, f - mb);
        return true;
    }

    // ---------------------------------------------------------------- dondolo

    public static void swingStart(ServerPlayer p) {
        ItemStack s = shooter(p);
        if (s.isEmpty()) {
            SuitData.msg(p, "msg.ironmanmod.no_shooter");
            return;
        }
        Vec3 eye = p.getEyePosition();
        Vec3 end = eye.add(p.getLookAngle().scale(RANGE));
        BlockHitResult bh = p.level().clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (bh.getType() == HitResult.Type.MISS) {
            SuitData.msg(p, "msg.ironmanmod.no_anchor");
            return;
        }
        if (!take(p, s, SWING_COST)) return;
        Vec3 a = bh.getLocation();
        ANCHORS.put(p.getUUID(), new Anchor(a, Math.max(4.0, a.distanceTo(eye))));
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 1.0f, 1.6f);
    }

    public static void swingStop(ServerPlayer p) {
        ANCHORS.remove(p.getUUID());
    }

    /** Ogni tick del giocatore: tira verso il punto di attacco e disegna il filo. */
    public static void tick(ServerPlayer p) {
        // bonus della tuta completa: agile, salta di piu', cade piano
        if (p.tickCount % 20 == 0 && fullSuit(p)) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0, false, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, 1, false, false, false));
        }
        Anchor a = ANCHORS.get(p.getUUID());
        if (a == null) return;
        if (!p.isAlive() || shooter(p).isEmpty() || p.isInWater() || p.isPassenger()) {
            ANCHORS.remove(p.getUUID());
            return;
        }
        Vec3 pos = p.position().add(0, p.getBbHeight() * 0.6, 0);
        Vec3 d = a.pos().subtract(pos);
        double dist = d.length();
        if (dist < 2.5) {
            ANCHORS.remove(p.getUUID()); // arrivato
            return;
        }
        Vec3 dir = d.scale(1.0 / dist);
        Vec3 v = p.getDeltaMovement();
        v = v.add(dir.scale(0.16));
        if (dist > a.len()) { // filo teso: niente velocita' verso l'esterno
            double out = -v.dot(dir);
            if (out > 0) v = v.add(dir.scale(out));
        }
        double sp = v.length();
        if (sp > 2.0) v = v.scale(2.0 / sp);
        p.setDeltaMovement(v);
        p.hurtMarked = true;
        p.fallDistance = 0f;
        ANCHORS.put(p.getUUID(), new Anchor(a.pos(), Math.min(a.len(), dist)));

        if (p.tickCount % 2 == 0) {
            ServerLevel lvl = p.serverLevel();
            Vec3 look = p.getLookAngle();
            Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
            Vec3 hand = p.getEyePosition().add(right.scale(-0.35)).add(0, -0.3, 0).add(look.scale(0.4));
            Vec3 line = a.pos().subtract(hand);
            double len = line.length();
            int steps = (int) Math.min(60, len / 1.0);
            for (int i = 0; i <= steps; i++) {
                Vec3 q = hand.add(line.scale(i / (double) Math.max(1, steps)));
                lvl.sendParticles(WHITE, q.x, q.y, q.z, 1, 0, 0, 0, 0);
            }
        }
    }

    public static void clear(Player p) {
        ANCHORS.remove(p.getUUID());
    }

    // ---------------------------------------------------------------- sparo

    public static void shoot(ServerPlayer p) {
        if (!SuitData.ready(p, "web")) return;
        ItemStack s = shooter(p);
        if (s.isEmpty()) {
            SuitData.msg(p, "msg.ironmanmod.no_shooter");
            return;
        }
        if (!take(p, s, SHOT_COST)) return;
        SuitData.setCooldown(p, "web", 6);

        ServerLevel lvl = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(32.0));
        BlockHitResult bh = lvl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (bh.getType() != HitResult.Type.MISS) end = bh.getLocation();

        LivingEntity hit = null;
        double best = Double.MAX_VALUE;
        List<LivingEntity> cand = lvl.getEntitiesOfClass(LivingEntity.class, new AABB(eye, end).inflate(1.5),
                e -> e != p && e.isAlive() && !e.isSpectator());
        for (LivingEntity e : cand) {
            var h = e.getBoundingBox().inflate(0.3).clip(eye, end);
            if (h.isPresent()) {
                double dd = eye.distanceToSqr(h.get());
                if (dd < best) {
                    best = dd;
                    hit = e;
                }
            }
        }
        if (hit != null) end = eye.add(look.scale(Math.sqrt(best)));

        Vec3 start = eye.add(look.cross(new Vec3(0, 1, 0)).normalize().scale(-0.3)).add(0, -0.25, 0);
        Vec3 line = end.subtract(start);
        int steps = (int) Math.max(2, line.length() * 2);
        for (int i = 0; i <= steps; i++) {
            Vec3 q = start.add(line.scale(i / (double) steps));
            lvl.sendParticles(SHOT, q.x, q.y, q.z, 1, 0.02, 0.02, 0.02, 0.0);
        }
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.SLIME_BLOCK_HIT, SoundSource.PLAYERS, 1.0f, 1.8f);
        if (hit != null) {
            hit.hurt(p.damageSources().playerAttack(p), 6.0f);
            hit.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 3));
            lvl.sendParticles(WHITE, hit.getX(), hit.getY() + hit.getBbHeight() / 2, hit.getZ(), 14, 0.3, 0.4, 0.3, 0.02);
        } else if (bh.getType() != HitResult.Type.MISS) {
            lvl.sendParticles(WHITE, end.x, end.y, end.z, 8, 0.2, 0.2, 0.2, 0.02);
        }
    }
}
