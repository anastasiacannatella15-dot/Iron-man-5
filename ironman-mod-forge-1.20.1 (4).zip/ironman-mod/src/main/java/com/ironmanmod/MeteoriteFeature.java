package com.ironmanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Meteorite: un cratere con una roccia bruciata e, nel cuore, blocchi di Uru. */
public class MeteoriteFeature extends Feature<NoneFeatureConfiguration> {
    public MeteoriteFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    private static boolean solid(BlockState s) {
        return !s.isAir() && !s.canBeReplaced() && !s.is(BlockTags.LEAVES) && !s.is(BlockTags.LOGS) && s.getFluidState().isEmpty();
    }

    private static int surfaceY(WorldGenLevel lvl, int x, int z, int startY) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(x, startY + 12, z);
        for (int y = startY + 12; y > startY - 16; y--) {
            p.setY(y);
            if (solid(lvl.getBlockState(p))) return y;
        }
        return startY - 16;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel lvl = ctx.level();
        BlockPos o = ctx.origin();
        RandomSource r = ctx.random();
        if (!lvl.getFluidState(o.below()).isEmpty()) return false; // niente oceani
        int cx = o.getX(), cz = o.getZ();
        int R = 8;
        int groundY = surfaceY(lvl, cx, cz, o.getY());
        int centerFloor = groundY - 4;

        // cratere
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                double d2 = dx * dx + dz * dz;
                if (d2 > R * R) continue;
                int x = cx + dx, z = cz + dz;
                int top = surfaceY(lvl, x, z, groundY);
                double depth = 4.0 * (1.0 - d2 / (R * R));
                int bottom = top - (int) Math.round(depth);
                for (int y = top + 5; y > bottom; y--) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!lvl.getBlockState(p).is(Blocks.BEDROCK)) lvl.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                }
                // terreno bruciato sul fondo e sul bordo
                BlockPos fp = new BlockPos(x, bottom, z);
                float f = r.nextFloat();
                BlockState burnt = f < 0.35f ? Blocks.BLACKSTONE.defaultBlockState()
                        : f < 0.6f ? Blocks.COARSE_DIRT.defaultBlockState()
                        : f < 0.8f ? Blocks.GRAVEL.defaultBlockState()
                        : f < 0.92f ? Blocks.BASALT.defaultBlockState() : Blocks.MAGMA_BLOCK.defaultBlockState();
                lvl.setBlock(fp, burnt, 2);
                // sassi sul bordo del cratere
                if (d2 > (R - 2) * (R - 2) && r.nextInt(3) == 0) {
                    lvl.setBlock(new BlockPos(x, top + 1, z), (r.nextBoolean() ? Blocks.BLACKSTONE : Blocks.BASALT).defaultBlockState(), 2);
                }
            }
        }

        // la roccia del meteorite (mezza sepolta)
        int my = centerFloor + 2;
        int rad = 3;
        for (int dx = -rad - 1; dx <= rad + 1; dx++) {
            for (int dy = -rad - 1; dy <= rad + 1; dy++) {
                for (int dz = -rad - 1; dz <= rad + 1; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz) + r.nextDouble() * 0.5;
                    if (d > rad + 0.4) continue;
                    BlockPos p = new BlockPos(cx + dx, my + dy, cz + dz);
                    float f = r.nextFloat();
                    BlockState s;
                    if (d > 2.0) {
                        s = f < 0.5f ? Blocks.BLACKSTONE.defaultBlockState() : f < 0.8f ? Blocks.BASALT.defaultBlockState()
                                : f < 0.92f ? Blocks.MAGMA_BLOCK.defaultBlockState() : Blocks.OBSIDIAN.defaultBlockState();
                    } else {
                        s = f < 0.6f ? Blocks.DEEPSLATE.defaultBlockState() : f < 0.85f ? Blocks.BLACKSTONE.defaultBlockState()
                                : Blocks.CRYING_OBSIDIAN.defaultBlockState();
                    }
                    if (d > 1.5 && r.nextInt(6) == 0) s = ModContent.TITANIUM_ORE.get().defaultBlockState();
                    lvl.setBlock(p, s, 2);
                }
            }
        }
        // cuore di Uru: centro + 6 blocchi vicini, piu' qualche pezzo sparso
        BlockPos core = new BlockPos(cx, my, cz);
        lvl.setBlock(core, ModContent.URU_BLOCK.get().defaultBlockState(), 2);
        for (net.minecraft.core.Direction dir : net.minecraft.core.Direction.values()) {
            if (r.nextInt(4) != 0) lvl.setBlock(core.relative(dir), ModContent.URU_BLOCK.get().defaultBlockState(), 2);
        }
        for (int i = 0; i < 3; i++) {
            lvl.setBlock(core.offset(r.nextInt(3) - 1, r.nextInt(3) - 1, r.nextInt(3) - 1), ModContent.URU_BLOCK.get().defaultBlockState(), 2);
        }
        return true;
    }
}
