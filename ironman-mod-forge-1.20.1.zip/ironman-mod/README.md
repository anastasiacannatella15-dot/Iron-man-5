# The Avengers 3.5.0 — Iron Man, Thor, Captain America, Doctor Strange

Minecraft **1.20.1** · Forge **47.3.0** · Java **17**

La versione si cambia in `gradle.properties` (`mod_version`): il .jar si chiama `the-avengers-<versione>.jar`.

## 3.5.0 — The Avengers, Mark 4/6/7/8
- **La mod si chiama "The Avengers"** (nome nel menu mod, nella tab creativa e nel file: `the-avengers-<versione>.jar`). L'id tecnico resta `ironmanmod`, così mondi, comandi e ricette continuano a funzionare. **Togli dalla cartella `mods` il vecchio `iron-man-*.jar`.**
- **Mark 4, 6 e 8:** armature normali con pezzi veri, come la Mark 42 (volo, repulsore, HUD). Craft: Mark 4 ferro + oro, Mark 6 oro + polvere di glowstone, Mark 8 titanio + oro (schema es. elmo `III / IMI`).
- **Mark 7 coi bracciali** (craft `IGI / R R / IGI`: ferro, oro, redstone): i pezzi arrivano in volo dall'alto e si agganciano ai bracciali uno alla volta, come in The Avengers. Shift + clic destro con i bracciali scarichi mentre porti la Mark 7: l'armatura rientra. La Mark 7 si ottiene solo così.

## 3.4.1 — Skin Mark 5
- Mark 5: usata la skin disegnata da te (`mark5.png`), gambali compresi.
- La texture 256x256 della valigetta (`textures/entity/mark5_briefcase_model.png`) è nel progetto ma non ancora usata: serve il modello 3D (file Blockbench) a cui appartiene.

## 3.4.0 — Valigetta Mark 5 come Iron Man 2
- La **Mark 5 si ottiene solo con la valigetta**: i pezzi non si craftano più e non sono nella tab creativa.
- **Craft più economico:** 6 lingotti di ferro, 2 redstone e 1 lapislazzuli (`III / RLR / III`) al posto di 24 diamanti.
- **Nuova animazione, non più nanotech:** clic destro e la valigetta viene posata a terra davanti a te, si apre e i pezzi volano dalla valigetta al corpo uno alla volta (stivali, gambali, petto, casco). Poi si chiude e la valigetta vuota torna nell'inventario. Resti fermo per circa 5 secondi. Shift + clic destro con la valigetta vuota mentre porti la Mark 5: l'armatura rientra nella valigetta.

## 3.3.2 — Skin Mark 42
- Texture della Mark 42 aggiornata con la skin `iron_man_layer1.png` e cosce riempite (prima erano trasparenti: si vedevano le gambe nude sopra gli stivali).

## 3.3.1 — Gambali Mark 2/3/5
- Le texture delle armature Mark 2, 3 e 5 non coprivano le cosce (solo gli stivali): ora i gambali coprono tutta la gamba.

## 3.3.0 — Valigetta della Mark 5
- **Valigetta Mark 5**: clic destro e come in Iron Man 2 la valigetta si apre e i pezzi volano addosso uno alla volta (stivali, gambali, petto, casco) con scintille e suoni; resti fermo per circa 3,5 secondi. I pezzi che avevi addosso vanno nell'inventario. Shift + clic destro con la valigetta vuota mentre porti la Mark 5: l'armatura si smonta e rientra nella valigetta.

## 3.2.0 — Captain America, Doctor Strange, Mark 2/3/5
- **Scudo lanciabile (Captain America):** con lo scudo di vibranio in mano e il siero del super soldato, **Z** lo lancia: colpisce, rimbalza fino a 4 bersagli vicini e sui muri, poi torna da te. **X** lo richiama. Danno 12 ai mob, 8 ai giocatori.
- **Anello di Doctor Strange** (craft: 8 lingotti d'oro attorno a un occhio di Ender): Shift + clic destro salva dove ti trovi; clic destro apre un portale di scintille arancioni, resta fermo 3 secondi e arrivi alla destinazione (senza destinazione salvata: il tuo letto o lo spawn). Vicino alla destinazione il portale ti riporta da dove eri partito. Funziona anche tra dimensioni.
- **Armature Iron Man Mark 2 (argento), Mark 3 (rosso e oro) e Mark 5 (rosso e argento):** pezzi veri come la Mark 42, senza nanotech e senza reattore. Con tutti e 4 i pezzi hanno volo, repulsore e HUD con J.A.R.V.I.S. Craft: lingotti di ferro / oro / diamanti con un pezzo di redstone / rame / lapislazzuli al posto dei vuoti (es. elmo `III / IMI`). Sono più deboli della Mark 42: Mark 2 senza micro-missili, Mark 3 con 2, Mark 5 con 3.

## 3.1.0 — Poteri delle gemme e Stormbreaker
- **Poteri delle gemme nel Mjölnir/Stormbreaker** (non dipendono più da Palladium): tasto **K** usa il potere della gemma scelta, **Shift + K** cambia gemma. Con il martello in mano:
  - **Potere:** raggio viola che parte dalla testa del martello e si allarga con la distanza (40 danno ai mob, 15 ai giocatori).
  - **Spazio:** teletrasporto di 14 blocchi nella direzione in cui guardi.
  - **Realtà:** cono di fuoco e Wither davanti a te.
  - **Tempo:** rallenta tutti entro 10 blocchi.
  - **Anima:** ruba vita a chi è entro 8 blocchi e ti cura.
  - **Mente:** i mob entro 14 blocchi perdono il bersaglio, si illuminano e si indeboliscono.
- Le abilità passive delle gemme quando il martello colpisce ora funzionano sempre, anche con Palladium installato.
- **Stormbreaker:** non serve più l'armatura Iron Man. Lo regge solo chi ha il **siero del dio del tuono** (e chi è in creativa).

## 3.0.1 — Correzioni
- Avengers Tower: la "A" luminosa aveva un buco a quota del solaio, ora è intera.
- Ultron: cadendo nel vuoto muore invece di evolversi all'infinito.

## 3.0.0 — Ultron e Avengers Tower
- **Nucleo di Ultron** (craft: 4 lingotti di vibranio, 2 diamanti, 2 occhi di Ender, 1 blocco di redstone, schema `VDV/ERE/VDV`): clic destro su un blocco e nasce Ultron.
- Ultron ha 4 forme come in Age of Ultron: **AI** (iniziale, piccolo), **Mark II**, **Mark III**, **Prime** (finale, 400 di vita). Quando una forma sta per morire si trasferisce nella successiva, con la sua frase. Spara raggi rossi; Prime chiama dei droni (Ultron AI). Nella tab creativa ci sono i nuclei di tutte le forme.
- **Avengers Tower**: struttura che si genera nel mondo (raro, terreno piano, non in acqua), con la "A" luminosa, scala a pioli nel nucleo, bauli con bottino e guglia con parafulmine. Trovala con `/locate structure ironmanmod:avengers_tower` o con l'Explorer's Compass.

## 2.9.3 — Thanos a 0 0
- Su Titano Thanos compare una sola volta a 0 0 (o sulla terraferma più vicina, se lì c'è acqua). Quando arrivi su Titano un messaggio ti dice le sue coordinate.

## 2.9.2 — Correzione
- Thanos prende il Guanto dell'Infinito anche se lo porti in Curios (slot hands o altri), non solo dall'inventario.

## 2.9.1 — Correzione
- Thanos: la scena finale ("I AM INEVITABLE.") parte a 10 di vita invece che a 20.

## 2.9.0 — Degni, sieri, vibranio, Thanos e Titano
- **Mjölnir solo per i degni:** serve il siero del dio del tuono, oppure il siero del super soldato + 50 mob ostili uccisi. Chi non è degno non lo regge: gli cade di mano e non lo può raccogliere.
- **Stormbreaker:** lo regge solo chi ha il siero del dio del tuono (in creativa lo reggono tutti).
- **Siringa vuota** (ferro + vetro), **Siero del dio del tuono** (siringa + Uru + parafulmine + polvere di glowstone: super elettrico, forza/velocità/salto, immune ai fulmini) e **Siero del super soldato** (siringa + mela d'oro + diamante + redstone: forza, velocità, resistenza, cuori extra). I sieri restano dopo la morte.
- **Vibranio:** minerale più raro del diamante (sottoterra, y -64..0) e 1 blocco garantito in ogni meteorite; si ottiene il lingotto (piccone di diamante). **Scudo di vibranio** (4 lingotti + 5 ferro): tasto destro per pararsi.
- **Thanos:** 500 di vita, armor 30. Se hai il Guanto dell'Infinito dice "You stole my Gauntlet. I'm taking it back." e te lo prende (mano sinistra, particelle arcobaleno); a 10 di vita "I AM INEVITABLE." Con la Mark 85 c'è la scena finale (Thanos schiocca, non trova le gemme, "I am Iron Man", schiocchi e resti a mezzo cuore, lui muore). Senza Mark 85 schiocca e dimezza la vita a chi è vicino. Se muore restituisce il guanto.
- **Pianeta Titano:** nuova dimensione. Con la Gemma dello Spazio o il Tesseract in mano: Maiusc + tasto destro, resta vicino al portale 4 secondi. Su Titano lo stesso gesto ti riporta indietro. La prima volta Thanos ti aspetta poco lontano.
- Comandi (operatori): `/serum thor|soldier|reset`, `/titan`, `/titan thanos`. Uovo di Thanos nel creativo.
- Non verificato: mai compilata né provata.

## 2.8.6 — Correzioni
- Lancio normale (tasto F/lancio semplice) con un Mjölnir non legato: non colpisce più chi lo lancia.
- Stormbreaker: l'esplosione alla fine dei 5 secondi del raggio ora è solo visiva e sonora (prima era una vera esplosione che ferisce chi è vicino e distrugge gli oggetti a terra).
- Pulizia: chiave di traduzione inutilizzata rimossa.

## 2.8.5 — Ricette dei reattori
- Mark 50: niente più stella del Nether, al centro c'è un lingotto di netherite (`DGD / GRG / DGD`, R = lingotto di netherite).
- Mark 85: niente più stella del Nether, al suo posto blocchi di diamante (`NDN / DRD / NDN`: N = lingotto di netherite, D = blocco di diamante, R = reattore Mark 50).

## 2.8.4 — Occhiali E.D.I.T.H. come quelli di Tony Stark
- Montatura nera spessa quadrata, barra superiore e ponte argento, aste argento lunghe; stesso stile in inventario, in mano e sulla faccia.

## 2.8.3 — Occhiali E.D.I.T.H. più realistici
- Nell'inventario e in mano sono veri occhiali in 3D (montatura, lenti, aste); indossati sulla faccia hanno montatura, lenti con riflesso e aste sulle tempie.

## 2.8.2 — Correzione
- Anche con il Mjölnir il braccio resta abbassato mentre gira (tasto destro).

## 2.8.1 — Correzione
- Stormbreaker: tenendo premuto il tasto destro il braccio resta abbassato mentre gira.

## 2.8.0 — Stormbreaker più grande
- Lo Stormbreaker è ora 1,4 volte più grande del Mjölnir (in mano, a terra, mentre gira). L'icona nell'inventario resta della stessa misura per entrare nello slot.

## 2.7.5 — Correzione
- Stormbreaker che gira: abbassato attorno alla mano (prima sembrava alzare la mano), in prima e terza persona.

## 2.7.4 — Correzione
- Mjölnir/Stormbreaker: il volo col salto funziona solo in prima persona; in terza persona il martello gira e basta.

## 2.7.3 — Correzioni
- Tenendo il Mjölnir con la Gemma del Potere non parte più l'esplosione di particelle gigante (quella della Pietra del Potere in mano senza guanto): disattivata nei poteri Palladium del martello.
- In terza persona il martello gira sempre nella mano, anche in volo: non si sposta più in avanti.

## 2.7.2 — Correzione compilazione
- HammerSpinLayer: import di RenderLayer corretto (errore di compilazione della 2.7.0/2.7.1).

## 2.7.1 — Correzione
- Mentre il martello girava in terza persona l'icona nella hotbar/inventario spariva: ora si nasconde solo il modello in mano.

## 2.7.0 — Martello che gira in terza persona, volo, Super Fulmine (U)
- Tenendo premuto il tasto destro il Mjölnir/Stormbreaker ruota nella mano anche in terza persona e per gli altri giocatori (layer di rendering dedicato).
- Girando e saltando voli nella direzione in cui guardi (Sprint = più veloce).
- Stormbreaker: con il Super Fulmine sbloccato il tasto **U** lancia un fulmine nel punto che miri, danno 140 (10 volte il fulmine normale da 14). Senza sblocco mostra un messaggio.
- Non verificato: la mod non è stata compilata né provata.

## Come ottenere il .jar

**Metodo consigliato (con il wrapper Gradle ufficiale):**
1. Scarica il "Mdk" di Forge 1.20.1 (47.3.0) da https://files.minecraftforge.net e scompattalo.
2. Copia dentro la sua cartella il mio `src/` e il mio `build.gradle` (sovrascrivi quelli dell'MDK).
3. Apri un terminale nella cartella ed esegui:
   - Windows: `gradlew build`
   - Linux/Mac: `./gradlew build`
4. Il file finito è in `build/libs/the-avengers-3.5.0.jar` → mettilo nella cartella `mods` di Minecraft.

**Alternativa:** con JDK 17 e Gradle 8.1.x installati, esegui `gradle build` direttamente in questa cartella.

## Modello 3D
Le armature usano un vero modello 3D (spalline, pettorali, ginocchiere, stivali, casco con mento e orecchie che sporgono dal corpo), senza librerie extra. Texture in `textures/models/armor/markXX_model.png`.

## Come si gioca

**Mark 42 — armatura normale, senza nanotech.** Si craftta pezzo per pezzo (diamanti + oro, stessa forma dell'armatura di diamante)
e si indossa a mano. Con tutti e 4 i pezzi addosso hai volo, repulsori e missili. Ha 20 punti armor, tenacia 2,5 e il 10% di danno in meno:
un po' meglio del diamante.

**Mark 50 e Mark 85 — nanotech.** Servono gli item **Mark 50** / **Mark 85** (hanno l'icona del reattore Arc della tuta),
da **indossare nello slot del petto** oppure in **Curios (slot body)**. Il bottone di trasformazione compare in alto a sinistra solo quando lo indossi.
- Mark 50: diamanti + oro + lingotto di netherite al centro (`DGD / GRG / DGD`)
- Mark 85: lingotti di netherite + blocchi di diamante + Mark 50 al centro (`NDN / DRD / NDN`)
- Trasformazione in stile Infinity War: le nanoparticelle partono dal petto e corrono fino a mani, piedi e testa (0,5 secondi, la tuta compare tutta insieme).

**Tasti** (modificabili in Opzioni → Controlli → Iron Man):

| Tasto | Azione |
|-------|--------|
| **G** | Trasformati / rimuovi l'armatura (0,5 secondi) |
| **R** | Repulsore: braccio destro alzato, raggio giallo di 1,5 s (tienilo premuto per continuare a sparare) |
| **V** | Unibeam dal petto, dura 1,5 s (solo Mark 50 e 85, non la 42) |
| **B** | Micro-missili di fuoco (4 / 6 / 8 bersagli) |

**Volo**: doppio salto per volare. Vai avanti e il corpo si inclina come nei film, con i repulsori accesi nelle gambe. Tieni **Sprint + W** mentre voli per il volo supersonico. L'energia si consuma volando e sparando e si ricarica a terra.

## Protezione e danno

| | Mark 42 | Mark 50 | Mark 85 |
|---|---|---|---|
| Armor (casco/petto/gambali/stivali) | 3/8/6/3 = 20 | 2/6/5/2 = 15 | 3/8/6/3 = 20 |
| Tenacia (per pezzo) | 2,5 | 5 | 6 |
| Resistenza al knockback (totale) | 0 | 2 | 2 |
| Danno subito (extra) | -10% | normale | -75% (circa il doppio della netherite con Protezione IV) |
| Repulsore (fuoco) | 10 | 13 | 16 |
| Unibeam (totale in 1,5 s) | no | 30 | 40 |
| Micro-missili | 4 | 6 | 8 |

I raggi danno fuoco. Nota: in Minecraft diamante e netherite hanno entrambi 20 punti armor,
le differenze tra i modelli vengono quindi da tenacia e riduzione del danno.

## Mjölnir (martello)
Ricetta: 5 lingotti di netherite, 1 stella del Nether, 1 blaze rod (`NNN / NSN / .R.`).
- **Tieni premuto il tasto destro**: il martello gira. **Salta** mentre tieni premuto e voli nella direzione in cui guardi (Sprint per andare piu' veloce). Niente danni da caduta.
- **Maiusc + tasto destro**: lo leghi a te, il tuo nome compare sotto il nome del martello. Solo tu puoi usarlo e sollevarlo.
- **Se lo droppi** resta in piedi a terra. Passandoci sopra non lo prendi: devi fare **tasto destro** sopra di lui.
- **Z** lancia · **X** richiama (torna da solo nel tuo inventario, anche attraverso i blocchi) · **C** fulmine dove guardi · **H** tempesta di fulmini tutto intorno a te.
- Sei immune ai suoi fulmini. Danno in mischia 14, lancio 16, fulmine 14 piu' fuoco.

## Morte
Se muori senza keepInventory, l'armatura nanotech sparisce e droppa la tua armatura originale.

## Uru, meteorite e Matrice del Mjölnir (2.6.1)
- **Meteorite**: ora è una vera struttura (2.6.1): funziona con `/locate structure ironmanmod:meteorite` e con Explorer's Compass. Cratere bruciato con roccia dal cuore di Blocchi di Uru e vene di titanio. Compare solo nei chunk NUOVI.
- **Matrice del Mjölnir** (`mjolnir_cast`): si trova nelle casse del **fabbro (weaponsmith) dei villaggi** (50% di probabilità).
- **Con Tinkers' Construct**: fondi Uru (lingotti/blocchi) nella fonderia, poi versa **3 secchi (3000 mB) di Uru fuso** sul tavolo di colata con la Matrice → ottieni il **Mjölnir**.
- **Senza Tinkers**: ricetta a banco `uru_block ×5 + matrice + blaze rod`.
- Nota: le ricette Tinkers sono scritte a memoria e non testate; se non funzionano mandami il `latest.log`.

## Spider, Iron Man (sentinella), FRIDAY/JARVIS
- **Texture armature**: Mark 50, Mark 85 e Iron Man usano le tue skin 64x64 (`textures/models/armor/*_model.png`, layout skin base). Per cambiarle sostituisci i PNG.
- **Armatura "Iron Man"** (ex Mark 42, classica rosso/oro, craft con lingotti di **titanio**): con tutti e 4 i pezzi hai volo/repulsore/missili e **JARVIS**.
- **Sentinella** (tasto J con l'armatura Iron Man completa): l'armatura esce da te, ti segue e spara ai mostri, 50 di vita; se muore droppa i pezzi. **Tasto destro** = si apre la schiena; **cammina verso di lei** e la indossi.
- **FRIDAY** (Mark 50/85) / **JARVIS** (Iron Man): schermata HUD in prima persona. **Shift+V** accende/spegne; **Shift+F** scansione dei mob; tenendo **Shift** i tasti in alto a sinistra si nascondono.
- **Titanio**: Titanio Grezzo si trova nei meteoriti insieme all'Uru (si fonde in lingotti).
- **Trasformazione**: onda + spirale di nanoparticelle dal reattore; in prima persona il braccio scende verso il reattore, in terza persona la mano va al petto.

## Aggiornamento
- Corretto il reattore indossato (texture mancante: busto nero/viola) e messe le tue icone per Mark 50 / Mark 85; Mark 85 con la tua versione "mask".
- Seconda mano occupata (offhand o Curios "hands"): l'armatura lascia libero il braccio sinistro.
- Mjölnir: cade subito (gravità normale). Con il Mjölnir in mano: **F** = lancio istantaneo (60 di danno, torna subito nella mano), **Shift+F** = blocca/sblocca (solo tu puoi prenderlo). Senza Mjölnir: Shift+F = scan mob.

## Aggiornamento
- Corretto il reattore indossato (texture mancante: busto nero/viola) e messe le tue icone per Mark 50 / Mark 85; Mark 85 con la tua versione "mask".
- Seconda mano occupata (offhand o Curios "hands"): l'armatura lascia libero il braccio sinistro.
- Mjölnir: cade subito (gravità normale). Con il Mjölnir in mano: **F** = lancio istantaneo (60 di danno, torna subito nella mano), **Shift+F** = blocca/sblocca (solo tu puoi prenderlo). Senza Mjölnir: Shift+F = scan mob.

## Aggiornamento
- Rimossa la tuta ragno, il Web Shooter e tutto ciò che era collegato.

## Aggiornamento
- Le tue nuove immagini sono nei posti giusti: icone Iron Man in `textures/item/mark42_*.png`, texture armature in `textures/models/armor/mark42_model.png`, `mark50_model.png`, `mark85_model.png`.
- **Reattore Arc nello slot petto**: alla trasformazione NON compaiono più elmo/pettorale/ecc.; il reattore resta e disegna l'armatura intera. Protezione del reattore: **Mark 85 = 30 armor, Mark 50 = 27 armor** (si legge sotto il nome). Con il reattore in Curios (body) resta il vecchio sistema a pezzi.

## Aggiornamento
- La Mark 50/85 non fa più comparire nessun pezzo (nemmeno il pettorale) né con il reattore nel petto né in Curios: il reattore resta dov'è e l'armatura si vede intera addosso (nuovo layer di rendering). Con il reattore in Curios la protezione (30 / 27) arriva da modificatori e sparisce a tuta ritirata.

## Gemme dell'Infinito nel Mjölnir
- Serve "Pugmeowla's Infinity Stone Core" (mod `infinity`). **Shift + tasto destro** con il Mjölnir in mano: una Gemma (mano secondaria o inventario) viene incastonata nel martello (1 per tipo, max 6). Se non hai gemme da inserire e il martello non ha ancora il tuo nome, mette il tuo nome come prima.
- Per togliere l'ultima gemma: Shift + tasto destro con mano secondaria vuota e il martello già con il tuo nome.
- Effetti tenendo il Mjölnir in mano: Power = Forza II (e danno di F ×1,5), Space = Velocità II (e portata di F ×2), Reality = Resistenza II, Time = Fretta II, Soul = Rigenerazione II, Mind = Visione notturna. Le gemme si leggono nel tooltip.

## Aggiornamento
- **F** con il Mjölnir in mano: il martello vola davvero verso dove guardi, fa 60 di danno (x1,5 con la gemma Power, velocità maggiore con Space) e appena colpisce un mob (o un blocco, o a fine corsa) torna subito nella tua mano. **Z** resta il lancio normale.

## Gemme potenziate
- **Danno di F:** senza gemme 60 (mob) / 8 (giocatori). **Power** da sola 250 / 20; ogni altra gemma aggiunge +20 / +2; con tutte e 6: 350 mob / 30 giocatori (esplosione TNT esclusa).
- **Inserire Power:** costa metà vita (non uccide), particelle viola entro 10 blocchi ed esplosione da 5 TNT (senza rompere i blocchi). Le altre gemme: solo particelle del loro colore.
- **Tutte e 6:** particelle di tutti i colori entro 15 blocchi e metà vita a chiunque entro 15 blocchi (anche chi regge il martello, ma non muore).
- Le pietre inserite si vedono sulla testa del martello (6 colori).

## Bilanciamento
- Danno F: senza gemme 20 (mob) / 4 (giocatori); solo Power 70 / 10; ogni altra gemma +6 / +1; tutte e 6 = 100 mob / 15 giocatori.

## Aggiornamento
- Danno F: senza gemme 14 (mob e giocatori); solo Power 100 mob / 25 giocatori; solo un'altra gemma 40 / 20; ogni gemma in più +10 / +5; tutte e 6 = 150 mob / 50 giocatori.

## Abilità delle gemme
Con il Mjölnir in mano (passive) e quando colpisce (lancio o mischia):
- **Potere:** Forza II + onda d'urto che respinge i mob vicini e lancia in alto il bersaglio.
- **Spazio:** Velocità II + Salto II; il bersaglio viene sbalzato lontano.
- **Realtà:** Resistenza II + resistenza al fuoco; il bersaglio brucia e viene avvelenato (Wither).
- **Tempo:** Fretta II + Velocità; il bersaglio è rallentato fortemente.
- **Anima:** Rigenerazione II + sazietà; chi colpisce si cura del 30% del danno.
- **Mente:** Visione notturna; il bersaglio diventa debole, luminoso e cieco per un attimo.

## Collegamento a Palladium
Se Palladium è installato, le gemme inserite nel Mjölnir danno i **poteri veri** della mod Infinity (infinity:power_stone, space_stone, reality_stone, time_stone, soul_stone, mind_stone) finché tieni il martello in mano; li togli lasciandolo. Usa il comando `/superpower add/remove` di Palladium. Senza Palladium restano le abilità semplici della 2.3.0.

## Aggiornamento
- Velocità del martello lanciato con F: nessuna gemma 1.0, una gemma 0.8, due o più 0.7, tutte e 6 = 0.5 (moltiplicatore della velocità base).

## Aggiornamento
- Lancio F: il numero indica il tempo di volo (più basso = più veloce): 1.0 / 0.8 / 0.7 / 0.5 con 0 / 1 / 2+ / 6 gemme. Velocità = base ÷ fattore.
- Armatura Iron Man (Mk42): maschera chiusa, il viso non si vede più (occhi bianchi luminosi).

## Aggiornamento
- Comando `/mjolnir test`: ti colpisce col danno da giocatore del lancio F (in base alle gemme del Mjölnir che tieni in mano) per provare quanti cuori toglie. Può ucciderti.

## Stormbreaker, Bifrost, raggio del Potere
- **Stormbreaker** (ricetta: 2 lingotti di Uru, 1 titanio, 1 stella del Nether, 1 verga di blaze; anche in creativa).
  - **U — Fulmine:** lancia l'ascia, colpisce con un fulmine (danno del fulmine del Mjölnir) e torna subito in mano.
  - **O — Bifrost:** guarda un punto (fino a 120 blocchi) e ti teletrasporti lì con un raggio arcobaleno.
  - **Super Fulmine:** i fulmini fanno x10 danno (sbloccato dal raggio, o con `/stormbreaker super` per provarlo).
- **Raggio della Gemma del Potere** (energy beam di Palladium lanciato da un giocatore):
  - su chi tiene il **Mjölnir**: ogni secondo consuma 1 di durabilità; dopo 10 secondi si spezza (le gemme tornano a te);
  - su chi tiene lo **Stormbreaker**: nessun danno, incanala il potere (particelle di fulmine intorno), dopo 5 secondi esplodono e si sblocca il Super Fulmine.
- Mjölnir: ora ha 10 di durabilità (barra visibile quando si danneggia). Lancio F: portata massima ~48 blocchi.
- Palladium: poteri copiati (mj_*_stone) con "pietra in mano" sostituita dal Mjölnir, così le abilità si attivano.
- Particelle delle gemme in un solo pacchetto (meno lag).

## Aggiornamento
- Danno in mischia: Mjölnir 12, Stormbreaker 15 (più forte del Mjölnir).
- Ricetta Stormbreaker (senza Tinkers): 3 blocchi di Uru a forma d'ascia, Stella del Nether al centro, verga di blaze come manico (`UU ` / `UN ` / ` R `).
- Con Tinkers' Construct: Matrice dello Stormbreaker + 6 secchi (6000 mB) di Uru fuso nel tavolo di colata. La Matrice si trova nelle casse dei fabbri dei villaggi (50%) insieme a quella del Mjölnir.

## Stormbreaker come il Mjölnir, occhiali E.D.I.T.H.
- **Stormbreaker** ridisegnato (martello a un lato, lama dall'altro, manico intrecciato) e ora funziona come il Mjölnir ma migliore: stessi tasti e poteri (tasto destro tenuto = gira/vola, Shift+destro = nome o gemme, Q = cade a terra e si riprende col destro, Z lancia, X richiama, C fulmine, H tempesta, F lancio istantaneo, Shift+F bloccato) più **Bifrost (O)** e **Super Fulmine** (tutti i fulmini x10, sbloccato dal raggio del Potere o con `/stormbreaker super`). Si possono inserire le gemme di Infinity (Shift+destro). Non si rompe mai. Mischia 15 (Mjölnir 12). Poteri Palladium anche per lo Stormbreaker.
- **Mjölnir:** con il tasto destro tenuto ruota nella mano (il manico resta nella mano, la testa gira) invece che davanti allo schermo.
- **Gemma del Potere:** niente più esplosioni vere; resta metà vita, onda di particelle viola e un effetto visivo di esplosione senza danni.
- **Occhiali E.D.I.T.H.** (ferro, diamante, 2 pannelli di vetro: `IDI` / `G G`): nello slot dell'elmo mostrano il visore (bussola, coordinate, Shift+F scansione dei mob).
- **Blocco di Uru:** basta il piccone di ferro (prima serviva il diamante).

## Correzioni
- Le gemme inserite nello Stormbreaker ora si vedono sulla testa (come sul Mjölnir).
- Bifrost: se non guardi nulla di solido ti porta a 60 blocchi (non oltre i chunk caricati).
