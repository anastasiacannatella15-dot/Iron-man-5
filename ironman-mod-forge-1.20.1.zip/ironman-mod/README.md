# Iron Man 1.4.0 — Mark 42 / Mark 50 / Mark 85

Minecraft **1.20.1** · Forge **47.3.0** · Java **17**

La versione si cambia in `gradle.properties` (`mod_version`): il .jar si chiama `iron-man-<versione>.jar`.

## Come ottenere il .jar

**Metodo consigliato (con il wrapper Gradle ufficiale):**
1. Scarica il "Mdk" di Forge 1.20.1 (47.3.0) da https://files.minecraftforge.net e scompattalo.
2. Copia dentro la sua cartella il mio `src/` e il mio `build.gradle` (sovrascrivi quelli dell'MDK).
3. Apri un terminale nella cartella ed esegui:
   - Windows: `gradlew build`
   - Linux/Mac: `./gradlew build`
4. Il file finito è in `build/libs/iron-man-1.4.0.jar` → mettilo nella cartella `mods` di Minecraft.

**Alternativa:** con JDK 17 e Gradle 8.1.x installati, esegui `gradle build` direttamente in questa cartella.

## Modello 3D
Le armature usano un vero modello 3D (spalline, pettorali, ginocchiere, stivali, casco con mento e orecchie che sporgono dal corpo), senza librerie extra. Texture in `textures/models/armor/markXX_model.png`.

## Come si gioca

**Mark 42 — armatura normale, senza nanotech.** Si craftta pezzo per pezzo (diamanti + oro, stessa forma dell'armatura di diamante)
e si indossa a mano. Con tutti e 4 i pezzi addosso hai volo, repulsori e missili. Ha 20 punti armor, tenacia 2,5 e il 10% di danno in meno:
un po' meglio del diamante.

**Mark 50 e Mark 85 — nanotech.** Servono gli item **Mark 50** / **Mark 85** (hanno l'icona del reattore Arc della tuta),
da **indossare nello slot del petto** oppure in **Curios (slot body)**. Il bottone di trasformazione compare in alto a sinistra solo quando lo indossi.
- Mark 50: diamanti + oro + stella del Nether al centro (`DGD / GRG / DGD`)
- Mark 85: lingotti di netherite + stelle del Nether + blocchi di diamante + Mark 50 al centro (`NSN / DRD / NSN`)
- Trasformazione in stile Infinity War: le nanoparticelle partono dal petto e corrono fino a mani, piedi e testa (1,3 secondi).

**Tasti** (modificabili in Opzioni → Controlli → Iron Man):

| Tasto | Azione |
|-------|--------|
| **G** | Trasformati / rimuovi l'armatura (1,3 secondi: prima il corpetto, poi il resto) |
| **R** | Repulsore: alzi il braccio destro, raggio giallo di 0,5 s |
| **V** | Unibeam dal petto, dura 1,2 s (solo Mark 50 e 85, non la 42) |
| **B** | Micro-missili di fuoco (4 / 6 / 8 bersagli) |

**Volo**: doppio salto per volare. Vai avanti e il corpo si inclina come nei film, con i repulsori accesi nelle gambe. Tieni **Sprint + W** mentre voli per il volo supersonico. L'energia si consuma volando e sparando e si ricarica a terra.

## Protezione e danno

| | Mark 42 | Mark 50 | Mark 85 |
|---|---|---|---|
| Armor (casco/petto/gambali/stivali) | 3/8/6/3 = 20 | 3/8/6/3 = 20 | 3/8/6/3 = 20 |
| Tenacia | 2,5 | 3 (come la netherite) | 12 |
| Danno subito (extra) | -10% | normale | -75% (circa il doppio della netherite con Protezione IV) |
| Repulsore (fuoco) | 10 | 13 | 16 |
| Unibeam (totale in 1,2 s) | no | 30 | 40 |
| Micro-missili | 4 | 6 | 8 |

I raggi danno fuoco. Nota: in Minecraft diamante e netherite hanno entrambi 20 punti armor,
le differenze tra i modelli vengono quindi da tenacia e riduzione del danno.

## Morte
Se muori senza keepInventory, l'armatura nanotech sparisce e droppa la tua armatura originale.
