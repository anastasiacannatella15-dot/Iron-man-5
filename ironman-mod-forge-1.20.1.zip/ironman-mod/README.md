# Iron Man 2.8.2 — Mark 42 / Mark 50 / Mark 85

Minecraft **1.20.1** · Forge **47.3.0** · Java **17**

La versione si cambia in `gradle.properties` (`mod_version`): il .jar si chiama `iron-man-<versione>.jar`.

## 2.8.2 — Correzione
- Anche con il Mjölnir il braccio resta abbassato mentre gira (tasto destro).

## 2.8.1 — Correzione
- Stormbreaker: tenendo premuto il tasto destro il braccio resta abbassato mentre gira.

## 2.8.0 — Stormbreaker più grande
- Lo Stormbreaker è ora 1,4 volte più grande del Mjölnir (in mano, a terra, mentre gira). L'icona nell'inventario resta della stessa misura per entrare nello slot.

## 2.7.5 — Correzione
- Stormbreaker che gira: abbassato attorno alla mano (prima sembrava alzare la mano), in prima e terza persona.

## 2.7.4 — Correzione
- Mjölnir/Stormbreaker: il volo col salto funziona solo in prima persona; in terza persona il martello gira e basta.

## 2.7.3 — Correzioni
- Tenendo il Mjölnir con la Gemma del Potere non parte più l'esplosione di particelle gigante (quella della Pietra del Potere in mano senza guanto): disattivata nei poteri Palladium del martello.
- In terza persona il martello gira sempre nella mano, anche in volo: non si sposta più in avanti.

## 2.7.2 — Correzione compilazione
- HammerSpinLayer: import di RenderLayer corretto (errore di compilazione della 2.7.0/2.7.1).

## 2.7.1 — Correzione
- Mentre il martello girava in terza persona l'icona nella hotbar/inventario spariva: ora si nasconde solo il modello in mano.

## 2.7.0 — Martello che gira in terza persona, volo, Super Fulmine (U)
- Tenendo premuto il tasto destro il Mjölnir/Stormbreaker ruota nella mano anche in terza persona e per gli altri giocatori (layer di rendering dedicato).
- Girando e saltando voli nella direzione in cui guardi (Sprint = più veloce).
- Stormbreaker: con il Super Fulmine sbloccato il tasto **U** lancia un fulmine nel punto che miri, danno 140 (10 volte il fulmine normale da 14). Senza sblocco mostra un messaggio.
- Non verificato: la mod non è stata compilata né provata.

## Come ottenere il .jar

**Metodo consigliato (con il wrapper Gradle ufficiale):**
1. Scarica il "Mdk" di Forge 1.20.1 (47.3.0) da https://files.minecraftforge.net e scompattalo.
2. Copia dentro la sua cartella il mio `src/` e il mio `build.gradle` (sovrascrivi quelli dell'MDK).
3. Apri un terminale nella cartella ed esegui:
   - Windows: `gradlew build`
   - Linux/Mac: `./gradlew build`
4. Il file finito è in `build/libs/iron-man-2.8.2.jar` → mettilo nella cartella `mods` di Minecraft.

**Alternativa:** con JDK 17 e Gradle 8.1.x installati, esegui `gradle build` direttamente in questa cartella.

## Modello 3D
Le armature usano un vero modello 3D (spalline, pettorali, ginocchiere, stivali, casco con mento e orecchie che sporgono dal corpo), senza librerie extra. Texture in `textures/models/armor/markXX_model.png`.

## Come si gioca

**Mark 42 — armatura normale, senza nanotech.** Si craftta pezzo per pezzo (diamanti + oro, stessa forma dell'armatura di diamante)
e si indossa a mano. Con tutti e 4 i pezzi addosso hai volo, repulsori e missili. Ha 20 punti armor, tenacia 2,5 e il 10% di danno in meno:
un po' meglio del diamante.

**Mark 50 e Mark 85 — nanotech.** Servono gli item **Mark 50** / **Mark 85** (hanno l'icona del reattore Arc della tuta),
da **indossare nello slot del petto** oppure in **Curios (slot body)**. Il bottone di trasformazione compare in alto a sinistra solo quando lo indossi.
- Mark 50: diamanti + oro + stella del Nether al centro (`DGD / GRG / DGD`)
- Mark 85: lingotti di netherite + stelle del Nether + blocchi di diamante + Mark 50 al centro (`NSN / DRD / NSN`)
- Trasformazione in stile Infinity War: le nanoparticelle partono dal petto e corrono fino a mani, piedi e testa (0,5 secondi, la tuta compare tutta insieme).

**Tasti** (modificabili in Opzioni → Controlli → Iron Man):

| Tasto | Azione |
|-------|--------|
| **G** | Trasformati / rimuovi l'armatura (0,5 secondi) |
| **R** | Repulsore: braccio destro alzato, raggio giallo di 1,5 s (tienilo premuto per continuare a sparare) |
| **V** | Unibeam dal petto, dura 1,5 s (solo Mark 50 e 85, non la 42) |
| **B** | Micro-missili di fuoco (4 / 6 / 8 bersagli) |

**Volo**: doppio salto per volare. Vai avanti e il corpo si inclina come nei film, con i repulsori accesi nelle gambe. Tieni **Sprint + W** mentre voli per il volo supersonico. L'energia si consuma volando e sparando e si ricarica a terra.

## Protezione e danno

| | Mark 42 | Mark 50 | Mark 85 |
|---|---|---|---|
| Armor (casco/petto/gambali/stivali) | 3/8/6/3 = 20 | 2/6/5/2 = 15 | 3/8/6/3 = 20 |
| Tenacia (per pezzo) | 2,5 | 5 | 6 |
| Resistenza al knockback (totale) | 0 | 2 | 2 |
| Danno subito (extra) | -10% | normale | -75% (circa il doppio della netherite con Protezione IV) |
| Repulsore (fuoco) | 10 | 13 | 16 |
| Unibeam (totale in 1,5 s) | no | 30 | 40 |
| Micro-missili | 4 | 6 | 8 |

I raggi danno fuoco. Nota: in Minecraft diamante e netherite hanno entrambi 20 punti armor,
le differenze tra i modelli vengono quindi da tenacia e riduzione del danno.

## Mjölnir (martello)
Ricetta: 5 lingotti di netherite, 1 stella del Nether, 1 blaze rod (`NNN / NSN / .R.`).
- **Tieni premuto il tasto destro**: il martello gira. **Salta** mentre tieni premuto e voli nella direzione in cui guardi (Sprint per andare piu' veloce). Niente danni da caduta.
- **Maiusc + tasto destro**: lo leghi a te, il tuo nome compare sotto il nome del martello. Solo tu puoi usarlo e sollevarlo.
- **Se lo droppi** resta in piedi a terra. Passandoci sopra non lo prendi: devi fare **tasto destro** sopra di lui.
- **Z** lancia · **X** richiama (torna da solo nel tuo inventario, anche attraverso i blocchi) · **C** fulmine dove guardi · **H** tempesta di fulmini tutto intorno a te.
- Sei immune ai suoi fulmini. Danno in mischia 14, lancio 16, fulmine 14 piu' fuoco.

## Morte
Se muori senza keepInventory, l'armatura nanotech sparisce e droppa la tua armatura originale.

## Uru, meteorite e Matrice del Mjölnir (2.6.1)
- **Meteorite**: ora è una vera struttura (2.6.1): funziona con `/locate structure ironmanmod:meteorite` e con Explorer's Compass. Cratere bruciato con roccia dal cuore di Blocchi di Uru e vene di titanio. Compare solo nei chunk NUOVI.
- **Matrice del Mjölnir** (`mjolnir_cast`): si trova nelle casse del **fabbro (weaponsmith) dei villaggi** (50% di probabilità).
- **Con Tinkers' Construct**: fondi Uru (lingotti/blocchi) nella fonderia, poi versa **3 secchi (3000 mB) di Uru fuso** sul tavolo di colata con la Matrice → ottieni il **Mjölnir**.
- **Senza Tinkers**: ricetta a banco `uru_block ×5 + matrice + blaze rod`.
- Nota: le ricette Tinkers sono scritte a memoria e non testate; se non funzionano mandami il `latest.log`.

## Spider, Iron Man (sentinella), FRIDAY/JARVIS
- **Texture armature**: Mark 50, Mark 85 e Iron Man usano le tue skin 64x64 (`textures/models/armor/*_model.png`, layout skin base). Per cambiarle sostituisci i PNG.
- **Armatura "Iron Man"** (ex Mark 42, classica rosso/oro, craft con lingotti di **titanio**): con tutti e 4 i pezzi hai volo/repulsore/missili e **JARVIS**.
- **Sentinella** (tasto J con l'armatura Iron Man completa): l'armatura esce da te, ti segue e spara ai mostri, 50 di vita; se muore droppa i pezzi. **Tasto destro** = si apre la schiena; **cammina verso di lei** e la indossi.
- **FRIDAY** (Mark 50/85) / **JARVIS** (Iron Man): schermata HUD in prima persona. **Shift+V** accende/spegne; **Shift+F** scansione dei mob; tenendo **Shift** i tasti in alto a sinistra si nascondono.
- **Titanio**: Titanio Grezzo si trova nei meteoriti insieme all'Uru (si fonde in lingotti).
- **Trasformazione**: onda + spirale di nanoparticelle dal reattore; in prima persona il braccio scende verso il reattore, in terza persona la mano va al petto.

## Aggiornamento
- Corretto il reattore indossato (texture mancante: busto nero/viola) e messe le tue icone per Mark 50 / Mark 85; Mark 85 con la tua versione "mask".
- Seconda mano occupata (offhand o Curios "hands"): l'armatura lascia libero il braccio sinistro.
- Mjölnir: cade subito (gravità normale). Con il Mjölnir in mano: **F** = lancio istantaneo (60 di danno, torna subito nella mano), **Shift+F** = blocca/sblocca (solo tu puoi prenderlo). Senza Mjölnir: Shift+F = scan mob.

## Aggiornamento
- Corretto il reattore indossato (texture mancante: busto nero/viola) e messe le tue icone per Mark 50 / Mark 85; Mark 85 con la tua versione "mask".
- Seconda mano occupata (offhand o Curios "hands"): l'armatura lascia libero il braccio sinistro.
- Mjölnir: cade subito (gravità normale). Con il Mjölnir in mano: **F** = lancio istantaneo (60 di danno, torna subito nella mano), **Shift+F** = blocca/sblocca (solo tu puoi prenderlo). Senza Mjölnir: Shift+F = scan mob.

## Aggiornamento
- Rimossa la tuta ragno, il Web Shooter e tutto ciò che era collegato.

## Aggiornamento
- Le tue nuove immagini sono nei posti giusti: icone Iron Man in `textures/item/mark42_*.png`, texture armature in `textures/models/armor/mark42_model.png`, `mark50_model.png`, `mark85_model.png`.
- **Reattore Arc nello slot petto**: alla trasformazione NON compaiono più elmo/pettorale/ecc.; il reattore resta e disegna l'armatura intera. Protezione del reattore: **Mark 85 = 30 armor, Mark 50 = 27 armor** (si legge sotto il nome). Con il reattore in Curios (body) resta il vecchio sistema a pezzi.

## Aggiornamento
- La Mark 50/85 non fa più comparire nessun pezzo (nemmeno il pettorale) né con il reattore nel petto né in Curios: il reattore resta dov'è e l'armatura si vede intera addosso (nuovo layer di rendering). Con il reattore in Curios la protezione (30 / 27) arriva da modificatori e sparisce a tuta ritirata.

## Gemme dell'Infinito nel Mjölnir
- Serve "Pugmeowla's Infinity Stone Core" (mod `infinity`). **Shift + tasto destro** con il Mjölnir in mano: una Gemma (mano secondaria o inventario) viene incastonata nel martello (1 per tipo, max 6). Se non hai gemme da inserire e il martello non ha ancora il tuo nome, mette il tuo nome come prima.
- Per togliere l'ultima gemma: Shift + tasto destro con mano secondaria vuota e il martello già con il tuo nome.
- Effetti tenendo il Mjölnir in mano: Power = Forza II (e danno di F ×1,5), Space = Velocità II (e portata di F ×2), Reality = Resistenza II, Time = Fretta II, Soul = Rigenerazione II, Mind = Visione notturna. Le gemme si leggono nel tooltip.

## Aggiornamento
- **F** con il Mjölnir in mano: il martello vola davvero verso dove guardi, fa 60 di danno (x1,5 con la gemma Power, velocità maggiore con Space) e appena colpisce un mob (o un blocco, o a fine corsa) torna subito nella tua mano. **Z** resta il lancio normale.

## Gemme potenziate
- **Danno di F:** senza gemme 60 (mob) / 8 (giocatori). **Power** da sola 250 / 20; ogni altra gemma aggiunge +20 / +2; con tutte e 6: 350 mob / 30 giocatori (esplosione TNT esclusa).
- **Inserire Power:** costa metà vita (non uccide), particelle viola entro 10 blocchi ed esplosione da 5 TNT (senza rompere i blocchi). Le altre gemme: solo particelle del loro colore.
- **Tutte e 6:** particelle di tutti i colori entro 15 blocchi e metà vita a chiunque entro 15 blocchi (anche chi regge il martello, ma non muore).
- Le pietre inserite si vedono sulla testa del martello (6 colori).

## Bilanciamento
- Danno F: senza gemme 20 (mob) / 4 (giocatori); solo Power 70 / 10; ogni altra gemma +6 / +1; tutte e 6 = 100 mob / 15 giocatori.

## Aggiornamento
- Danno F: senza gemme 14 (mob e giocatori); solo Power 100 mob / 25 giocatori; solo un'altra gemma 40 / 20; ogni gemma in più +10 / +5; tutte e 6 = 150 mob / 50 giocatori.

## Abilità delle gemme
Con il Mjölnir in mano (passive) e quando colpisce (lancio o mischia):
- **Potere:** Forza II + onda d'urto che respinge i mob vicini e lancia in alto il bersaglio.
- **Spazio:** Velocità II + Salto II; il bersaglio viene sbalzato lontano.
- **Realtà:** Resistenza II + resistenza al fuoco; il bersaglio brucia e viene avvelenato (Wither).
- **Tempo:** Fretta II + Velocità; il bersaglio è rallentato fortemente.
- **Anima:** Rigenerazione II + sazietà; chi colpisce si cura del 30% del danno.
- **Mente:** Visione notturna; il bersaglio diventa debole, luminoso e cieco per un attimo.

## Collegamento a Palladium
Se Palladium è installato, le gemme inserite nel Mjölnir danno i **poteri veri** della mod Infinity (infinity:power_stone, space_stone, reality_stone, time_stone, soul_stone, mind_stone) finché tieni il martello in mano; li togli lasciandolo. Usa il comando `/superpower add/remove` di Palladium. Senza Palladium restano le abilità semplici della 2.3.0.

## Aggiornamento
- Velocità del martello lanciato con F: nessuna gemma 1.0, una gemma 0.8, due o più 0.7, tutte e 6 = 0.5 (moltiplicatore della velocità base).

## Aggiornamento
- Lancio F: il numero indica il tempo di volo (più basso = più veloce): 1.0 / 0.8 / 0.7 / 0.5 con 0 / 1 / 2+ / 6 gemme. Velocità = base ÷ fattore.
- Armatura Iron Man (Mk42): maschera chiusa, il viso non si vede più (occhi bianchi luminosi).

## Aggiornamento
- Comando `/mjolnir test`: ti colpisce col danno da giocatore del lancio F (in base alle gemme del Mjölnir che tieni in mano) per provare quanti cuori toglie. Può ucciderti.

## Stormbreaker, Bifrost, raggio del Potere
- **Stormbreaker** (ricetta: 2 lingotti di Uru, 1 titanio, 1 stella del Nether, 1 verga di blaze; anche in creativa).
  - **U — Fulmine:** lancia l'ascia, colpisce con un fulmine (danno del fulmine del Mjölnir) e torna subito in mano.
  - **O — Bifrost:** guarda un punto (fino a 120 blocchi) e ti teletrasporti lì con un raggio arcobaleno.
  - **Super Fulmine:** i fulmini fanno x10 danno (sbloccato dal raggio, o con `/stormbreaker super` per provarlo).
- **Raggio della Gemma del Potere** (energy beam di Palladium lanciato da un giocatore):
  - su chi tiene il **Mjölnir**: ogni secondo consuma 1 di durabilità; dopo 10 secondi si spezza (le gemme tornano a te);
  - su chi tiene lo **Stormbreaker**: nessun danno, incanala il potere (particelle di fulmine intorno), dopo 5 secondi esplodono e si sblocca il Super Fulmine.
- Mjölnir: ora ha 10 di durabilità (barra visibile quando si danneggia). Lancio F: portata massima ~48 blocchi.
- Palladium: poteri copiati (mj_*_stone) con "pietra in mano" sostituita dal Mjölnir, così le abilità si attivano.
- Particelle delle gemme in un solo pacchetto (meno lag).

## Aggiornamento
- Danno in mischia: Mjölnir 12, Stormbreaker 15 (più forte del Mjölnir).
- Ricetta Stormbreaker (senza Tinkers): 3 blocchi di Uru a forma d'ascia, Stella del Nether al centro, verga di blaze come manico (`UU ` / `UN ` / ` R `).
- Con Tinkers' Construct: Matrice dello Stormbreaker + 6 secchi (6000 mB) di Uru fuso nel tavolo di colata. La Matrice si trova nelle casse dei fabbri dei villaggi (50%) insieme a quella del Mjölnir.

## Stormbreaker come il Mjölnir, occhiali E.D.I.T.H.
- **Stormbreaker** ridisegnato (martello a un lato, lama dall'altro, manico intrecciato) e ora funziona come il Mjölnir ma migliore: stessi tasti e poteri (tasto destro tenuto = gira/vola, Shift+destro = nome o gemme, Q = cade a terra e si riprende col destro, Z lancia, X richiama, C fulmine, H tempesta, F lancio istantaneo, Shift+F bloccato) più **Bifrost (O)** e **Super Fulmine** (tutti i fulmini x10, sbloccato dal raggio del Potere o con `/stormbreaker super`). Si possono inserire le gemme di Infinity (Shift+destro). Non si rompe mai. Mischia 15 (Mjölnir 12). Poteri Palladium anche per lo Stormbreaker.
- **Mjölnir:** con il tasto destro tenuto ruota nella mano (il manico resta nella mano, la testa gira) invece che davanti allo schermo.
- **Gemma del Potere:** niente più esplosioni vere; resta metà vita, onda di particelle viola e un effetto visivo di esplosione senza danni.
- **Occhiali E.D.I.T.H.** (ferro, diamante, 2 pannelli di vetro: `IDI` / `G G`): nello slot dell'elmo mostrano il visore (bussola, coordinate, Shift+F scansione dei mob).
- **Blocco di Uru:** basta il piccone di ferro (prima serviva il diamante).

## Correzioni
- Le gemme inserite nello Stormbreaker ora si vedono sulla testa (come sul Mjölnir).
- Bifrost: se non guardi nulla di solido ti porta a 60 blocchi (non oltre i chunk caricati).
