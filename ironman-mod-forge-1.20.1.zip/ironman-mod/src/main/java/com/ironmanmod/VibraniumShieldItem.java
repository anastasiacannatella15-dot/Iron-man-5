package com.ironmanmod;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;

/** Scudo di ferro e vibranio (Captain America): tieni premuto il tasto destro per pararti, come uno scudo normale ma resistentissimo. */
public class VibraniumShieldItem extends Item {
    public VibraniumShieldItem() {
        super(new Item.Properties().durability(2500).rarity(Rarity.EPIC).fireResistant());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        p.startUsingItem(hand);
        return InteractionResultHolder.consume(st);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BLOCK;
    }

    @Override
    public boolean canPerformAction(ItemStack stack, ToolAction action) {
        return ToolActions.DEFAULT_SHIELD_ACTIONS.contains(action);
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repair) {
        return repair.is(ModContent.VIBRANIUM_INGOT.get());
    }

    @Override
    public int getEnchantmentValue() {
        return 14;
    }
}
