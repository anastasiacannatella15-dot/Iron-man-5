package com.ironmanmod;

import com.ironmanmod.net.Net;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

@Mod(IronManMod.MODID)
public class IronManMod {
    public static final String MODID = "ironmanmod";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<net.minecraft.world.entity.EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<SuitMark, Map<ArmorItem.Type, RegistryObject<Item>>> ARMOR = new EnumMap<>(SuitMark.class);
    public static final Map<SuitMark, RegistryObject<Item>> REACTORS = new EnumMap<>(SuitMark.class);

    static {
        for (SuitMark m : SuitMark.values()) {
            Map<ArmorItem.Type, RegistryObject<Item>> pieces = new EnumMap<>(ArmorItem.Type.class);
            for (ArmorItem.Type t : ArmorItem.Type.values()) {
                if (m.classic) {
                    pieces.put(t, ITEMS.register(m.id + "_" + t.getName(), () -> new HeroArmorItem(m, t)));
                } else {
                    pieces.put(t, ITEMS.register(m.id + "_" + t.getName(), () -> new SuitArmorItem(m, t)));
                }
            }
            ARMOR.put(m, pieces);
            if (!m.classic) { // le armature normali non hanno nanotech, quindi niente reattore
                REACTORS.put(m, ITEMS.register("arc_reactor_" + m.id, () -> new ReactorItem(m)));
            }
        }
    }

    public static final RegistryObject<Item> MJOLNIR = ITEMS.register("mjolnir", MjolnirItem::new);
    public static final RegistryObject<Item> EDITH_GLASSES = ITEMS.register("edith_glasses", EdithGlassesItem::new);
    public static final RegistryObject<Item> STORMBREAKER = ITEMS.register("stormbreaker", StormbreakerItem::new);
    public static final RegistryObject<net.minecraft.world.entity.EntityType<MjolnirEntity>> MJOLNIR_ENTITY = ENTITIES.register("mjolnir",
            () -> net.minecraft.world.entity.EntityType.Builder.<MjolnirEntity>of(MjolnirEntity::new, net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.7f, 1.0f).clientTrackingRange(10).updateInterval(1).fireImmune().build("mjolnir"));

    public static final RegistryObject<net.minecraft.world.entity.EntityType<SentinelEntity>> SENTINEL = ENTITIES.register("sentinel",
            () -> net.minecraft.world.entity.EntityType.Builder.<SentinelEntity>of(SentinelEntity::new, net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.6f, 1.9f).clientTrackingRange(10).fireImmune().build("sentinel"));

    public static final RegistryObject<net.minecraft.world.entity.EntityType<ThanosEntity>> THANOS = ENTITIES.register("thanos",
            () -> net.minecraft.world.entity.EntityType.Builder.<ThanosEntity>of(ThanosEntity::new, net.minecraft.world.entity.MobCategory.MONSTER)
                    .sized(0.9f, 2.9f).clientTrackingRange(12).fireImmune().build("thanos"));
    public static final RegistryObject<net.minecraft.world.entity.EntityType<UltronEntity>> ULTRON = ENTITIES.register("ultron",
            () -> net.minecraft.world.entity.EntityType.Builder.<UltronEntity>of(UltronEntity::new, net.minecraft.world.entity.MobCategory.MONSTER)
                    .sized(0.6f, 1.95f).clientTrackingRange(10).fireImmune().build("ultron"));
    public static final RegistryObject<net.minecraft.world.entity.EntityType<ShieldEntity>> SHIELD = ENTITIES.register("thrown_shield",
            () -> net.minecraft.world.entity.EntityType.Builder.<ShieldEntity>of(ShieldEntity::new, net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.6f, 0.3f).clientTrackingRange(10).updateInterval(1).fireImmune().build("thrown_shield"));
    public static final RegistryObject<Item> BRIEFCASE = ITEMS.register("mark5_briefcase", BriefcaseItem::new);
    public static final RegistryObject<Item> BRIEFCASE_OPEN = ITEMS.register("mark5_briefcase_open", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<net.minecraft.world.entity.EntityType<BriefcaseEntity>> BRIEFCASE_ENTITY = ENTITIES.register("briefcase",
            () -> net.minecraft.world.entity.EntityType.Builder.<BriefcaseEntity>of(BriefcaseEntity::new, net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.9f, 0.3f).clientTrackingRange(10).updateInterval(1).fireImmune().build("briefcase"));
    public static final RegistryObject<Item> BRACELETS = ITEMS.register("mark7_bracelets", BraceletItem::new);
    public static final RegistryObject<Item> SLING_RING = ITEMS.register("sling_ring", SlingRingItem::new);
    public static final RegistryObject<Item> THANOS_EGG = ITEMS.register("thanos_spawn_egg",
            () -> new net.minecraftforge.common.ForgeSpawnEggItem(THANOS, 0x6b4a9c, 0xd4a017, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.ironmanmod"))
                    .icon(() -> new ItemStack(REACTORS.get(SuitMark.MARK_85).get()))
                    .displayItems((params, out) -> {
                        for (SuitMark cm : SuitMark.values()) if (cm.classic && cm != SuitMark.MARK_5 && cm != SuitMark.MARK_7 && cm != SuitMark.HULK) for (RegistryObject<Item> a : ARMOR.get(cm).values()) out.accept(a.get());
                        for (RegistryObject<Item> r : REACTORS.values()) out.accept(r.get());
                        out.accept(MJOLNIR.get());
                        out.accept(STORMBREAKER.get());
                        out.accept(EDITH_GLASSES.get());
                        out.accept(ModContent.MJOLNIR_CAST.get());
                        out.accept(ModContent.STORMBREAKER_CAST.get());
                        out.accept(ModContent.URU_INGOT.get());
                        out.accept(ModContent.TITANIUM_INGOT.get());
                        out.accept(ModContent.TITANIUM_SWORD.get());
                        out.accept(ModContent.TITANIUM_PICKAXE.get());
                        out.accept(ModContent.TITANIUM_AXE.get());
                        out.accept(ModContent.TITANIUM_SHOVEL.get());
                        out.accept(ModContent.TITANIUM_HOE.get());
                        out.accept(ModContent.MOLTEN_TITANIUM_BUCKET.get());
                        out.accept(ModContent.TITANIUM_ORE_ITEM.get());
                        out.accept(ModContent.URU_BLOCK_ITEM.get());
                        out.accept(ModContent.MOLTEN_URU_BUCKET.get());
                        out.accept(ModContent.VIBRANIUM_ORE_ITEM.get());
                        out.accept(ModContent.VIBRANIUM_INGOT.get());
                        out.accept(ModContent.VIBRANIUM_SHIELD.get());
                        out.accept(ModContent.EMPTY_SYRINGE.get());
                        out.accept(ModContent.THOR_SERUM.get());
                        out.accept(ModContent.SOLDIER_SERUM.get());
                        out.accept(ModContent.GAMMA_SERUM.get());
                        out.accept(BRIEFCASE.get());
                        out.accept(BRACELETS.get());
                        out.accept(SLING_RING.get());
                        out.accept(THANOS_EGG.get());
                        out.accept(ModContent.ULTRON_CORE.get());
                        out.accept(ModContent.ULTRON_MK2_CORE.get());
                        out.accept(ModContent.ULTRON_MK3_CORE.get());
                        out.accept(ModContent.ULTRON_PRIME_CORE.get());
                    })
                    .build());

    public IronManMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModContent.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        ENTITIES.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::init));
    }
}
