package com.ironmanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/**
 * Avengers Tower: piazza 25x25, 3 piani larghi (9), fusto di vetro (6), cima (4), corona (3), guglia con parafulmine.
 * Una "A" luminosa sulla facciata sud. Scala a pioli nel nucleo centrale, 2 bauli con bottino. Tutto deterministico.
 */
public class AvengersTowerPiece extends StructurePiece {
    static final int R = 12, H = 82;
    private static final ResourceLocation LOOT = new ResourceLocation(IronManMod.MODID, "chests/avengers_tower");
    private static final String[] A = {".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"};

    private final int cx, gy, cz;

    public AvengersTowerPiece(int x, int groundY, int z) {
        super(ModContent.TOWER_PIECE.get(), 0, new BoundingBox(x - R, groundY - 6, z - R, x + R, groundY + H, z + R));
        cx = x;
        gy = groundY;
        cz = z;
    }

    public AvengersTowerPiece(CompoundTag t) {
        super(ModContent.TOWER_PIECE.get(), t);
        cx = t.getInt("cx");
        gy = t.getInt("gy");
        cz = t.getInt("cz");
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext ctx, CompoundTag t) {
        t.putInt("cx", cx);
        t.putInt("gy", gy);
        t.putInt("cz", cz);
    }

    /** Mezza larghezza della torre all'altezza dy (-1 = non c'e'). */
    private static int hw(int dy) {
        if (dy <= 11) return 9;
        if (dy <= 41) return 6;
        if (dy <= 59) return 4;
        if (dy <= 65) return 3;
        return -1;
    }

    private static BlockState outside(int dy, int m) {
        return dy <= 6 && m <= R ? Blocks.AIR.defaultBlockState() : null; // libera la piazza da alberi e dossi
    }

    /** Blocco in (dx, dy, dz) relativi al centro della base; null = lascia il terreno com'e'. */
    private static BlockState pick(int dx, int dy, int dz) {
        int ax = Math.abs(dx), az = Math.abs(dz), m = Math.max(ax, az);
        if (dy < 0) return m <= R ? Blocks.STONE_BRICKS.defaultBlockState() : null;
        if (dy == 0) {
            if (m > R) return null;
            return ((dx + dz) & 1) == 0 ? Blocks.POLISHED_ANDESITE.defaultBlockState() : Blocks.STONE_BRICKS.defaultBlockState();
        }
        if (dy > 66) {
            if (m != 0 || dy > 80) return null;
            return dy == 80 ? Blocks.LIGHTNING_ROD.defaultBlockState() : Blocks.IRON_BARS.defaultBlockState();
        }
        if (dy <= 65 && ax <= 1 && az <= 1) return Blocks.POLISHED_ANDESITE.defaultBlockState(); // nucleo centrale
        if (dy <= 65 && dx == -2 && dz == 0) return Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.WEST);
        if (dy % 6 == 0) { // solaio
            int f = hw(dy - 1);
            if (m <= f) return Blocks.SMOOTH_QUARTZ.defaultBlockState();
            return outside(dy, m);
        }
        int h = hw(dy);
        if (m > h) return outside(dy, m);
        if (m < h) { // interno
            if (dy % 6 == 5 && ax == h - 1 && az == h - 1) return Blocks.SEA_LANTERN.defaultBlockState();
            return Blocks.AIR.defaultBlockState();
        }
        // perimetro
        if (ax == h && az == h) return Blocks.QUARTZ_PILLAR.defaultBlockState();
        if (h == 9 && dz == 9 && dy <= 3 && ax <= 1) return Blocks.AIR.defaultBlockState(); // ingresso
        if (h == 6 && dz == 6 && dx >= -2 && dx <= 2 && dy >= 19 && dy <= 25 && A[25 - dy].charAt(dx + 2) == '#') {
            return Blocks.SEA_LANTERN.defaultBlockState(); // la "A"
        }
        int r = dy % 6;
        if (r >= 2 && r <= 4 && ((dx + dz) & 3) != 0) return Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState();
        return Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
    }

    private void chest(WorldGenLevel level, BoundingBox box, RandomSource rnd, int dx, int dy, int dz) {
        BlockPos p = new BlockPos(cx + dx, gy + dy, cz + dz);
        if (!box.isInside(p)) return;
        level.setBlock(p, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.NORTH), 2);
        RandomizableContainerBlockEntity.setLootTable(level, rnd, p, LOOT);
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager sm, ChunkGenerator gen, RandomSource rnd,
                            BoundingBox box, ChunkPos cp, BlockPos pivot) {
        int x0 = Math.max(box.minX(), cx - R), x1 = Math.min(box.maxX(), cx + R);
        int z0 = Math.max(box.minZ(), cz - R), z1 = Math.min(box.maxZ(), cz + R);
        int y0 = Math.max(box.minY(), gy - 6), y1 = Math.min(box.maxY(), gy + H);
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int y = y0; y <= y1; y++) {
                    BlockState s = pick(x - cx, y - gy, z - cz);
                    if (s != null) level.setBlock(new BlockPos(x, y, z), s, 2);
                }
            }
        }
        chest(level, box, rnd, 5, 1, 5);   // atrio
        chest(level, box, rnd, 2, 61, 2);  // sala in cima
    }
}
