package com.ironmanmod;

import com.ironmanmod.net.Net;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

/**
 * Tutto lo stato dell'armatura vive nei dati persistenti del giocatore (NBT "IronManMod"):
 * selected, active, phase (0 nulla / 1 formazione / 2 ritiro), t, energy, orig (armatura originale), cd_*.
 */
public final class SuitData {
    public static final String ROOT = "IronManMod";

    static final EquipmentSlot[] SLOTS = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
    static final ArmorItem.Type[] TYPES = {ArmorItem.Type.BOOTS, ArmorItem.Type.LEGGINGS, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.HELMET};

    private static final DustParticleOptions GOLD = new DustParticleOptions(new Vector3f(1f, 0.75f, 0.15f), 1.1f);
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(0.85f, 0.1f, 0.12f), 1.1f);

    private SuitData() {
    }

    // ------------------------------------------------------------------ dati

    public static CompoundTag root(Player p) {
        CompoundTag pd = p.getPersistentData();
        if (!pd.contains(ROOT, Tag.TAG_COMPOUND)) pd.put(ROOT, new CompoundTag());
        return pd.getCompound(ROOT);
    }

    /** Il Mark 50 / 85 indossato nello slot del petto o in Curios (body), altrimenti null. */
    public static SuitMark wornReactor(Player p) {
        return ReactorLookup.mark(p);
    }

    public static SuitMark selected(Player p) {
        SuitMark worn = wornReactor(p);
        if (worn != null) return worn;
        CompoundTag r = root(p);
        SuitMark m = r.contains("selected") ? SuitMark.byNumber(r.getInt("selected")) : null;
        return m != null ? m : SuitMark.MARK_42;
    }

    /** Il modello attualmente indossato a trasformazione completata, altrimenti null. */
    public static SuitMark activeMark(Player p) {
        CompoundTag r = root(p);
        if (r.getInt("phase") == 0 && r.getInt("active") > 0) return SuitMark.byNumber(r.getInt("active"));
        if (r.getInt("phase") == 0) return classicSet(p);
        return null;
    }

    /** La Mark 42 e' un'armatura normale: i poteri valgono solo con tutti e 4 i pezzi indossati. */
    public static boolean hasMk42Set(Player p) {
        return classicSet(p) == SuitMark.MARK_42;
    }

    /** Il modello "normale" (Mark 2, 3, 5, 42) di cui indossi tutti e 4 i pezzi, altrimenti null. */
    public static SuitMark classicSet(Player p) {
        for (SuitMark m : SuitMark.values()) {
            if (!m.classic || m == SuitMark.HULK) continue; // il Hulk non e' un'armatura con HUD e volo
            boolean all = true;
            for (int i = 0; i < 4 && all; i++) {
                if (p.getItemBySlot(SLOTS[i]).getItem() != IronManMod.ARMOR.get(m).get(TYPES[i]).get()) all = false;
            }
            if (all) return m;
        }
        return null;
    }

    public static boolean owns(Player p, SuitMark m) {
        if (!Config.REQUIRE_REACTOR.get()) return true;
        return wornReactor(p) == m;
    }

    private static int ownedMask(Player p) {
        int mask = 0;
        for (SuitMark m : SuitMark.values()) {
            if (owns(p, m)) mask |= 1 << m.ordinal();
        }
        return mask;
    }

    public static void msg(ServerPlayer p, String key, Object... args) {
        p.displayClientMessage(Component.translatable(key, args), true);
    }

    public static boolean isSuit(ItemStack s) {
        return s.getItem() instanceof SuitArmorItem;
    }

    // ------------------------------------------------------------------ azioni dai tasti

    public static void handleAction(ServerPlayer p, int action) {
        switch (action) {
            case Net.A_TRANSFORM -> toggle(p);
            case Net.A_CYCLE -> cycle(p);
            case Net.A_REPULSOR -> {
                if (Hulk.isHulk(p) || classicSet(p) == SuitMark.MARK_44) Hulk.leap(p);
                else Powers.repulsor(p);
            }
            case Net.A_UNIBEAM -> Powers.unibeam(p);
            case Net.A_MISSILES -> Powers.missiles(p);
            case Net.A_SENTINEL -> Sentinel.activate(p);
            default -> {
                if (Mjolnir.isAction(action)) Mjolnir.handleAction(p, action);
            }
        }
    }

    private static void cycle(ServerPlayer p) {
        CompoundTag r = root(p);
        if (r.getInt("phase") != 0 || r.getInt("active") > 0) {
            msg(p, "msg.ironmanmod.remove_first");
            return;
        }
        SuitMark[] all = SuitMark.values();
        int cur = selected(p).ordinal();
        for (int i = 1; i <= all.length; i++) {
            SuitMark c = all[(cur + i) % all.length];
            if (!c.classic && owns(p, c)) {
                r.putInt("selected", c.number);
                msg(p, "msg.ironmanmod.selected", c.number);
                return;
            }
        }
        msg(p, "msg.ironmanmod.need_reactor", selected(p).number);
    }

    private static void toggle(ServerPlayer p) {
        CompoundTag r = root(p);
        if (r.getInt("phase") != 0) return;

        if (r.getInt("active") == 0) {
            SuitMark m = wornReactor(p); // la nanotech parte solo con il Reattore Arc Mark 50 / 85 indossato
            if (m == null) {
                msg(p, "msg.ironmanmod.need_reactor_any");
                return;
            }
            // salva l'armatura originale e svuota gli slot (niente duplicazioni)
            boolean rc = p.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof ReactorItem; // reattore nel petto: resta li'
            r.putBoolean("rc", rc);
            ListTag orig = new ListTag();
            for (int i = 0; i < 4; i++) {
                if (rc && SLOTS[i] == EquipmentSlot.CHEST) continue;
                CompoundTag t = new CompoundTag();
                p.getItemBySlot(SLOTS[i]).save(t);
                t.putByte("Slot", (byte) i);
                orig.add(t);
                p.setItemSlot(SLOTS[i], ItemStack.EMPTY);
            }
            r.put("orig", orig);
            if (!r.contains("energy")) r.putInt("energy", m.maxEnergy);
            else r.putInt("energy", Math.min(r.getInt("energy"), m.maxEnergy));
            r.putInt("active", m.number);
            r.putInt("phase", 1);
            r.putInt("t", 0);
        } else {
            r.putInt("phase", 2);
            r.putInt("t", 0);
        }
    }

    // ------------------------------------------------------------------ tick

    public static void tick(ServerPlayer p) {
        CompoundTag r = root(p);
        int phase = r.getInt("phase");
        int active = r.getInt("active");

        if (phase == 1) formTick(p, r);
        else if (phase == 2) removeTick(p, r);
        else if (active > 0) suitTick(p, r, SuitMark.byNumber(active));
        else if (classicSet(p) != null) suitTick(p, r, classicSet(p));
        else if (r.getBoolean("fly")) revokeFlight(p, r); // tolta la Mark 42: niente piu' volo
        Powers.tick(p, r);

        if (p.tickCount % 10 == 0) sync(p);
    }

    private static final double[][] LIMBS = {
            {0, 1.75}, {-0.5, 1.4}, {0.5, 1.4}, {-0.55, 0.8}, {0.55, 0.8},
            {-0.2, 0.85}, {0.2, 0.85}, {-0.22, 0.1}, {0.22, 0.1}};

    /** Nanotech come in Infinity War: le particelle escono dal reattore sul petto e corrono lungo il corpo fino alle mani, ai piedi e alla testa. */
    private static void nanoParticles(ServerLevel lvl, ServerPlayer p, int t, int dur, boolean forming) {
        double prog = (double) t / dur;
        if (!forming) prog = 1.0 - prog;
        double front = Math.min(1.0, prog * 1.25);
        double yaw = Math.toRadians(p.yBodyRot);
        double lx = Math.cos(yaw), lz = Math.sin(yaw);
        double cx = p.getX(), cy = p.getY() + 1.3, cz = p.getZ();

        lvl.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 2, 0.12, 0.12, 0.12, 0.02);
        for (double[] l : LIMBS) {
            double tx = cx + lx * l[0], ty = p.getY() + l[1], tz = cz + lz * l[0];
            for (int k = 0; k < 3; k++) {
                double f = Math.max(0.0, front - p.getRandom().nextDouble() * 0.4);
                double x = cx + (tx - cx) * f, y = cy + (ty - cy) * f, z = cz + (tz - cz) * f;
                lvl.sendParticles(k == 1 ? RED : GOLD, x, y, z, 1, 0.1, 0.1, 0.1, 0.0);
            }
            double x = cx + (tx - cx) * front, y = cy + (ty - cy) * front, z = cz + (tz - cz) * front;
            lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 2, 0.08, 0.08, 0.08, 0.05);
        }
        // onda che parte dal reattore e si allarga, piu' spirale di nanoparticelle che sale lungo il corpo
        double ringR = (forming ? prog : 1.0 - prog) * 1.6;
        for (int i = 0; i < 14; i++) {
            double a = i * (Math.PI * 2.0 / 14) + t * 0.6;
            lvl.sendParticles(ParticleTypes.END_ROD, cx + Math.cos(a) * ringR, cy, cz + Math.sin(a) * ringR, 1, 0, 0, 0, 0);
        }
        for (int k = 0; k < 3; k++) {
            double a = prog * 14.0 + k * (Math.PI * 2.0 / 3);
            double hy = p.getY() + 0.1 + prog * 1.9;
            lvl.sendParticles(k == 1 ? RED : GOLD, cx + Math.cos(a) * 0.55, hy, cz + Math.sin(a) * 0.55, 1, 0.02, 0.02, 0.02, 0);
            lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, cx + Math.cos(a) * 0.55, hy, cz + Math.sin(a) * 0.55, 1, 0.05, 0.05, 0.05, 0.02);
        }
        // nube di nanoparticelle che avvolge il corpo
        for (int i = 0; i < 6; i++) {
            double a = p.getRandom().nextDouble() * Math.PI * 2.0;
            double rr = 0.35 + 0.25 * prog;
            double dy = (p.getRandom().nextDouble() - 0.5) * 2.0 * (0.3 + 0.9 * prog);
            lvl.sendParticles(forming ? GOLD : RED, cx + Math.cos(a) * rr, cy - 0.1 + dy, cz + Math.sin(a) * rr, 1, 0, 0, 0, 0);
        }
    }

    private static ItemStack suitStack(SuitMark m, int slotIdx) {
        return new ItemStack(IronManMod.ARMOR.get(m).get(TYPES[slotIdx]).get());
    }

    private static void formTick(ServerPlayer p, CompoundTag r) {
        SuitMark m = SuitMark.byNumber(r.getInt("active"));
        if (m == null) {
            r.putInt("phase", 0);
            r.putInt("active", 0);
            return;
        }
        int dur = Config.TRANSFORM_TICKS.get();
        int t = r.getInt("t") + 1;
        r.putInt("t", t);
        ServerLevel lvl = p.serverLevel();

        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 5, 4, false, false, false));
        nanoParticles(lvl, p, t, dur, true);

        if (t == 1) {
            Net.sendPose(p, -(dur + 6));
            lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.5f);
        }
        // la tuta compare tutta insieme (come in Fisk's Superheroes): subito la Mark, poi l'effetto nanotech
        if (t == 1) { // nessun pezzo nell'inventario: il Reattore Arc resta e l'armatura si vede intera
            setSuitTag(p, true);
            lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ARMOR_EQUIP_NETHERITE, SoundSource.PLAYERS, 1.0f, 1.3f);
            lvl.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1.2, p.getZ(), 1, 0, 0, 0, 0);
        }
        if (t >= dur) {
            r.putInt("phase", 0);
            r.putInt("t", 0);
            lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.2f);
            lvl.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
        }
    }

    private static void removeTick(ServerPlayer p, CompoundTag r) {
        int dur = Config.TRANSFORM_TICKS.get();
        int t = r.getInt("t") + 1;
        r.putInt("t", t);
        ServerLevel lvl = p.serverLevel();

        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 5, 4, false, false, false));
        nanoParticles(lvl, p, t, dur, false);

        if (t == 1) {
            Net.sendPose(p, -(dur + 6));
            lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 1.5f);
        }
        if (t == Math.max(1, dur / 2)) { // la tuta sparisce tutta insieme
            setSuitTag(p, false);
            for (int i = 0; i < 4; i++) {
                if (isSuit(p.getItemBySlot(SLOTS[i]))) p.setItemSlot(SLOTS[i], ItemStack.EMPTY);
            }
            lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ARMOR_EQUIP_NETHERITE, SoundSource.PLAYERS, 1.0f, 0.8f);
        }
        if (t >= dur) {
            for (int i = 0; i < 4; i++) {
                if (isSuit(p.getItemBySlot(SLOTS[i]))) p.setItemSlot(SLOTS[i], ItemStack.EMPTY);
            }
            setSuitTag(p, false);
            restoreOriginals(p, r);
            r.putBoolean("rc", false);
            r.putInt("phase", 0);
            r.putInt("t", 0);
            r.putInt("active", 0);
            revokeFlight(p, r);
        }
    }

    /** Rimette l'armatura che il giocatore aveva prima di trasformarsi. */
    public static void restoreOriginals(Player p, CompoundTag source) {
        ListTag orig = source.getList("orig", Tag.TAG_COMPOUND);
        for (int i = 0; i < 4; i++) {
            if (isSuit(p.getItemBySlot(SLOTS[i]))) p.setItemSlot(SLOTS[i], ItemStack.EMPTY);
        }
        for (Tag tag : orig) {
            CompoundTag c = (CompoundTag) tag;
            ItemStack s = ItemStack.of(c);
            int i = c.getByte("Slot");
            if (s.isEmpty() || i < 0 || i > 3) continue;
            if (p.getItemBySlot(SLOTS[i]).isEmpty()) {
                p.setItemSlot(SLOTS[i], s);
            } else if (!p.getInventory().add(s)) {
                p.drop(s, false);
            }
        }
        source.remove("orig");
    }

    /** Accende/spegne l'aspetto della tuta sul Reattore Arc (nello slot petto o in Curios). */
    static void setSuitTag(Player p, boolean on) {
        ItemStack c = p.getItemBySlot(EquipmentSlot.CHEST);
        if (c.getItem() instanceof ReactorItem) {
            if (on) c.getOrCreateTag().putBoolean("Suit", true);
            else if (c.getTag() != null) c.getTag().remove("Suit");
        } else {
            ItemStack cu = ReactorLookup.curios(p, x -> x.getItem() instanceof ReactorItem);
            if (cu.getItem() instanceof ReactorItem) {
                if (on) cu.getOrCreateTag().putBoolean("Suit", true);
                else if (cu.getTag() != null) cu.getTag().remove("Suit");
            }
        }
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.items.size(); i++) {
            ItemStack x = inv.items.get(i);
            if (x.getItem() instanceof ReactorItem && x.getTag() != null) x.getTag().remove("Suit");
        }
        if (!on) setCuriosArmor(p, null);
    }

    private static final java.util.UUID ARMOR_ID = java.util.UUID.fromString("5b0f2c1e-6a1d-4c55-9a52-1e7a0c1d0001");
    private static final java.util.UUID TOUGH_ID = java.util.UUID.fromString("5b0f2c1e-6a1d-4c55-9a52-1e7a0c1d0002");
    private static final java.util.UUID KB_ID = java.util.UUID.fromString("5b0f2c1e-6a1d-4c55-9a52-1e7a0c1d0003");

    /** Reattore in Curios (non nel petto): la protezione 30 / 27 arriva da modificatori; null = li toglie. */
    static void setCuriosArmor(Player p, SuitMark m) {
        var armor = p.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR);
        var tough = p.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS);
        var kb = p.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE);
        if (armor == null || tough == null || kb == null) return;
        if (m == null) {
            armor.removeModifier(ARMOR_ID);
            tough.removeModifier(TOUGH_ID);
            kb.removeModifier(KB_ID);
            return;
        }
        if (armor.getModifier(ARMOR_ID) == null) {
            armor.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(ARMOR_ID, "ironman_reactor", m == SuitMark.MARK_85 ? 30 : 27,
                    net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));
            tough.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(TOUGH_ID, "ironman_reactor", m.getToughness(),
                    net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));
            kb.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(KB_ID, "ironman_reactor", 1.0,
                    net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));
        }
    }

    private static void revokeFlight(ServerPlayer p, CompoundTag r) {
        if (r.getBoolean("fly") && !p.isCreative() && !p.isSpectator()) {
            net.minecraft.world.entity.player.Abilities ab = p.getAbilities();
            ab.mayfly = false;
            ab.flying = false;
            ab.setFlyingSpeed(0.05f);
            p.onUpdateAbilities();
        }
        r.putBoolean("fly", false);
    }

    /** Impedisce di togliere/perdere i pezzi nanotech mentre l'armatura e' attiva. */
    private static void enforce(ServerPlayer p, SuitMark m) {
        CompoundTag rr = root(p);
        boolean inChest = p.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof ReactorItem;
        boolean inCurios = !inChest && ReactorLookup.curios(p, x -> x.getItem() instanceof ReactorItem).getItem() instanceof ReactorItem;
        if (!inChest && !inCurios) { // il reattore non c'e' piu': la tuta si ritira subito
            setSuitTag(p, false);
            restoreOriginals(p, rr);
            rr.putBoolean("rc", false);
            rr.putInt("active", 0);
            revokeFlight(p, rr);
            return;
        }
        rr.putBoolean("rc", inChest);
        if (inCurios) setCuriosArmor(p, m); else setCuriosArmor(p, null);
        ItemStack rs = inChest ? p.getItemBySlot(EquipmentSlot.CHEST) : ReactorLookup.curios(p, x -> x.getItem() instanceof ReactorItem);
        if (rr.getInt("phase") != 2 && !ReactorItem.suitOn(rs)) setSuitTag(p, true);
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.items.size(); i++) {
            if (isSuit(inv.items.get(i))) inv.items.set(i, ItemStack.EMPTY);
        }
        for (int i = 0; i < inv.offhand.size(); i++) {
            if (isSuit(inv.offhand.get(i))) inv.offhand.set(i, ItemStack.EMPTY);
        }
        if (isSuit(p.containerMenu.getCarried())) p.containerMenu.setCarried(ItemStack.EMPTY);
    }

    private static void suitTick(ServerPlayer p, CompoundTag r, SuitMark m) {
        if (m == null) {
            r.putInt("active", 0);
            return;
        }
        if (!m.classic && p.tickCount % 5 == 0) enforce(p, m); // le armature normali non hanno nanotech

        boolean creative = p.isCreative() || p.isSpectator();
        net.minecraft.world.entity.player.Abilities ab = p.getAbilities();
        int e = r.getInt("energy");

        if (!creative) {
            boolean flying = ab.flying && !p.onGround();
            if (flying) e -= p.isSprinting() ? 4 : 1;
            else if (p.onGround()) e += 4;
            else e += 1;
            e = Mth.clamp(e, 0, m.maxEnergy);

            boolean can = m.flySpeed > 0f && (ab.mayfly ? e > 0 : e >= 100);
            if (ab.mayfly != can || Math.abs(ab.getFlyingSpeed() - m.flySpeed) > 1.0E-4f) {
                ab.mayfly = can;
                if (!can) ab.flying = false;
                ab.setFlyingSpeed(m.flySpeed);
                p.onUpdateAbilities();
            }
            r.putBoolean("fly", true);
        }
        r.putInt("energy", e);

        if (p.tickCount % 20 == 0) {
            // visore del casco
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0, true, false, false));
            if (m == SuitMark.MARK_44) { // Hulkbuster: salti potenti e forza
                p.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, 2, true, false, false));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 1, true, false, false));
            }
        }
    }

    // ------------------------------------------------------------------ energia / cooldown

    public static boolean useEnergy(ServerPlayer p, int cost) {
        if (p.isCreative()) return true;
        CompoundTag r = root(p);
        int e = r.getInt("energy");
        if (e < cost) return false;
        r.putInt("energy", e - cost);
        return true;
    }

    public static boolean ready(ServerPlayer p, String key) {
        return p.level().getGameTime() >= root(p).getLong("cd_" + key);
    }

    public static void setCooldown(ServerPlayer p, String key, int ticks) {
        root(p).putLong("cd_" + key, p.level().getGameTime() + ticks);
    }

    // ------------------------------------------------------------------ sync verso il client

    public static void sync(ServerPlayer p) {
        CompoundTag r = root(p);
        int active = r.getInt("active");
        if (active == 0 && r.getInt("phase") == 0 && classicSet(p) != null) active = classicSet(p).number;
        SuitMark sel = selected(p);
        SuitMark shown = active > 0 && SuitMark.byNumber(active) != null ? SuitMark.byNumber(active) : sel;

        int energy = r.contains("energy") ? r.getInt("energy") : shown.maxEnergy;
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p),
                new Net.SyncPacket(active, sel.number, r.getInt("phase"), r.getInt("t"),
                        Config.TRANSFORM_TICKS.get(), energy, shown.maxEnergy, ownedMask(p)));
    }
}
