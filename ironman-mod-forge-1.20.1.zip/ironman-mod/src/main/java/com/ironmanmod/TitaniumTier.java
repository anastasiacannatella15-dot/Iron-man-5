package com.ironmanmod;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Titanio: piu' forte del ferro, meno del diamante. */
public enum TitaniumTier implements Tier {
    INSTANCE;

    @Override
    public int getUses() {
        return 900; // ferro 250, diamante 1561
    }

    @Override
    public float getSpeed() {
        return 7.0f; // ferro 6, diamante 8
    }

    @Override
    public float getAttackDamageBonus() {
        return 2.5f; // ferro 2, diamante 3
    }

    @Override
    public int getLevel() {
        return 2; // come il ferro: miniera diamanti, non ossidiana
    }

    @Override
    public int getEnchantmentValue() {
        return 14;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(ModContent.TITANIUM_INGOT.get());
    }
}
