package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SentinelEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/** La sentinella: un corpo scuro che indossa i 4 pezzi dell'armatura Iron Man (con le texture dell'armatura). */
public class SentinelRenderer extends HumanoidMobRenderer<SentinelEntity, HumanoidModel<SentinelEntity>> {
    private static final ResourceLocation TEX = new ResourceLocation(IronManMod.MODID, "textures/entity/sentinel_base.png");

    public SentinelRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
        getModel().hat.visible = false;
        addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE_INNER_ARMOR)),
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(SentinelEntity e) {
        return TEX;
    }
}
