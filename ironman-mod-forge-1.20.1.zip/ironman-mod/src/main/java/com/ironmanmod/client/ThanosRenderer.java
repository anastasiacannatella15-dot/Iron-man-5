package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.ThanosEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Thanos: corpo da giocatore ingrandito, viola con l'armatura; con il guanto la mano sinistra e' dorata con le gemme. */
public class ThanosRenderer extends HumanoidMobRenderer<ThanosEntity, HumanoidModel<ThanosEntity>> {
    private static final ResourceLocation PLAIN = new ResourceLocation(IronManMod.MODID, "textures/entity/thanos.png");
    private static final ResourceLocation GLOVE = new ResourceLocation(IronManMod.MODID, "textures/entity/thanos_gauntlet.png");

    public ThanosRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.9f);
        getModel().hat.visible = false;
    }

    @Override
    protected void scale(ThanosEntity e, PoseStack ps, float partialTick) {
        ps.scale(1.35f, 1.35f, 1.35f);
    }

    @Override
    public void render(ThanosEntity e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        // quando si riprende il guanto la mano sinistra e' tesa verso di te
        model.leftArmPose = e.isReaching() ? HumanoidModel.ArmPose.BOW_AND_ARROW : HumanoidModel.ArmPose.EMPTY;
        super.render(e, yaw, partialTick, ps, buf, light);
    }

    @Override
    public ResourceLocation getTextureLocation(ThanosEntity e) {
        return e.hasGauntlet() ? GLOVE : PLAIN;
    }
}
