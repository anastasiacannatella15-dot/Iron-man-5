package com.ironmanmod.client;

import com.ironmanmod.ReactorLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;

import java.util.HashMap;
import java.util.Map;

/** La seconda mano occupata (oggetto in offhand o in Curios "hands"): l'armatura lascia libero il braccio sinistro. */
public final class ArmorHands {
    private static final TagKey<Item> HANDS = TagKey.create(Registries.ITEM, new ResourceLocation("curios", "hands"));
    private static final Map<Integer, long[]> CACHE = new HashMap<>(); // id -> {tick, valore}

    private ArmorHands() {
    }

    public static boolean leftBusy(LivingEntity e) {
        long[] c = CACHE.get(e.getId());
        if (c != null && c[0] == e.tickCount) return c[1] == 1L;
        boolean busy = !e.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty();
        if (!busy) busy = !ReactorLookup.curios(e, s -> !s.isEmpty() && s.is(HANDS)).isEmpty();
        CACHE.put(e.getId(), new long[]{e.tickCount, busy ? 1L : 0L});
        return busy;
    }
}
