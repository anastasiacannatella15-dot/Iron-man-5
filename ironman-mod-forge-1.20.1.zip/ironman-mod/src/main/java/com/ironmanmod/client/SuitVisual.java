package com.ironmanmod.client;

import com.ironmanmod.ReactorItem;
import com.ironmanmod.ReactorLookup;
import com.ironmanmod.SuitMark;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Map;

/** Quale armatura nanotech si vede addosso a un giocatore (il Reattore Arc resta nello slot petto o in Curios). */
public final class SuitVisual {
    private static final Map<Integer, Object[]> CACHE = new HashMap<>();

    private SuitVisual() {
    }

    public static SuitMark mark(Player p) {
        if (p == Minecraft.getInstance().player) {
            // per te: lo stato sincronizzato dal server (sparisce quando la tuta si ritira)
            if (ClientState.active > 0 && ClientState.phase != 2) {
                SuitMark m = SuitMark.byNumber(ClientState.active);
                return m != null && m.classic ? null : m; // l'armatura Iron Man e' fatta di pezzi veri
            }
            return null;
        }
        Object[] c = CACHE.get(p.getId());
        if (c != null && (int) c[0] == p.tickCount) return (SuitMark) c[1];
        SuitMark res = null;
        ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
        if (chest.getItem() instanceof ReactorItem ri && ReactorItem.suitOn(chest)) {
            res = ri.mark;
        } else {
            ItemStack cu = ReactorLookup.curios(p, s -> s.getItem() instanceof ReactorItem && ReactorItem.suitOn(s));
            if (cu.getItem() instanceof ReactorItem ri2) res = ri2.mark;
        }
        CACHE.put(p.getId(), new Object[]{p.tickCount, res});
        return res;
    }
}
