package com.ironmanmod.client;

import com.ironmanmod.SuitMark;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import org.joml.Vector3f;

/**
 * Schermata dell'assistente (F.R.I.D.A.Y. su Mark 50/85, J.A.R.V.I.S. sull'armatura Iron Man): bordo azzurro, esagono in
 * alto, scala dell'altitudine a sinistra, bussola, velocita', coordinate, energia, tasti e scansione dei mob.
 */
public final class FridayHud {
    private static final int C = 0x00D8FF;
    private static final int LINE = 0xFF40DCFF;

    private FridayHud() {
    }

    public static String aiName(SuitMark m) {
        if (m == null) return "E.D.I.T.H";
        return m.classic ? "J.A.R.V.I.S" : "F.R.I.D.A.Y";
    }

    private static void line(GuiGraphics g, int x1, int y1, int x2, int y2, int col) {
        int n = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));
        if (n == 0) {
            g.fill(x1, y1, x1 + 2, y1 + 2, col);
            return;
        }
        for (int i = 0; i <= n; i++) {
            int x = x1 + (x2 - x1) * i / n, y = y1 + (y2 - y1) * i / n;
            g.fill(x, y, x + 2, y + 2, col);
        }
    }

    public static void render(ForgeGui gui, GuiGraphics g, float pt, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || !ClientState.fridayOn) return;
        // visore: dall'armatura (FRIDAY / JARVIS) oppure dagli occhiali E.D.I.T.H.
        SuitMark mk = ClientState.phase == 0 && ClientState.active > 0 ? SuitMark.byNumber(ClientState.active) : null;
        if (mk == null && !glasses(mc)) return;
        if (!mc.options.getCameraType().isFirstPerson()) return;
        Font f = mc.font;

        // bordo azzurro "visore"
        for (int i = 0; i < 26; i++) {
            int a = (int) (0x46 * (1.0 - i / 26.0));
            int col = (a << 24) | C;
            g.fill(i, 0, i + 1, h, col);
            g.fill(w - 1 - i, 0, w - i, h, col);
            g.fill(0, i, w, i + 1, col);
            g.fill(0, h - 1 - i, w, h - i, col);
        }

        // esagono in alto
        int cx = w / 2;
        line(g, cx - 120, 0, cx - 86, 50, LINE);
        line(g, cx - 86, 50, cx + 86, 50, LINE);
        line(g, cx + 86, 50, cx + 120, 0, LINE);
        g.drawCenteredString(f, Component.literal(aiName(mk)), cx, 36, 0xFF8CE8FF);

        // scala dell'altitudine a sinistra
        double py = mc.player.getY();
        int lx = (int) (w * 0.12), mid = h / 2;
        double frac = py - Math.floor(py);
        for (int i = -8; i <= 8; i++) {
            int y = (int) (mid + i * 16 + frac * 16);
            int ya = (int) Math.floor(py) - i;
            boolean major = ya % 5 == 0;
            g.fill(lx, y, lx + (major ? 20 : 9), y + 1, LINE);
            if (major) g.drawString(f, Integer.toString(ya), lx + 24, y - 4, 0xFF60E0FF, false);
        }
        g.fill(lx - 10, mid - 1, lx - 2, mid + 2, 0xFFFFD040);

        // bussola in alto a destra
        int ccx = w - 70, ccy = 70, rad = 30;
        int prev_x = ccx + rad, prev_y = ccy;
        for (int i = 1; i <= 36; i++) {
            double a = i * Math.PI * 2 / 36;
            int x = ccx + (int) (Math.cos(a) * rad), y = ccy + (int) (Math.sin(a) * rad);
            line(g, prev_x, prev_y, x, y, LINE);
            prev_x = x;
            prev_y = y;
        }
        float yaw = mc.player.getYRot();
        String[] names = {"S", "W", "N", "E"};
        for (int i = 0; i < 4; i++) {
            double th = Math.toRadians(i * 90.0 - yaw);
            int x = ccx + (int) (Math.sin(th) * (rad + 11)), y = ccy - (int) (Math.cos(th) * (rad + 11));
            g.drawCenteredString(f, names[i], x, y - 4, "N".equals(names[i]) ? 0xFFFF5050 : 0xFF60E0FF);
        }
        g.fill(ccx - 1, ccy - rad + 2, ccx + 1, ccy, 0xFFFFD040);

        // velocita' e coordinate
        Vec3 v = mc.player.getDeltaMovement();
        int kmh = (int) (Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) * 20.0 * 3.6);
        g.pose().pushPose();
        g.pose().scale(2f, 2f, 1f);
        g.drawString(f, kmh + " km/h", (int) ((w - 150) / 2f), (int) ((h * 0.40f) / 2f), 0xFF60E0FF, false);
        g.pose().popPose();
        g.drawString(f, "X: " + (int) mc.player.getX(), w - 120, (int) (h * 0.40f) + 24, 0xFF60E0FF, false);
        g.drawString(f, "Y: " + (int) mc.player.getY(), w - 120, (int) (h * 0.40f) + 34, 0xFF60E0FF, false);
        g.drawString(f, "Z: " + (int) mc.player.getZ(), w - 120, (int) (h * 0.40f) + 44, 0xFF60E0FF, false);

        // energia a quadratini (solo con l'armatura)
        if (mk != null) energyBar(g, f, w, h);
        else g.drawString(f, aiName(null), w - 150, (int) (h * 0.40f) + 62, 0xFF60E8FF, false);
        hints(g, f, mc, mk);
        scan(g, f, mc, w, h, pt);
    }

    public static boolean glasses(Minecraft mc) {
        return mc.player != null && mc.player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).getItem() instanceof com.ironmanmod.EdithGlassesItem;
    }

    private static void energyBar(GuiGraphics g, Font f, int w, int h) {
        SuitMark mk = ClientState.activeMark();
        if (mk == null) return;
        float en = Math.min(1f, ClientState.energy / (float) ClientState.maxEnergy);
        int bx = w - 150, by = (int) (h * 0.40f) + 62;
        for (int i = 0; i < 18; i++) {
            boolean on = i < Math.round(en * 18);
            g.fill(bx + i * 7, by, bx + i * 7 + 5, by + 4, on ? (en > 0.25f ? 0xFF40DCFF : 0xFFFF4040) : 0x6640DCFF);
        }
        g.pose().pushPose();
        g.pose().scale(1.5f, 1.5f, 1f);
        g.drawString(f, aiName(mk), (int) ((w - 150) / 1.5f), (int) ((by + 14) / 1.5f), 0xFF60E8FF, false);
        g.pose().popPose();
    }

    private static void hints(GuiGraphics g, Font f, Minecraft mc, SuitMark mk) {
        if (mc.options.keyShift.isDown()) return; // i tasti si nascondono tenendo premuto Shift
        int y = 56;
        if (mk != null) {
            y = hint(g, f, ClientModBus.REPULSOR.getTranslatedKeyMessage().getString(), "key.ironmanmod.repulsor", x0(), y);
            if (mk.unibeamDamage > 0f) y = hint(g, f, ClientModBus.UNIBEAM.getTranslatedKeyMessage().getString(), "key.ironmanmod.unibeam", x0(), y);
            y = hint(g, f, ClientModBus.MISSILES.getTranslatedKeyMessage().getString(), "key.ironmanmod.missiles", x0(), y);
            if (mk == SuitMark.MARK_42) y = hint(g, f, ClientModBus.SENTINEL.getTranslatedKeyMessage().getString(), "key.ironmanmod.sentinel", x0(), y);
            y = hint(g, f, "Shift+" + ClientModBus.UNIBEAM.getTranslatedKeyMessage().getString(), null, x0(), y, aiName(mk));
        }
        hint(g, f, "Shift+" + ClientModBus.SCAN.getTranslatedKeyMessage().getString(), "key.ironmanmod.scan", x0(), y);
    }

    private static int x0() {
        return 6;
    }

    private static int hint(GuiGraphics g, Font f, String key, String nameKey, int x, int y) {
        return hint(g, f, key, nameKey, x, y, null);
    }

    private static int hint(GuiGraphics g, Font f, String key, String nameKey, int x, int y, String literal) {
        Component name = nameKey != null ? Component.translatable(nameKey) : Component.literal(literal);
        Component line = Component.literal(key + " - ").append(name);
        g.fill(x - 2, y - 1, x + f.width(line) + 3, y + 9, 0x88202830);
        g.drawString(f, line, x, y, 0xFFFFE070, false);
        return y + 12;
    }

    // ---------------------------------------------------------------- scansione dei mob

    private static void scan(GuiGraphics g, Font f, Minecraft mc, int w, int h, float pt) {
        if (mc.level == null || mc.level.getGameTime() > ClientState.scanUntil) return;
        g.drawCenteredString(f, Component.translatable("hud.ironmanmod.scan"), w / 2, 56, 0xFFFFD040);
        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 cp = cam.getPosition();
        Vector3f look = cam.getLookVector(), up = cam.getUpVector(), left = cam.getLeftVector();
        double fov = Math.toRadians(mc.options.fov().get());
        double focal = (h / 2.0) / Math.tan(fov / 2.0);
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive()) continue;
            Vec3 pos = le.getPosition(pt).add(0, le.getBbHeight() / 2.0, 0);
            Vec3 rel = pos.subtract(cp);
            double dist = rel.length();
            if (dist > 64) continue;
            double fwd = rel.x * look.x + rel.y * look.y + rel.z * look.z;
            if (fwd < 0.5) continue;
            double lf = rel.x * left.x + rel.y * left.y + rel.z * left.z;
            double up2 = rel.x * up.x + rel.y * up.y + rel.z * up.z;
            int sx = (int) (w / 2.0 - lf / fwd * focal), sy = (int) (h / 2.0 - up2 / fwd * focal);
            int hw = Mth.clamp((int) (le.getBbWidth() * focal / fwd / 2), 6, 120);
            int hh = Mth.clamp((int) (le.getBbHeight() * focal / fwd / 2), 8, 160);
            if (sx < -hw || sx > w + hw || sy < -hh || sy > h + hh) continue;
            int col = le instanceof Enemy ? 0xFFFF4040 : (le instanceof net.minecraft.world.entity.player.Player ? 0xFF40A0FF : 0xFF40FF80);
            int k = Math.max(3, Math.min(hw, hh) / 3);
            // quattro angoli
            g.fill(sx - hw, sy - hh, sx - hw + k, sy - hh + 1, col);
            g.fill(sx - hw, sy - hh, sx - hw + 1, sy - hh + k, col);
            g.fill(sx + hw - k, sy - hh, sx + hw, sy - hh + 1, col);
            g.fill(sx + hw - 1, sy - hh, sx + hw, sy - hh + k, col);
            g.fill(sx - hw, sy + hh - 1, sx - hw + k, sy + hh, col);
            g.fill(sx - hw, sy + hh - k, sx - hw + 1, sy + hh, col);
            g.fill(sx + hw - k, sy + hh - 1, sx + hw, sy + hh, col);
            g.fill(sx + hw - 1, sy + hh - k, sx + hw, sy + hh, col);
            String label = le.getName().getString() + "  " + (int) Math.ceil(le.getHealth()) + "/" + (int) le.getMaxHealth()
                    + "  " + (int) dist + "m";
            g.drawString(f, label, sx - hw, sy - hh - 10, col, true);
        }
    }
}
