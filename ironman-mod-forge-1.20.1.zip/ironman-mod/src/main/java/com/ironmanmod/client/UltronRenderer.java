package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.UltronEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Ultron: corpo umanoide metallico, una texture per forma, piu' grande a ogni evoluzione. */
public class UltronRenderer extends HumanoidMobRenderer<UltronEntity, HumanoidModel<UltronEntity>> {
    private static final ResourceLocation[] TEX = new ResourceLocation[4];

    static {
        for (int i = 0; i < 4; i++) TEX[i] = new ResourceLocation(IronManMod.MODID, "textures/entity/ultron_" + i + ".png");
    }

    public UltronRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
        getModel().hat.visible = false;
    }

    @Override
    protected void scale(UltronEntity e, PoseStack ps, float partialTick) {
        float s = e.bodyScale();
        ps.scale(s, s, s);
    }

    @Override
    public ResourceLocation getTextureLocation(UltronEntity e) {
        return TEX[e.getVariant()];
    }
}
