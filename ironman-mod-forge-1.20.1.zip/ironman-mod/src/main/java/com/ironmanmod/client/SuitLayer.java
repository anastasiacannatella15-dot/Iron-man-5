package com.ironmanmod.client;

import com.ironmanmod.SuitMark;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/** Disegna l'armatura nanotech intera addosso al giocatore: nessun pezzo e' nell'inventario, il Reattore Arc resta dov'e'. */
public class SuitLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public SuitLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        SuitMark m = SuitVisual.mark(p);
        if (m == null || p.isInvisible()) return;
        HumanoidModel<LivingEntity> model = SuitModels.getFull(m.id);
        @SuppressWarnings("unchecked")
        HumanoidModel<AbstractClientPlayer> asPlayer = (HumanoidModel<AbstractClientPlayer>) (HumanoidModel<?>) model;
        getParentModel().copyPropertiesTo(asPlayer);
        model.leftArm.visible = !ArmorHands.leftBusy(p);
        ResourceLocation tex = new ResourceLocation("ironmanmod", "textures/models/armor/" + m.id + "_model.png");
        VertexConsumer vc = buf.getBuffer(RenderType.armorCutoutNoCull(tex));
        model.renderToBuffer(ps, vc, light, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
    }
}
