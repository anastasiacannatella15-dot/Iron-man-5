package com.ironmanmod.client;

import com.ironmanmod.MjolnirEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;

/** Disegna il Mjolnir con il suo modello 3D: in piedi sulla testa a terra, o che ruota quando vola. */
public class MjolnirRenderer extends EntityRenderer<MjolnirEntity> {
    public MjolnirRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.4f;
    }

    @Override
    public void render(MjolnirEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        float scale = 0.8f;
        if (e.getState() == MjolnirEntity.STANDING) {
            ps.translate(0, 0.5 * scale, 0);
            ps.mulPose(Axis.YP.rotationDegrees(yaw));
            ps.mulPose(Axis.ZP.rotationDegrees(180f)); // testa in basso, manico in alto
        } else {
            ps.translate(0, 0.4, 0);
            ps.mulPose(Axis.YP.rotationDegrees(-e.getYRot()));
            ps.mulPose(Axis.XP.rotationDegrees((e.tickCount + pt) * 45f)); // gira in volo
        }
        ps.scale(scale, scale, scale);
        Minecraft.getInstance().getItemRenderer().renderStatic(e.getStack(), ItemDisplayContext.FIXED, light,
                OverlayTexture.NO_OVERLAY, ps, buf, e.level(), e.getId());
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    @Override
    public ResourceLocation getTextureLocation(MjolnirEntity e) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
