package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitMark;
import com.ironmanmod.net.Net;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = IronManMod.MODID, value = Dist.CLIENT)
public class ClientForgeBus {
    private static boolean mjFlying;

    private static void poll(KeyMapping key, int action, boolean canSend) {
        while (key.consumeClick()) {
            if (canSend) Net.sendAction(action);
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        boolean can = mc.screen == null;
        poll(ClientModBus.TRANSFORM, Net.A_TRANSFORM, can);
        // Repulsore: tenendo premuto il tasto il raggio riparte e il braccio resta alzato
        boolean holding = ClientModBus.REPULSOR.isDown();
        while (ClientModBus.REPULSOR.consumeClick()) {
            holding = true;
        }
        if (can && holding && mc.player.tickCount % 2 == 0) Net.sendAction(Net.A_REPULSOR);
        while (ClientModBus.UNIBEAM.consumeClick()) {
            if (!can) continue;
            if (mc.options.keyShift.isDown()) { // Shift + V: accende/spegne l'assistente (FRIDAY / JARVIS)
                ClientState.fridayOn = !ClientState.fridayOn;
            } else {
                Net.sendAction(Net.A_UNIBEAM);
            }
        }
        while (ClientModBus.SCAN.consumeClick()) {
            if (!can) continue;
            boolean hammer = mc.player.getMainHandItem().getItem() instanceof com.ironmanmod.MjolnirItem;
            if (hammer) { // con il Mjolnir in mano: F = lancio istantaneo, Shift+F = blocca/sblocca
                Net.sendAction(mc.options.keyShift.isDown() ? com.ironmanmod.Mjolnir.A_LOCK : com.ironmanmod.Mjolnir.A_STRIKE);
                continue;
            }
            // Shift + F: scansione dei mob
            if (mc.options.keyShift.isDown() && (ClientState.active > 0 || FridayHud.glasses(mc)) && ClientState.fridayOn) {
                boolean on = mc.level != null && mc.level.getGameTime() <= ClientState.scanUntil;
                ClientState.scanUntil = on || mc.level == null ? 0 : mc.level.getGameTime() + 200;
            }
        }
        poll(ClientModBus.SENTINEL, Net.A_SENTINEL, can);
        poll(ClientModBus.MISSILES, Net.A_MISSILES, can);
        poll(ClientModBus.MJ_THROW, com.ironmanmod.Mjolnir.A_THROW, can);
        poll(ClientModBus.MJ_RECALL, com.ironmanmod.Mjolnir.A_RECALL, can);
        poll(ClientModBus.MJ_BOLT, com.ironmanmod.Mjolnir.A_BOLT, can);
        poll(ClientModBus.MJ_STORM, com.ironmanmod.Mjolnir.A_STORM, can);
        while (ClientModBus.GEM.consumeClick()) { // K = potere della gemma, Shift + K = cambia gemma
            if (can) Net.sendAction(mc.options.keyShift.isDown() ? com.ironmanmod.GemPowers.A_GEM_CYCLE : com.ironmanmod.GemPowers.A_GEM);
        }
        poll(ClientModBus.SB_SUPER, com.ironmanmod.Stormbreaker.A_SUPER, can);
        poll(ClientModBus.SB_BIFROST, com.ironmanmod.Stormbreaker.A_BIFROST, can);

        // Mjolnir: tenendo premuto il tasto destro il martello gira; saltando si vola nella direzione in cui guardi
        boolean using = mc.player.isUsingItem() && mc.player.getUseItem().getItem() instanceof com.ironmanmod.MjolnirItem;
        if (!using || !mc.options.getCameraType().isFirstPerson()) { // in terza persona il martello gira ma non si vola
            mjFlying = false;
        } else if (can) {
            if (mc.options.keyJump.isDown()) mjFlying = true;
            else if (mc.player.onGround()) mjFlying = false;
            if (mjFlying) {
                mc.player.setDeltaMovement(mc.player.getLookAngle().scale(mc.options.keySprint.isDown() ? 1.6 : 1.0));
                mc.player.fallDistance = 0f;
            }
        }

        // Volo veloce: sprint + avanti mentre voli = spinta nella direzione in cui guardi
        SuitMark m = ClientState.activeMark();
        if (can && m != null && ClientState.energy > 0
                && mc.player.getAbilities().flying
                && mc.options.keySprint.isDown() && mc.options.keyUp.isDown()) {
            mc.player.setSprinting(true);
            Vec3 look = mc.player.getLookAngle();
            mc.player.setDeltaMovement(look.scale(m.boost));
        }
    }
}
