package com.ironmanmod.client;

import com.ironmanmod.ShieldEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;

/** Lo scudo lanciato: disco piatto che gira come un frisbee. */
public class ShieldRenderer extends EntityRenderer<ShieldEntity> {
    public ShieldRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.2f;
    }

    @Override
    public void render(ShieldEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        ps.translate(0, 0.25, 0);
        ps.mulPose(Axis.XP.rotationDegrees(90f)); // steso in orizzontale
        ps.mulPose(Axis.ZP.rotationDegrees((e.tickCount + pt) * 50f)); // gira
        ps.scale(1.3f, 1.3f, 1.3f);
        Minecraft.getInstance().getItemRenderer().renderStatic(e.getStack(), ItemDisplayContext.FIXED, light,
                OverlayTexture.NO_OVERLAY, ps, buf, e.level(), e.getId());
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    @Override
    public ResourceLocation getTextureLocation(ShieldEntity e) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
