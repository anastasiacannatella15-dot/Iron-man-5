package com.ironmanmod.client;

import com.ironmanmod.HeroArmorItem;
import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitMark;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hulk e Hulkbuster sono piu' grandi degli altri giocatori. */
@Mod.EventBusSubscriber(modid = IronManMod.MODID, value = Dist.CLIENT)
public class GiantRender {
    @SubscribeEvent
    public static void onPre(RenderPlayerEvent.Pre e) {
        if (!(e.getEntity().getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof HeroArmorItem h)) return;
        if (h.mark == SuitMark.HULK) e.getPoseStack().scale(1.4f, 1.4f, 1.4f);
        else if (h.mark == SuitMark.MARK_44) e.getPoseStack().scale(1.65f, 1.65f, 1.65f);
    }
}
