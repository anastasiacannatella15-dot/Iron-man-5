package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitMark;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;

/**
 * Modelli delle armature: usano il layout di una skin 64x64 (le skin disegnate dall'utente) su un corpo leggermente
 * gonfiato, cosi' la texture e' esattamente quella della skin. Il casco disegna la testa, il pettorale corpo e braccia,
 * i gambali le gambe (gli stivali sono gia' nelle gambe della skin).
 */
public final class SuitModels {
    public static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    public static final String[] IDS = {"mark42", "mark50", "mark85", "mark2", "mark3", "mark5"};
    private static final String[] PARTS = {"head", "hat", "body", "right_arm", "left_arm", "right_leg", "left_leg"};
    private static final Map<String, HumanoidModel<LivingEntity>> CACHE = new HashMap<>();
    private static final float G = 0.5f;

    private SuitModels() {
    }

    public static ModelLayerLocation loc(String id, EquipmentSlot s) {
        return new ModelLayerLocation(new ResourceLocation(IronManMod.MODID, id + "_" + s.getName()), "main");
    }

    private static float[] pivot(String part) {
        return switch (part) {
            case "right_arm" -> new float[]{-5f, 2f, 0f};
            case "left_arm" -> new float[]{5f, 2f, 0f};
            case "right_leg" -> new float[]{-1.9f, 12f, 0f};
            case "left_leg" -> new float[]{1.9f, 12f, 0f};
            default -> new float[]{0f, 0f, 0f};
        };
    }

    private static CubeListBuilder cube(String part, EquipmentSlot s) {
        CubeListBuilder b = CubeListBuilder.create();
        CubeDeformation d = new CubeDeformation(G);
        switch (part) {
            case "head" -> {
                if (s == EquipmentSlot.HEAD) b.texOffs(0, 0).addBox(-4f, -8f, -4f, 8f, 8f, 8f, d);
            }
            case "body" -> {
                if (s == EquipmentSlot.CHEST) b.texOffs(16, 16).addBox(-4f, 0f, -2f, 8f, 12f, 4f, d);
            }
            case "right_arm" -> {
                if (s == EquipmentSlot.CHEST) b.texOffs(40, 16).addBox(-3f, -2f, -2f, 4f, 12f, 4f, d);
            }
            case "left_arm" -> {
                if (s == EquipmentSlot.CHEST) b.texOffs(32, 48).addBox(-1f, -2f, -2f, 4f, 12f, 4f, d);
            }
            case "right_leg" -> {
                if (s == EquipmentSlot.LEGS) b.texOffs(0, 16).addBox(-2f, 0f, -2f, 4f, 12f, 4f, d);
            }
            case "left_leg" -> {
                if (s == EquipmentSlot.LEGS) b.texOffs(16, 48).addBox(-2f, 0f, -2f, 4f, 12f, 4f, d);
            }
            default -> {
            }
        }
        return b;
    }

    public static ModelLayerLocation locFull(String id) {
        return new ModelLayerLocation(new ResourceLocation(IronManMod.MODID, id + "_full"), "main");
    }

    /** Tutta l'armatura in un solo modello (testa, busto, braccia, gambe): la disegna il Reattore Arc a tuta attiva. */
    public static LayerDefinition createFull() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        CubeDeformation d = new CubeDeformation(G);
        for (String part : PARTS) {
            CubeListBuilder b = CubeListBuilder.create();
            switch (part) {
                case "head" -> b.texOffs(0, 0).addBox(-4f, -8f, -4f, 8f, 8f, 8f, d);
                case "body" -> b.texOffs(16, 16).addBox(-4f, 0f, -2f, 8f, 12f, 4f, d);
                case "right_arm" -> b.texOffs(40, 16).addBox(-3f, -2f, -2f, 4f, 12f, 4f, d);
                case "left_arm" -> b.texOffs(32, 48).addBox(-1f, -2f, -2f, 4f, 12f, 4f, d);
                case "right_leg" -> b.texOffs(0, 16).addBox(-2f, 0f, -2f, 4f, 12f, 4f, d);
                case "left_leg" -> b.texOffs(16, 48).addBox(-2f, 0f, -2f, 4f, 12f, 4f, d);
                default -> {
                }
            }
            float[] p = pivot(part);
            root.addOrReplaceChild(part, b, PartPose.offset(p[0], p[1], p[2]));
        }
        return LayerDefinition.create(mesh, 64, 64);
    }

    public static HumanoidModel<LivingEntity> getFull(String id) {
        return CACHE.computeIfAbsent(id + "_full",
                k -> new HumanoidModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(locFull(id))));
    }

    public static LayerDefinition create(EquipmentSlot s) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        for (String part : PARTS) {
            float[] p = pivot(part);
            root.addOrReplaceChild(part, cube(part, s), PartPose.offset(p[0], p[1], p[2]));
        }
        return LayerDefinition.create(mesh, 64, 64);
    }

    public static HumanoidModel<LivingEntity> get(String id, EquipmentSlot s) {
        return CACHE.computeIfAbsent(id + "_" + s.getName(),
                k -> new HumanoidModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(loc(id, s))));
    }

    public static HumanoidModel<LivingEntity> get(SuitMark m, EquipmentSlot s) {
        return get(m.id, s);
    }
}
