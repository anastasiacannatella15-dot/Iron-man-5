package com.ironmanmod.client;

import com.ironmanmod.IronManMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = IronManMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModBus {
    private static final String CAT = "key.categories.ironmanmod";

    public static final KeyMapping TRANSFORM = new KeyMapping("key.ironmanmod.transform", InputConstants.KEY_G, CAT);
    public static final KeyMapping REPULSOR = new KeyMapping("key.ironmanmod.repulsor", InputConstants.KEY_R, CAT);
    public static final KeyMapping UNIBEAM = new KeyMapping("key.ironmanmod.unibeam", InputConstants.KEY_V, CAT);
    public static final KeyMapping MISSILES = new KeyMapping("key.ironmanmod.missiles", InputConstants.KEY_B, CAT);

    public static final KeyMapping SENTINEL = new KeyMapping("key.ironmanmod.sentinel", InputConstants.KEY_J, CAT);
    public static final KeyMapping SCAN = new KeyMapping("key.ironmanmod.scan", InputConstants.KEY_F, CAT);

    public static final KeyMapping MJ_THROW = new KeyMapping("key.ironmanmod.mj_throw", InputConstants.KEY_Z, CAT);
    public static final KeyMapping MJ_RECALL = new KeyMapping("key.ironmanmod.mj_recall", InputConstants.KEY_X, CAT);
    public static final KeyMapping MJ_BOLT = new KeyMapping("key.ironmanmod.mj_bolt", InputConstants.KEY_C, CAT);
    public static final KeyMapping MJ_STORM = new KeyMapping("key.ironmanmod.mj_storm", InputConstants.KEY_H, CAT);

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(TRANSFORM);
        e.register(REPULSOR);
        e.register(UNIBEAM);
        e.register(MISSILES);
        e.register(SENTINEL);
        e.register(SCAN);
        e.register(MJ_THROW);
        e.register(MJ_RECALL);
        e.register(MJ_BOLT);
        e.register(MJ_STORM);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("ironman_hud", ClientHud::render);
        e.registerAboveAll("friday_hud", FridayHud::render);
        e.registerAboveAll("mjolnir_hud", MjolnirHud::render);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(IronManMod.MJOLNIR_ENTITY.get(), MjolnirRenderer::new);
        e.registerEntityRenderer(IronManMod.SENTINEL.get(), SentinelRenderer::new);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        for (String id : SuitModels.IDS) {
            for (net.minecraft.world.entity.EquipmentSlot s : SuitModels.SLOTS) {
                e.registerLayerDefinition(SuitModels.loc(id, s), () -> SuitModels.create(s));
            }
            e.registerLayerDefinition(SuitModels.locFull(id), SuitModels::createFull);
        }
    }
}
