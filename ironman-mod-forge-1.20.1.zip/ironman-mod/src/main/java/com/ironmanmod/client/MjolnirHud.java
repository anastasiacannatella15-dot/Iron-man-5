package com.ironmanmod.client;

import com.ironmanmod.MjolnirItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** Suggerimenti dei tasti quando hai il Mjolnir in mano. */
public final class MjolnirHud {
    private MjolnirHud() {
    }

    public static void render(ForgeGui gui, GuiGraphics g, float pt, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        if (!(mc.player.getMainHandItem().getItem() instanceof MjolnirItem)) return;
        Component c = Component.translatable("hud.ironmanmod.mj",
                ClientModBus.MJ_THROW.getTranslatedKeyMessage(), ClientModBus.MJ_RECALL.getTranslatedKeyMessage(),
                ClientModBus.MJ_BOLT.getTranslatedKeyMessage(), ClientModBus.MJ_STORM.getTranslatedKeyMessage());
        g.drawString(mc.font, c, (w - mc.font.width(c)) / 2, h - 66, 0x9BE8FF, true);
    }
}
