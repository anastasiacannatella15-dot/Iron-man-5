package com.ironmanmod.client;

import com.ironmanmod.SlingRingItem;
import com.ironmanmod.net.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/** Menu dei waypoint dell'anello di Doctor Strange (Shift + clic destro, oppure Shift + N). */
public class SlingRingScreen extends Screen {
    private static final int ROWS = 6;
    private int scroll;
    private int renaming = -1;
    private EditBox box;
    private String boxText = "";
    private String sig = "";

    public SlingRingScreen() {
        super(Component.translatable("gui.ironmanmod.sr_title"));
    }

    public static void open() {
        Minecraft.getInstance().setScreen(new SlingRingScreen());
    }

    private ListTag wps() {
        ItemStack r = SlingRingItem.find(Minecraft.getInstance().player);
        CompoundTag t = r.getTag();
        return t == null ? new ListTag() : t.getList("WP", 10);
    }

    private int sel() {
        CompoundTag t = SlingRingItem.find(Minecraft.getInstance().player).getTag();
        return t == null ? -1 : t.getInt("Sel");
    }

    private String signature() {
        return wps() + "|" + sel();
    }

    @Override
    protected void init() {
        if (box != null) boxText = box.getValue();
        sig = signature();
        int left = width / 2 - 130, top = height / 2 - 100;
        ListTag l = wps();
        int sel = sel();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, l.size() - ROWS)));
        for (int i = 0; i < ROWS; i++) {
            int idx = scroll + i;
            if (idx >= l.size()) break;
            CompoundTag w = l.getCompound(idx);
            int y = top + 22 + i * 22;
            String label = (idx == sel ? "> " : "") + w.getString("Name") + "  (" + (int) w.getDouble("X") + ", " + (int) w.getDouble("Y") + ", " + (int) w.getDouble("Z") + ")";
            String nm = w.getString("Name");
            addRenderableWidget(Button.builder(Component.literal(label), b -> Net.sendRing(1, idx, "")).bounds(left, y, 190, 20).build());
            addRenderableWidget(Button.builder(Component.literal("R"), b -> {
                renaming = idx;
                box.setValue(nm);
                rebuildWidgets();
            }).bounds(left + 194, y, 28, 20).build());
            addRenderableWidget(Button.builder(Component.literal("X"), b -> {
                renaming = -1;
                Net.sendRing(3, idx, "");
            }).bounds(left + 226, y, 28, 20).build());
        }
        int by = top + 22 + ROWS * 22 + 6;
        box = new EditBox(font, left, by, 150, 20, Component.empty());
        box.setMaxLength(20);
        box.setHint(Component.translatable("gui.ironmanmod.sr_hint"));
        box.setValue(boxText);
        addRenderableWidget(box);
        addRenderableWidget(Button.builder(Component.translatable(renaming >= 0 ? "gui.ironmanmod.sr_rename" : "gui.ironmanmod.sr_save"), b -> {
            String n = box.getValue().trim();
            if (renaming >= 0) {
                Net.sendRing(2, renaming, n);
                renaming = -1;
            } else {
                Net.sendRing(0, 0, n);
            }
            box.setValue("");
            boxText = "";
            rebuildWidgets();
        }).bounds(left + 154, by, 100, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.ironmanmod.sr_open"), b -> {
            Net.sendRing(4, 0, "");
            onClose();
        }).bounds(left, by + 24, 254, 20).build());
    }

    @Override
    public void tick() {
        if (minecraft == null || minecraft.player == null || SlingRingItem.find(minecraft.player).isEmpty()) {
            onClose();
            return;
        }
        if (!sig.equals(signature())) rebuildWidgets();
    }

    @Override
    public boolean mouseScrolled(double x, double y, double delta) {
        int old = scroll;
        scroll -= (int) Math.signum(delta);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, wps().size() - ROWS)));
        if (old != scroll) rebuildWidgets();
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int top = height / 2 - 100;
        g.drawCenteredString(font, title, width / 2, top + 6, 0xFFAA33);
        if (wps().isEmpty()) g.drawCenteredString(font, Component.translatable("gui.ironmanmod.sr_empty"), width / 2, top + 50, 0xAAAAAA);
        super.render(g, mx, my, pt);
    }
}
