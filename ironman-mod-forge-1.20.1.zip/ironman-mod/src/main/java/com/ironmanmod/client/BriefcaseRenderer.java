package com.ironmanmod.client;

import com.ironmanmod.BriefcaseEntity;
import com.ironmanmod.IronManMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** La valigetta a terra: stesa sul pavimento, chiusa o aperta. */
public class BriefcaseRenderer extends EntityRenderer<BriefcaseEntity> {
    public BriefcaseRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.3f;
    }

    @Override
    public void render(BriefcaseEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        ps.translate(0, 0.06, 0);
        ps.mulPose(Axis.YP.rotationDegrees(-e.getYRot()));
        ps.mulPose(Axis.XP.rotationDegrees(90f)); // stesa a terra
        ps.scale(1.5f, 1.5f, 1.5f);
        ItemStack s = new ItemStack(e.isOpen() ? IronManMod.BRIEFCASE_OPEN.get() : IronManMod.BRIEFCASE.get());
        Minecraft.getInstance().getItemRenderer().renderStatic(s, ItemDisplayContext.FIXED, light,
                OverlayTexture.NO_OVERLAY, ps, buf, e.level(), e.getId());
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    @Override
    public ResourceLocation getTextureLocation(BriefcaseEntity e) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
