package com.ironmanmod;

import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Le Gemme dell'Infinito di "Pugmeowla's Infinity Stone Core" (mod "infinity") incastonate nel Mjolnir. */
public final class MjolnirGems {
    public static final String MOD = "infinity";
    public static final String[] STONES = {"power", "space", "reality", "time", "soul", "mind"};

    private MjolnirGems() {
    }

    /** "power", "space"... se l'oggetto e' una gemma dell'Infinity Stone Core, altrimenti null. */
    public static String stoneOf(ItemStack s) {
        if (s.isEmpty()) return null;
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (k == null || !MOD.equals(k.getNamespace())) return null;
        for (String n : STONES) if (k.getPath().equals(n + "_stone")) return n;
        return null;
    }

    public static List<String> list(ItemStack hammer) {
        List<String> out = new ArrayList<>();
        if (hammer.getTag() == null) return out;
        for (Tag t : hammer.getTag().getList("Gems", Tag.TAG_STRING)) out.add(t.getAsString());
        return out;
    }

    public static boolean has(ItemStack hammer, String stone) {
        return list(hammer).contains(stone);
    }

    public static boolean add(ItemStack hammer, String stone) {
        if (has(hammer, stone)) return false;
        ListTag l = hammer.getOrCreateTag().getList("Gems", Tag.TAG_STRING);
        l.add(StringTag.valueOf(stone));
        hammer.getOrCreateTag().put("Gems", l);
        return true;
    }

    /** Toglie l'ultima gemma inserita e la restituisce come oggetto (o EMPTY). */
    public static ItemStack removeLast(ItemStack hammer) {
        List<String> l = list(hammer);
        if (l.isEmpty()) return ItemStack.EMPTY;
        String last = l.remove(l.size() - 1);
        ListTag nl = new ListTag();
        for (String s : l) nl.add(StringTag.valueOf(s));
        hammer.getOrCreateTag().put("Gems", nl);
        var item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(MOD, last + "_stone"));
        return item == null ? ItemStack.EMPTY : new ItemStack(item);
    }
}
