package com.ironmanmod;

import org.joml.Vector3f;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Le Gemme dell'Infinito di "Pugmeowla's Infinity Stone Core" (mod "infinity") incastonate nel Mjolnir. */
public final class MjolnirGems {
    public static final String MOD = "infinity";
    public static final String[] STONES = {"power", "space", "reality", "time", "soul", "mind"};

    private MjolnirGems() {
    }

    /** "power", "space"... se l'oggetto e' una gemma dell'Infinity Stone Core, altrimenti null. */
    public static String stoneOf(ItemStack s) {
        if (s.isEmpty()) return null;
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (k == null || !MOD.equals(k.getNamespace())) return null;
        for (String n : STONES) if (k.getPath().equals(n + "_stone")) return n;
        return null;
    }

    public static List<String> list(ItemStack hammer) {
        List<String> out = new ArrayList<>();
        if (hammer.getTag() == null) return out;
        for (Tag t : hammer.getTag().getList("Gems", Tag.TAG_STRING)) out.add(t.getAsString());
        return out;
    }

    public static boolean has(ItemStack hammer, String stone) {
        return list(hammer).contains(stone);
    }

    public static boolean add(ItemStack hammer, String stone) {
        if (has(hammer, stone)) return false;
        ListTag l = hammer.getOrCreateTag().getList("Gems", Tag.TAG_STRING);
        l.add(StringTag.valueOf(stone));
        hammer.getOrCreateTag().put("Gems", l);
        return true;
    }

    /** Toglie l'ultima gemma inserita e la restituisce come oggetto (o EMPTY). */
    public static ItemStack removeLast(ItemStack hammer) {
        List<String> l = list(hammer);
        if (l.isEmpty()) return ItemStack.EMPTY;
        String last = l.remove(l.size() - 1);
        ListTag nl = new ListTag();
        for (String s : l) nl.add(StringTag.valueOf(s));
        hammer.getOrCreateTag().put("Gems", nl);
        var item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(MOD, last + "_stone"));
        return item == null ? ItemStack.EMPTY : new ItemStack(item);
    }

    private static final float[][] COLORS = {
            {0.67f, 0.16f, 1.0f},   // power: viola
            {0.16f, 0.43f, 1.0f},   // space: blu
            {1.0f, 0.12f, 0.16f},   // reality: rosso
            {0.16f, 1.0f, 0.35f},   // time: verde
            {1.0f, 0.6f, 0.08f},    // soul: arancio
            {1.0f, 0.94f, 0.16f}};  // mind: giallo

    /** Bit per ogni gemma (power = 1 ... mind = 32): serve al modello per mostrare le pietre sul martello. */
    public static int mask(ItemStack hammer) {
        int m = 0;
        for (String g : list(hammer)) {
            for (int i = 0; i < STONES.length; i++) if (STONES[i].equals(g)) m |= 1 << i;
        }
        return m;
    }

    /** Danno del lancio con F: Power da solo 250 (mob) / 20 (giocatori); ogni altra gemma +20 / +2; tutte e 6 = 350 / 30. */
    public static float strike(ItemStack hammer, boolean player) {
        float d = player ? 8f : 60f;
        for (String g : list(hammer)) d += g.equals("power") ? (player ? 12f : 190f) : (player ? 2f : 20f);
        return d;
    }

    private static void burst(ServerLevel sl, double x, double y, double z, double radius, int count, float[] c) {
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), 3.0f);
        for (int i = 0; i < count; i++) {
            double dx, dy, dz;
            do {
                dx = sl.random.nextDouble() * 2 - 1;
                dy = sl.random.nextDouble() * 2 - 1;
                dz = sl.random.nextDouble() * 2 - 1;
            } while (dx * dx + dy * dy + dz * dz > 1);
            sl.sendParticles(dust, x + dx * radius, y + 1.0 + dy * radius, z + dz * radius, 1, 0, 0, 0, 0);
        }
    }

    private static void halfLife(ServerLevel sl, LivingEntity e, boolean holder) {
        float amount = e.getMaxHealth() / 2f;
        if (holder) amount = Math.max(0f, Math.min(amount, e.getHealth() - 1f)); // chi regge il martello non muore
        if (amount > 0f) e.hurt(sl.damageSources().magic(), amount);
    }

    /** Effetti dell'inserimento di una gemma. */
    public static void onInsert(ServerLevel sl, Player p, String stone, ItemStack hammer) {
        int idx = 0;
        for (int i = 0; i < STONES.length; i++) if (STONES[i].equals(stone)) idx = i;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        if (stone.equals("power")) {
            halfLife(sl, p, true); // costa meta' vita
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 80, 4, false, false, false)); // niente danno dalla TNT
            burst(sl, x, y, z, 10, 700, COLORS[0]);
            for (int i = 0; i < 5; i++) { // esplosione da 5 TNT (senza rompere i blocchi)
                sl.explode(null, x + (sl.random.nextDouble() - 0.5) * 3, y + 0.5, z + (sl.random.nextDouble() - 0.5) * 3, 4.0f, Level.ExplosionInteraction.NONE);
            }
        } else {
            burst(sl, x, y, z, 5, 250, COLORS[idx]);
            sl.playSound(null, x, y, z, SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 0.8f + idx * 0.15f);
        }
        if (list(hammer).size() >= STONES.length) { // tutte e 6: onda di tutti i colori, meta' vita a chiunque entro 15 blocchi
            for (float[] c : COLORS) burst(sl, x, y, z, 15, 450, c);
            sl.playSound(null, x, y, z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 3.0f, 0.6f);
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(15), t -> t.isAlive() && t.distanceToSqr(p) <= 225.0)) {
                halfLife(sl, e, e == p);
            }
        }
    }
}
