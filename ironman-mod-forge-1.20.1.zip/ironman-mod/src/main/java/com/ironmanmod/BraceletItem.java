package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * I bracciali della Mark 7 (The Avengers): l'unico modo per avere la Mark 7. Clic destro: dai bracciali partono scintille e i pezzi
 * dell'armatura arrivano in volo dall'alto e si agganciano uno alla volta. Shift + clic destro con i bracciali "scarichi"
 * mentre porti la Mark 7: l'armatura si richiude nei bracciali.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class BraceletItem extends Item {
    private static final String T = "br_t";
    private static final int[] AT = {16, 30, 46, 62}; // stivali, gambali, petto, casco
    private static final int END = 76;
    private static final double[] HEIGHT = {0.2, 0.7, 1.3, 1.75};

    public BraceletItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (level.isClientSide || !(p instanceof ServerPlayer sp)) return InteractionResultHolder.success(st);
        CompoundTag d = sp.getPersistentData();
        if (d.getInt(T) > 0) return InteractionResultHolder.fail(st);
        boolean wearing = SuitData.classicSet(sp) == SuitMark.MARK_7;
        boolean spent = BriefcaseItem.isEmptyCase(st); // "Empty" = i bracciali hanno gia' lanciato l'armatura
        if (sp.isShiftKeyDown()) {
            if (!spent) {
                SuitData.msg(sp, "msg.ironmanmod.br_full");
            } else if (!wearing) {
                SuitData.msg(sp, "msg.ironmanmod.br_nosuit");
            } else {
                for (EquipmentSlot s : BriefcaseItem.SLOTS) sp.setItemSlot(s, ItemStack.EMPTY);
                st.getOrCreateTag().remove("Empty");
                ServerLevel sl = sp.serverLevel();
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 1, sp.getZ(), 60, 0.5, 0.9, 0.5, 0.3);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 0.8f);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PISTON_CONTRACT, SoundSource.PLAYERS, 1.0f, 1.3f);
                SuitData.msg(sp, "msg.ironmanmod.br_off");
            }
            return InteractionResultHolder.success(st);
        }
        if (spent) {
            SuitData.msg(sp, "msg.ironmanmod.br_empty");
            return InteractionResultHolder.fail(st);
        }
        if (wearing) {
            SuitData.msg(sp, "msg.ironmanmod.br_already");
            return InteractionResultHolder.fail(st);
        }
        st.getOrCreateTag().putBoolean("Empty", true);
        d.putInt(T, 1);
        return InteractionResultHolder.success(st);
    }

    private static Vec3 wrist(ServerPlayer p, int side) {
        double yaw = Math.toRadians(p.getYRot());
        return new Vec3(p.getX() + Math.cos(yaw) * 0.4 * side, p.getY() + 0.95, p.getZ() + Math.sin(yaw) * 0.4 * side);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide || !(e.player instanceof ServerPlayer p)) return;
        CompoundTag d = p.getPersistentData();
        int t = d.getInt(T);
        if (t <= 0) return;
        t++;
        d.putInt(T, t);
        ServerLevel sl = p.serverLevel();
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 6, false, false, false)); // resti fermo
        if (t == 2) {
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.8f);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.PLAYERS, 1.0f, 0.9f);
        }
        if (t < AT[3] && t % 2 == 0) { // i bracciali brillano
            for (int s = -1; s <= 1; s += 2) {
                Vec3 w = wrist(p, s);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, w.x, w.y, w.z, 3, 0.1, 0.1, 0.1, 0.05);
            }
        }
        for (int i = 0; i < 4; i++) {
            int a = AT[i];
            if (t >= a - 12 && t < a) { // il pezzo arriva in volo dall'alto e da un lato
                double f = (t - (a - 12)) / 12.0;
                Vec3 target = new Vec3(p.getX(), p.getY() + HEIGHT[i], p.getZ());
                double ang = i * 1.7 + 0.6;
                Vec3 start = new Vec3(p.getX() + Math.cos(ang) * 5, p.getY() + 7, p.getZ() + Math.sin(ang) * 5);
                Vec3 pos = start.lerp(target, f * f * (3 - 2 * f));
                sl.sendParticles(ParticleTypes.CRIT, pos.x, pos.y, pos.z, 8, 0.12, 0.12, 0.12, 0.02);
                sl.sendParticles(ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 1, 0.05, 0.05, 0.05, 0.0);
            }
            if (t == a) {
                BriefcaseItem.equip(p, SuitMark.MARK_7, i);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + HEIGHT[i], p.getZ(), 25, 0.35, 0.2, 0.35, 0.2);
                sl.sendParticles(ParticleTypes.CRIT, p.getX(), p.getY() + HEIGHT[i], p.getZ(), 15, 0.4, 0.2, 0.4, 0.3);
                sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 0.5f, 1.5f);
                sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 1.1f);
            }
        }
        if (t >= END) {
            d.remove(T);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.8f);
            sl.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 25, 0.4, 0.9, 0.4, 0.05);
            SuitData.msg(p, "msg.ironmanmod.br_on");
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable(BriefcaseItem.isEmptyCase(stack) ? "tooltip.ironmanmod.br_empty" : "tooltip.ironmanmod.br_full")
                .withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
