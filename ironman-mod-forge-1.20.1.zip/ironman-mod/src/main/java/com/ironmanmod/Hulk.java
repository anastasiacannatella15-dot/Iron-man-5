package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hulk (siero gamma, 5 minuti) e Hulkbuster: pugni potenti, salto a terra e onda d'urto all'atterraggio (tasto del repulsore). */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public final class Hulk {
    private static final String END = "hulk_end";
    private static final int DURATION = 6000;

    private Hulk() {
    }

    public static boolean isHulk(Player p) {
        return p.getPersistentData().getLong(END) > p.level().getGameTime();
    }

    private static boolean hulkbuster(Player p) {
        return SuitData.classicSet(p) == SuitMark.MARK_44;
    }

    private static boolean isHulkPiece(ItemStack s) {
        return s.getItem() instanceof HeroArmorItem h && h.mark == SuitMark.HULK;
    }

    public static void transform(ServerPlayer p) {
        for (int i = 0; i < 4; i++) {
            EquipmentSlot s = BriefcaseItem.SLOTS[i];
            ItemStack old = p.getItemBySlot(s);
            if (!old.isEmpty() && !isHulkPiece(old)) {
                if (!p.getInventory().add(old)) p.drop(old, false);
            }
            ItemStack piece = new ItemStack(IronManMod.ARMOR.get(SuitMark.HULK).get(BriefcaseItem.TYPES[i]).get());
            piece.getOrCreateTag().putBoolean("Unbreakable", true);
            p.setItemSlot(s, piece);
        }
        p.getPersistentData().putLong(END, p.level().getGameTime() + DURATION);
        p.heal(p.getMaxHealth());
        ServerLevel sl = p.serverLevel();
        sl.sendParticles(ParticleTypes.EXPLOSION, p.getX(), p.getY() + 1, p.getZ(), 6, 0.6, 0.9, 0.6, 0.0);
        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1, p.getZ(), 60, 0.7, 1.0, 0.7, 0.2);
        sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.5f, 0.5f);
        sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.0f, 0.8f);
        effects(p);
        SuitData.msg(p, "msg.ironmanmod.hulk_on");
    }

    private static void effects(ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 3, true, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 2, true, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, 3, true, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1, true, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 60, 4, true, false, false));
    }

    /** Toglie i pezzi del Hulk da armatura e inventario. */
    private static void strip(ServerPlayer p) {
        for (EquipmentSlot s : BriefcaseItem.SLOTS) if (isHulkPiece(p.getItemBySlot(s))) p.setItemSlot(s, ItemStack.EMPTY);
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.items.size(); i++) if (isHulkPiece(inv.items.get(i))) inv.items.set(i, ItemStack.EMPTY);
        for (int i = 0; i < inv.offhand.size(); i++) if (isHulkPiece(inv.offhand.get(i))) inv.offhand.set(i, ItemStack.EMPTY);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide || !(e.player instanceof ServerPlayer p)) return;
        CompoundTag d = p.getPersistentData();
        long end = d.getLong(END);
        if (end > p.level().getGameTime()) {
            if (p.tickCount % 20 == 0) effects(p);
            if (p.tickCount % 5 == 0 && p.getDeltaMovement().horizontalDistanceSqr() > 0.02) {
                p.serverLevel().sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.1, p.getZ(), 2, 0.2, 0.0, 0.2, 0.01);
            }
        } else if (end > 0) { // finito: torni normale
            d.remove(END);
            strip(p);
            p.serverLevel().sendParticles(ParticleTypes.POOF, p.getX(), p.getY() + 1, p.getZ(), 30, 0.5, 0.9, 0.5, 0.05);
            SuitData.msg(p, "msg.ironmanmod.hulk_off");
        } else if (p.tickCount % 40 == 0) {
            strip(p); // niente pezzi del Hulk fuori dalla trasformazione
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && p.getPersistentData().getLong(END) > 0) {
            p.getPersistentData().remove(END);
            strip(p);
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer p) || e.getSource().getDirectEntity() != p) return;
        float mul = isHulk(p) ? 2.0f : hulkbuster(p) ? 1.6f : 1.0f;
        if (mul > 1.0f) {
            e.setAmount(e.getAmount() * mul);
            Vec3 look = p.getLookAngle();
            e.getEntity().push(look.x * 0.8, 0.35, look.z * 0.8);
            e.getEntity().hurtMarked = true;
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !(isHulk(p) || hulkbuster(p))) return;
        float dist = e.getDistance();
        e.setDamageMultiplier(0f); // niente danno da caduta
        if (dist >= 3.0f) shock(p, 4.0 + Math.min(dist * 0.15, 5.0), 5.0f);
    }

    /** Tasto del repulsore: a terra salti in avanti, in aria ti schianti verso il basso (onda d'urto all'atterraggio). */
    public static void leap(ServerPlayer p) {
        if (!SuitData.ready(p, "slam")) return;
        SuitData.setCooldown(p, "slam", 25);
        Vec3 look = p.getLookAngle();
        if (p.onGround()) {
            p.setDeltaMovement(look.x * 1.6, 1.1, look.z * 1.6);
        } else {
            p.setDeltaMovement(0, -2.4, 0);
            p.fallDistance = Math.max(p.fallDistance, 8.0f);
        }
        p.hurtMarked = true;
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.RAVAGER_ATTACK, SoundSource.PLAYERS, 1.0f, 0.6f);
    }

    public static void shock(ServerPlayer p, double radius, float dmg) {
        ServerLevel sl = p.serverLevel();
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radius), x -> x != p && x.isAlive())) {
            double dx = t.getX() - p.getX(), dz = t.getZ() - p.getZ();
            double dd = Math.max(0.5, Math.sqrt(dx * dx + dz * dz));
            t.hurt(p.damageSources().playerAttack(p), dmg);
            t.setDeltaMovement(dx / dd * 0.9, 0.8, dz / dd * 0.9);
            t.hurtMarked = true;
        }
        sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.getX(), p.getY() + 0.2, p.getZ(), 1, 0, 0, 0, 0);
        for (int i = 0; i < 40; i++) {
            double a = Math.PI * 2 * i / 40;
            sl.sendParticles(ParticleTypes.POOF, p.getX() + Math.cos(a) * radius * 0.7, p.getY() + 0.2, p.getZ() + Math.sin(a) * radius * 0.7, 1, 0.1, 0.1, 0.1, 0.05);
        }
        sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.5f, 0.6f);
    }
}
