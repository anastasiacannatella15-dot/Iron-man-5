package com.ironmanmod;

import com.ironmanmod.net.Net;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Repulsori, Unibeam e micro-missili. */
public final class Powers {
    private static final DustParticleOptions YELLOW = new DustParticleOptions(new Vector3f(1.0f, 0.88f, 0.12f), 0.9f);
    private static final DustParticleOptions UNI = new DustParticleOptions(new Vector3f(1.0f, 0.95f, 0.55f), 2.2f);
    private static final DustParticleOptions BIG = new DustParticleOptions(new Vector3f(1.0f, 0.78f, 0.2f), 2.0f);

    private Powers() {
    }

    private record Trace(Vec3 end, List<LivingEntity> hits) {
    }

    private static Trace trace(ServerPlayer p, double range, boolean pierce) {
        Level lvl = p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(range));
        BlockHitResult bh = lvl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (bh.getType() != HitResult.Type.MISS) end = bh.getLocation();
        final Vec3 fEnd = end;

        AABB box = new AABB(eye, fEnd).inflate(1.5);
        List<LivingEntity> cand = lvl.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != p && e.isAlive() && !e.isSpectator());
        Map<LivingEntity, Double> dist = new HashMap<>();
        List<LivingEntity> hits = new ArrayList<>();
        for (LivingEntity e : cand) {
            Optional<Vec3> h = e.getBoundingBox().inflate(0.3).clip(eye, fEnd);
            if (h.isPresent()) {
                dist.put(e, eye.distanceToSqr(h.get()));
                hits.add(e);
            }
        }
        hits.sort(Comparator.comparingDouble((LivingEntity e) -> dist.get(e)));
        if (!pierce && hits.size() > 1) hits = new ArrayList<>(hits.subList(0, 1));
        if (!pierce && !hits.isEmpty()) end = eye.add(look.scale(Math.sqrt(dist.get(hits.get(0)))));
        return new Trace(end, hits);
    }

    private static void beam(ServerLevel lvl, Vec3 from, Vec3 to, boolean big) {
        Vec3 d = to.subtract(from);
        double len = d.length();
        if (len < 0.5) return;
        Vec3 dir = d.scale(1.0 / len);
        double step = big ? 0.6 : 0.7;
        int n = 0;
        for (double s = 0.0; s < len; s += step, n++) {
            Vec3 pt = from.add(dir.scale(s));
            lvl.sendParticles(big ? UNI : YELLOW, pt.x, pt.y, pt.z, 1, 0.02, 0.02, 0.02, 0);
            if (n % 3 == 0) lvl.sendParticles(ParticleTypes.END_ROD, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
            if (big && n % 4 == 0) lvl.sendParticles(ParticleTypes.FLAME, pt.x, pt.y, pt.z, 1, 0.1, 0.1, 0.1, 0.01);
        }
    }

    private static void hit(ServerPlayer p, LivingEntity e, float dmg, boolean resetIframes) {
        if (resetIframes) e.invulnerableTime = 0;
        if (e.hurt(p.damageSources().playerAttack(p), dmg)) {
            Vec3 d = e.position().subtract(p.position());
            d = new Vec3(d.x, 0, d.z).normalize();
            e.push(d.x * 0.5, 0.15, d.z * 0.5);
            e.hurtMarked = true;
        }
        e.setSecondsOnFire(6); // raggi di fuoco
    }

    /** Posizione della mano destra (da dove parte il raggio del repulsore). */
    private static Vec3 hand(ServerPlayer p) {
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        return p.getEyePosition().add(right.scale(0.4)).add(0, -0.45, 0).add(look.scale(0.6));
    }

    // ------------------------------------------------------------------ repulsore (raggio giallo di 1,5 s; tenendo premuto riparte)

    public static final int BEAM_TICKS = 30; // 1,5 secondi

    public static void repulsor(ServerPlayer p) {
        SuitMark m = SuitData.activeMark(p);
        if (m == null) return;
        CompoundTag r = SuitData.root(p);
        if (r.getInt("rep") > 0 || r.getInt("uni") > 0) return; // raggio gia' in corso
        if (!SuitData.useEnergy(p, 150)) {
            SuitData.msg(p, "msg.ironmanmod.no_energy");
            return;
        }
        r.putInt("rep", BEAM_TICKS);
        Net.sendPose(p, BEAM_TICKS + 2); // braccio destro alzato finche' dura il raggio
        ServerLevel lvl = p.serverLevel();
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.7f);
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 0.8f, 2.0f); // il "tiiiii" dei film
    }

    // ------------------------------------------------------------------ unibeam dal petto (1,5 secondi)

    public static void unibeam(ServerPlayer p) {
        SuitMark m = SuitData.activeMark(p);
        if (m == null) return;
        if (m.unibeamDamage <= 0f) {
            SuitData.msg(p, "msg.ironmanmod.no_unibeam");
            return;
        }
        CompoundTag r = SuitData.root(p);
        if (r.getInt("uni") > 0 || r.getInt("rep") > 0) return;
        if (!SuitData.ready(p, "uni")) return;
        if (!SuitData.useEnergy(p, 1500)) {
            SuitData.msg(p, "msg.ironmanmod.no_energy");
            return;
        }
        SuitData.setCooldown(p, "uni", 80);
        r.putInt("uni", BEAM_TICKS);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.2f, 1.2f);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 1.0f, 1.5f);
    }

    /** Ogni tick: continua i raggi in corso (repulsore e unibeam, 1,5 s ciascuno). */
    public static void tick(ServerPlayer p, CompoundTag r) {
        SuitMark m = SuitData.activeMark(p);
        ServerLevel lvl = p.serverLevel();

        int rep = r.getInt("rep");
        if (rep > 0) {
            if (m == null) {
                r.putInt("rep", 0);
            } else {
                r.putInt("rep", rep - 1);
                int n = BEAM_TICKS - rep;
                Trace tr = trace(p, 40, false);
                beam(lvl, hand(p), tr.end(), false);
                lvl.sendParticles(BIG, tr.end().x, tr.end().y, tr.end().z, 2, 0.15, 0.15, 0.15, 0.02);
                if (n % 10 == 0) {
                    for (LivingEntity e : tr.hits()) hit(p, e, m.repulsorDamage * 0.7f, true);
                    lvl.sendParticles(ParticleTypes.FLASH, tr.end().x, tr.end().y, tr.end().z, 1, 0, 0, 0, 0);
                }
            }
        }

        int uni = r.getInt("uni");
        if (uni <= 0) return;
        if (m == null || m.unibeamDamage <= 0f) {
            r.putInt("uni", 0);
            return;
        }
        r.putInt("uni", uni - 1);
        int n = BEAM_TICKS - uni;
        Trace tr = trace(p, 64, true);
        Vec3 from = new Vec3(p.getX(), p.getY() + 1.25, p.getZ()).add(p.getLookAngle().multiply(0.4, 0, 0.4)); // dal reattore sul petto
        beam(lvl, from, tr.end(), true);
        lvl.sendParticles(ParticleTypes.END_ROD, from.x, from.y, from.z, 3, 0.1, 0.1, 0.1, 0.03);
        lvl.sendParticles(ParticleTypes.FLAME, tr.end().x, tr.end().y, tr.end().z, 4, 0.3, 0.3, 0.3, 0.05);
        if (n % 6 == 0) {
            for (LivingEntity e : tr.hits()) hit(p, e, m.unibeamDamage / 5f, true); // 5 colpi: in tutto il danno dell'unibeam
        }
        if (n == 0) lvl.sendParticles(ParticleTypes.FLASH, from.x, from.y, from.z, 1, 0, 0, 0, 0);
        if (uni == 1) lvl.sendParticles(ParticleTypes.EXPLOSION, tr.end().x, tr.end().y, tr.end().z, 2, 0.4, 0.4, 0.4, 0);
    }

    // ------------------------------------------------------------------ micro-missili

    public static void missiles(ServerPlayer p) {
        SuitMark m = SuitData.activeMark(p);
        if (m == null || !SuitData.ready(p, "mis")) return;
        if (m.missiles <= 0) {
            SuitData.msg(p, "msg.ironmanmod.no_missiles");
            return;
        }
        if (!SuitData.useEnergy(p, 500)) {
            SuitData.msg(p, "msg.ironmanmod.no_energy");
            return;
        }
        SuitData.setCooldown(p, "mis", 100);
        ServerLevel lvl = p.serverLevel();

        List<LivingEntity> targets = new ArrayList<>(lvl.getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(28), e -> e instanceof Enemy && e.isAlive() && e != p && p.hasLineOfSight(e)));
        targets.sort(Comparator.comparingDouble((LivingEntity e) -> e.distanceToSqr(p)));

        Vec3 shoulder = p.position().add(0, 1.6, 0);
        int count = Math.min(m.missiles, targets.size());
        for (int i = 0; i < count; i++) {
            LivingEntity t = targets.get(i);
            Vec3 pos = t.position().add(0, t.getBbHeight() * 0.5, 0);
            beam(lvl, shoulder, pos, false);
            hit(p, t, m.repulsorDamage, true);
            lvl.explode(p, pos.x, pos.y, pos.z, 1.6f, Level.ExplosionInteraction.NONE);
        }
        if (count == 0) {
            Trace tr = trace(p, 30, false);
            Vec3 end = tr.end();
            if (end.distanceTo(p.position()) > 4) {
                beam(lvl, shoulder, end, false);
                lvl.explode(p, end.x, end.y, end.z, 1.6f, Level.ExplosionInteraction.NONE);
            }
        }
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.0f, 0.8f);
    }
}
