package com.ironmanmod;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

import java.util.Optional;

/** Meteorite come vera struttura: funziona con /locate structure ironmanmod:meteorite e con Explorer's Compass. */
public class MeteoriteStructure extends Structure {
    public static final Codec<MeteoriteStructure> CODEC = simpleCodec(MeteoriteStructure::new);

    public MeteoriteStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext ctx) {
        ChunkPos cp = ctx.chunkPos();
        int x = cp.getMiddleBlockX(), z = cp.getMiddleBlockZ();
        var g = ctx.chunkGenerator();
        var ha = ctx.heightAccessor();
        var rs = ctx.randomState();
        int y = g.getFirstOccupiedHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, ha, rs);
        // niente oceani/laghi e niente terreno troppo ripido
        if (!g.getBaseColumn(x, z, ha, rs).getBlock(y - 1).getFluidState().isEmpty()) return Optional.empty();
        int[][] off = {{8, 8}, {-8, 8}, {8, -8}, {-8, -8}};
        for (int[] o : off) {
            int yy = g.getFirstOccupiedHeight(x + o[0], z + o[1], Heightmap.Types.WORLD_SURFACE_WG, ha, rs);
            if (Math.abs(yy - y) > 5) return Optional.empty();
        }
        final int gy = y - 1;
        return Optional.of(new Structure.GenerationStub(new BlockPos(x, gy, z),
                builder -> builder.addPiece(new MeteoritePiece(x, gy, z))));
    }

    @Override
    public StructureType<?> type() {
        return ModContent.METEORITE_STRUCTURE.get();
    }
}
