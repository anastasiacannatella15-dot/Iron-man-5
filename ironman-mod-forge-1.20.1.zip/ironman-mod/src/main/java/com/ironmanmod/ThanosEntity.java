package com.ironmanmod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;

import java.util.UUID;

/**
 * Thanos: 500 di vita, armor 30. Se hai il Guanto dell'Infinito te lo prende ("You stole my Gauntlet. I'm taking it back.") e lo porta alla mano sinistra,
 * con le gemme ha particelle arcobaleno. A 10 di vita dice "I AM INEVITABLE." e schiocca: con la Mark 85 e' il finale di Endgame.
 */
public class ThanosEntity extends PathfinderMob implements Enemy {
    private static final EntityDataAccessor<Boolean> GAUNTLET = SynchedEntityData.defineId(ThanosEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> REACHING = SynchedEntityData.defineId(ThanosEntity.class, EntityDataSerializers.BOOLEAN);
    public static final float END_HEALTH = 10f;

    private final ServerBossEvent bar = new ServerBossEvent(Component.translatable("entity.ironmanmod.thanos"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    private ItemStack stolen = ItemStack.EMPTY;
    private boolean checked, sequence, done;
    private int seq, reach;
    private UUID victim, hero;

    public ThanosEntity(EntityType<? extends ThanosEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        xpReward = 500;
    }

    public static AttributeSupplier.Builder attributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 500.0)
                .add(Attributes.ARMOR, 30.0)
                .add(Attributes.ARMOR_TOUGHNESS, 8.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.MOVEMENT_SPEED, 0.30)
                .add(Attributes.ATTACK_DAMAGE, 14.0)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(GAUNTLET, false);
        entityData.define(REACHING, false);
    }

    public boolean hasGauntlet() {
        return entityData.get(GAUNTLET);
    }

    public boolean isReaching() {
        return entityData.get(REACHING);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean removeWhenFarAway(double d) {
        return false;
    }

    // ------------------------------------------------------------------ barra del boss

    @Override
    public void startSeenByPlayer(ServerPlayer p) {
        super.startSeenByPlayer(p);
        bar.addPlayer(p);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer p) {
        super.stopSeenByPlayer(p);
        bar.removePlayer(p);
    }

    // ------------------------------------------------------------------ danni

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (!src.is(DamageTypes.GENERIC_KILL)) {
            if (sequence) return false; // durante la scena non si puo' toccare
            if (!done && getHealth() <= END_HEALTH) return false; // si ferma a 20: il finale parte nel tick
        }
        return super.hurt(src, amount);
    }

    @Override
    protected void actuallyHurt(DamageSource src, float amount) {
        if (!done && !sequence && getHealth() > END_HEALTH && getHealth() - amount < END_HEALTH && !src.is(DamageTypes.GENERIC_KILL)) {
            amount = getHealth() - END_HEALTH; // non scende sotto i 20 di colpo
        }
        super.actuallyHurt(src, amount);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource src) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.IRON_GOLEM_DEATH;
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource src, int looting, boolean recent) {
        super.dropCustomDeathLoot(src, looting, recent);
        if (!stolen.isEmpty()) {
            spawnAtLocation(stolen.copy()); // il guanto rubato torna a chi lo vince
            stolen = ItemStack.EMPTY;
        }
        spawnAtLocation(new ItemStack(ModContent.URU_INGOT.get(), 6));
        spawnAtLocation(new ItemStack(ModContent.VIBRANIUM_INGOT.get(), 4));
    }

    // ------------------------------------------------------------------ comportamento

    private static boolean isGauntlet(ItemStack s) {
        if (s.isEmpty()) return false;
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        return k != null && k.getNamespace().equals("infinity") && k.getPath().equals("infinity_gauntlet");
    }

    private static boolean hasGauntlet(Player p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) if (isGauntlet(inv.getItem(i))) return true;
        return !ReactorLookup.curios(p, ThanosEntity::isGauntlet).isEmpty(); // anche negli slot Curios (hands)
    }

    private static ItemStack takeGauntlet(Player p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (isGauntlet(s)) {
                inv.setItem(i, ItemStack.EMPTY);
                return s;
            }
        }
        return ReactorLookup.takeCurio(p, ThanosEntity::isGauntlet);
    }

    private void say(String text) {
        if (!(level() instanceof ServerLevel sl)) return;
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(this) < 4096.0) p.sendSystemMessage(Component.literal("<Thanos> " + text));
        }
    }

    private void title(String text) {
        if (!(level() instanceof ServerLevel sl)) return;
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(this) < 4096.0) {
                p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 15));
                p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(text)));
            }
        }
    }

    private static Vector3f rainbow(float h) {
        int c = Mth.hsvToRgb(h - (float) Math.floor(h), 1.0f, 1.0f);
        return new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f);
    }

    private void rainbowBurst(ServerLevel sl, Vec3 at, int perColor, double spread) {
        for (int k = 0; k < 6; k++) {
            sl.sendParticles(new DustParticleOptions(rainbow(k / 6f), 2.0f), at.x, at.y, at.z, perColor, spread, spread, spread, 0);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (hasGauntlet() && tickCount % 2 == 0) { // particelle arcobaleno sul corpo: ha le sei gemme alla mano sinistra
                Vector3f c = rainbow(tickCount / 40f + random.nextFloat() * 0.2f);
                level().addParticle(new DustParticleOptions(c, 1.4f), getX() + (random.nextDouble() - 0.5) * 1.2,
                        getY() + random.nextDouble() * 2.6, getZ() + (random.nextDouble() - 0.5) * 1.2, 0, 0, 0);
            }
            return;
        }
        ServerLevel sl = (ServerLevel) level();
        bar.setProgress(Mth.clamp(getHealth() / getMaxHealth(), 0f, 1f));

        if (sequence) {
            sequenceTick(sl);
            return;
        }
        LivingEntity target = getTarget();

        // 1) vede il guanto: lo vuole indietro
        if (!checked && target instanceof Player tp && tp.isAlive()) {
            checked = true;
            if (hasGauntlet(tp)) {
                victim = tp.getUUID();
                reach = 50;
                setNoAi(true);
                entityData.set(REACHING, true);
                say("You stole my Gauntlet. I'm taking it back.");
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.0f, 0.6f);
            }
        }
        if (reach > 0) {
            reach--;
            Player v = victim == null ? null : sl.getPlayerByUUID(victim);
            if (v != null) {
                getLookControl().setLookAt(v, 60f, 60f);
                // il guanto viene attirato verso la sua mano
                Vec3 from = v.position().add(0, 1.0, 0);
                Vec3 to = position().add(0, 1.8, 0);
                for (int i = 0; i <= 10; i++) {
                    Vec3 q = from.lerp(to, i / 10.0);
                    sl.sendParticles(new DustParticleOptions(rainbow(i / 10f + tickCount / 20f), 1.6f), q.x, q.y, q.z, 2, 0.1, 0.1, 0.1, 0);
                }
            }
            if (reach == 25 && v != null) {
                ItemStack g = takeGauntlet(v);
                if (!g.isEmpty()) {
                    stolen = g;
                    entityData.set(GAUNTLET, true);
                    sl.playSound(null, getX(), getY(), getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 1.5f, 0.7f);
                    if (v instanceof ServerPlayer sp) sp.displayClientMessage(Component.translatable("msg.ironmanmod.thanos_took"), true);
                }
            }
            if (reach == 0) {
                entityData.set(REACHING, false);
                setNoAi(false);
            }
            return;
        }

        // 2) attacchi speciali
        if (target != null && target.isAlive()) {
            if (tickCount % 100 == 0 && distanceToSqr(target) < 400.0) powerBurst(sl);
            if (hasGauntlet() && tickCount % 140 == 70) gemStrike(sl, target);
        }

        // 3) a 20 di vita: finale
        if (!done && getHealth() > 0 && getHealth() <= END_HEALTH) startSequence(sl);
    }

    private void powerBurst(ServerLevel sl) {
        sl.sendParticles(new DustParticleOptions(new Vector3f(0.67f, 0.16f, 1.0f), 3.0f), getX(), getY() + 1.0, getZ(), 220, 2.5, 1.2, 2.5, 0);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.5f, 0.6f);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(6.0), x -> x != this && x.isAlive())) {
            t.hurt(damageSources().mobAttack(this), 10f);
            Vec3 d = t.position().subtract(position()).normalize();
            t.push(d.x * 1.6, 0.6, d.z * 1.6);
            t.hurtMarked = true;
        }
    }

    private void gemStrike(ServerLevel sl, LivingEntity target) {
        LightningBolt lb = EntityType.LIGHTNING_BOLT.create(sl);
        if (lb != null) {
            lb.moveTo(target.getX(), target.getY(), target.getZ());
            lb.setVisualOnly(true);
            sl.addFreshEntity(lb);
        }
        target.hurt(damageSources().magic(), 12f);
        switch (random.nextInt(4)) {
            case 0 -> target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3)); // tempo
            case 1 -> target.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));            // realta'
            case 2 -> target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, 1));          // mente
            default -> heal(15f);                                                                      // anima
        }
        rainbowBurst(sl, target.position().add(0, 1.0, 0), 20, 0.8);
    }

    // ------------------------------------------------------------------ finale

    private void startSequence(ServerLevel sl) {
        sequence = true;
        seq = 0;
        setNoAi(true);
        setTarget(null);
        hero = null;
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(this) < 2304.0 && SuitData.activeMark(p) == SuitMark.MARK_85) {
                hero = p.getUUID();
                break;
            }
        }
    }

    private void sequenceTick(ServerLevel sl) {
        seq++;
        getNavigation().stop();
        Player h = hero == null ? null : sl.getPlayerByUUID(hero);
        if (seq == 1) {
            say("I AM INEVITABLE.");
            title("I AM INEVITABLE.");
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 3.0f, 0.5f);
        }
        if (seq % 4 == 0 && hasGauntlet()) rainbowBurst(sl, position().add(0, 1.0, 0), 6, 1.2);

        if (h == null) { // senza Mark 85: schiocca davvero
            if (seq == 40) {
                snapEffect(sl);
                if (hasGauntlet()) {
                    for (ServerPlayer p : sl.players()) {
                        if (p.distanceToSqr(this) < 2304.0 && !p.isCreative()) p.setHealth(Math.max(1f, p.getHealth() / 2f));
                    }
                    say("Perfectly balanced, as all things should be.");
                }
                finish();
            }
            return;
        }
        switch (seq) {
            case 40 -> { // Thanos schiocca, ma non succede niente
                snapEffect(sl);
            }
            case 70 -> say("The stones... Where are the stones?");
            case 110 -> {
                title("I AM IRON MAN.");
                for (ServerPlayer p : sl.players()) {
                    if (p.distanceToSqr(this) < 4096.0) p.sendSystemMessage(Component.literal("<" + h.getGameProfile().getName() + "> I am Iron Man."));
                }
            }
            case 130 -> { // schiocca Iron Man con le gemme nel guanto nanotech
                rainbowBurst(sl, h.position().add(0, 1.0, 0), 80, 1.6);
                sl.playSound(null, h.getX(), h.getY(), h.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 3.0f, 1.0f);
                sl.playSound(null, h.getX(), h.getY(), h.getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 2.0f, 1.5f);
                if (!h.isCreative()) h.setHealth(1.0f); // mezzo cuore
            }
            case 150 -> {
                sequence = false;
                done = true;
                setNoAi(false);
                hurt(damageSources().playerAttack(h), 100000f);
            }
            default -> { }
        }
    }

    private void snapEffect(ServerLevel sl) {
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.HOSTILE, 3.0f, 0.5f);
        sl.sendParticles(ParticleTypes.FLASH, getX(), getY() + 2.0, getZ(), 1, 0, 0, 0, 0);
        rainbowBurst(sl, position().add(0, 1.8, 0), 40, 1.5);
    }

    private void finish() {
        sequence = false;
        done = true;
        setNoAi(false);
    }

    // ------------------------------------------------------------------ salvataggio

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putBoolean("Glove", hasGauntlet());
        t.put("Stolen", stolen.save(new CompoundTag()));
        t.putBoolean("Checked", checked);
        t.putBoolean("Done", done);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        entityData.set(GAUNTLET, t.getBoolean("Glove"));
        stolen = ItemStack.of(t.getCompound("Stolen"));
        checked = t.getBoolean("Checked");
        done = t.getBoolean("Done");
    }
}
