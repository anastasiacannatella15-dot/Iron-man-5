package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityStruckByLightningEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/** Poteri del Mjolnir (lancio, richiamo, fulmine, tempesta) e regole degli oggetti a terra. */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public final class Mjolnir {
    public static final int A_THROW = 10, A_RECALL = 11, A_BOLT = 12, A_STORM = 13, A_LOCK = 14, A_STRIKE = 15;
    public static final float STRIKE_DAMAGE = 60f;
    public static final float BOLT_DAMAGE = 14f;

    private Mjolnir() {
    }

    /** Effetti passivi delle gemme incastonate, mentre tieni il Mjolnir in mano. */
    @SubscribeEvent
    public static void onPlayerTick(net.minecraftforge.event.TickEvent.PlayerTickEvent e) {
        if (e.phase != net.minecraftforge.event.TickEvent.Phase.END || e.player.level().isClientSide || e.player.tickCount % 20 != 0) return;
        ItemStack h = e.player.getMainHandItem();
        if (!(h.getItem() instanceof MjolnirItem) || !MjolnirItem.worthy(h, e.player)) return;
        for (String g : MjolnirGems.list(h)) {
            net.minecraft.world.effect.MobEffect fx = switch (g) {
                case "power" -> net.minecraft.world.effect.MobEffects.DAMAGE_BOOST;
                case "space" -> net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED;
                case "reality" -> net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE;
                case "time" -> net.minecraft.world.effect.MobEffects.DIG_SPEED;
                case "soul" -> net.minecraft.world.effect.MobEffects.REGENERATION;
                case "mind" -> net.minecraft.world.effect.MobEffects.NIGHT_VISION;
                default -> null;
            };
            if (fx != null) e.player.addEffect(new net.minecraft.world.effect.MobEffectInstance(fx, 80, g.equals("mind") ? 0 : 1, false, false, true));
        }
    }

    public static boolean isAction(int a) {
        return a >= A_THROW && a <= A_STRIKE;
    }

    private static boolean holding(ServerPlayer p) {
        ItemStack s = p.getMainHandItem();
        if (!(s.getItem() instanceof MjolnirItem)) {
            SuitData.msg(p, "msg.ironmanmod.mj_hold");
            return false;
        }
        return MjolnirItem.worthy(s, p);
    }

    public static void handleAction(ServerPlayer p, int a) {
        ServerLevel lvl = p.serverLevel();
        switch (a) {
            case A_THROW -> {
                if (!holding(p) || !SuitData.ready(p, "mjt")) return;
                SuitData.setCooldown(p, "mjt", 10);
                ItemStack st = p.getMainHandItem();
                Vec3 look = p.getLookAngle();
                MjolnirEntity m = new MjolnirEntity(lvl);
                m.setStack(st.copy());
                Vec3 pos = p.getEyePosition().add(look.scale(0.8)).subtract(0, 0.3, 0);
                m.setPos(pos.x, pos.y, pos.z);
                m.setDeltaMovement(look.scale(1.7));
                m.setNoGravity(true);
                m.setState(MjolnirEntity.THROWN);
                lvl.addFreshEntity(m);
                p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
                lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 1.0f, 0.8f);
            }
            case A_RECALL -> {
                List<MjolnirEntity> l = lvl.getEntitiesOfClass(MjolnirEntity.class, p.getBoundingBox().inflate(200),
                        m -> p.getUUID().equals(MjolnirItem.owner(m.getStack())));
                if (l.isEmpty()) {
                    SuitData.msg(p, "msg.ironmanmod.mj_none");
                    return;
                }
                for (MjolnirEntity m : l) m.recall(p);
                lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.6f, 1.6f);
            }
            case A_BOLT -> {
                if (!holding(p) || !SuitData.ready(p, "mjb")) return;
                SuitData.setCooldown(p, "mjb", 15);
                Vec3 eye = p.getEyePosition();
                Vec3 end = eye.add(p.getLookAngle().scale(80));
                BlockHitResult bh = lvl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                Vec3 at = bh.getType() != HitResult.Type.MISS ? bh.getLocation() : end;
                immune(p);
                bolt(p, at);
            }
            case A_STORM -> {
                if (!holding(p) || !SuitData.ready(p, "mjs")) return;
                SuitData.setCooldown(p, "mjs", 100);
                immune(p);
                for (int i = 0; i < 10; i++) {
                    double ang = Math.PI * 2 * i / 10 + p.getRandom().nextDouble() * 0.4;
                    double r = 6 + p.getRandom().nextDouble() * 5;
                    Vec3 at = new Vec3(p.getX() + Math.cos(ang) * r, p.getY(), p.getZ() + Math.sin(ang) * r);
                    // porta il fulmine sul terreno
                    BlockHitResult bh = lvl.clip(new ClipContext(at.add(0, 12, 0), at.add(0, -24, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                    if (bh.getType() != HitResult.Type.MISS) at = bh.getLocation();
                    bolt(p, at);
                }
                lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 60, 1.5, 1.2, 1.5, 0.3);
            }
            case A_LOCK -> {
                if (!holding(p)) return;
                ItemStack st = p.getMainHandItem();
                var tag = st.getOrCreateTag();
                if (tag.getBoolean("Locked")) {
                    tag.remove("Locked");
                    tag.remove("Owner");
                    tag.remove("OwnerName");
                    SuitData.msg(p, "msg.ironmanmod.mj_unlocked");
                } else {
                    tag.putBoolean("Locked", true);
                    tag.putUUID("Owner", p.getUUID());
                    tag.putString("OwnerName", p.getGameProfile().getName());
                    SuitData.msg(p, "msg.ironmanmod.mj_locked");
                }
                lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 0.8f);
            }
            case A_STRIKE -> {
                // lancio con F: il martello vola verso il mob, fa tantissimo danno e torna subito nella tua mano
                if (!holding(p) || !SuitData.ready(p, "mjk")) return;
                SuitData.setCooldown(p, "mjk", 12);
                ItemStack st = p.getMainHandItem();
                Vec3 look = p.getLookAngle();
                MjolnirEntity m = new MjolnirEntity(lvl);
                m.setStack(st.copy());
                Vec3 pos = p.getEyePosition().add(look.scale(0.8)).subtract(0, 0.3, 0);
                m.setPos(pos.x, pos.y, pos.z);
                m.setDeltaMovement(look.scale(MjolnirGems.has(st, "space") ? 4.0 : 2.6));
                m.setNoGravity(true);
                m.setInstant(p, STRIKE_DAMAGE * (MjolnirGems.has(st, "power") ? 1.5f : 1f));
                m.setState(MjolnirEntity.THROWN);
                lvl.addFreshEntity(m);
                p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
                immune(p);
                lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 1.0f, 0.7f);
            }
            default -> {
            }
        }
    }

    private static void immune(ServerPlayer p) {
        p.getPersistentData().putLong("mj_immune", p.level().getGameTime() + 60);
    }

    private static void bolt(ServerPlayer p, Vec3 pos) {
        ServerLevel lvl = p.serverLevel();
        LightningBolt lb = EntityType.LIGHTNING_BOLT.create(lvl);
        if (lb == null) return;
        lb.moveTo(pos.x, pos.y, pos.z);
        lb.setCause(p);
        lvl.addFreshEntity(lb);
        for (LivingEntity e : lvl.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(3.5, 3, 3.5),
                x -> x != p && x.isAlive())) {
            e.hurt(p.damageSources().playerAttack(p), BOLT_DAMAGE);
            e.setSecondsOnFire(5);
        }
    }

    /** Chi tiene il Mjolnir e' immune ai suoi fulmini. */
    @SubscribeEvent
    public static void onStruck(EntityStruckByLightningEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        boolean holds = p.getMainHandItem().getItem() instanceof MjolnirItem || p.getOffhandItem().getItem() instanceof MjolnirItem;
        if (holds || p.level().getGameTime() < p.getPersistentData().getLong("mj_immune")) e.setCanceled(true);
    }

    /** Un Mjolnir che cade a terra diventa un'entita': non si raccoglie passandoci sopra, ma con il tasto destro. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (!(e.getEntity() instanceof ItemEntity ie) || !(ie.getItem().getItem() instanceof MjolnirItem)) return;
        e.setCanceled(true);
        if (e.getLevel().isClientSide) return;
        MjolnirEntity m = new MjolnirEntity(e.getLevel());
        m.setStack(ie.getItem().copy());
        m.setPos(ie.getX(), ie.getY(), ie.getZ());
        m.setDeltaMovement(ie.getDeltaMovement().scale(0.6));
        e.getLevel().addFreshEntity(m);
    }
}
