package com.ironmanmod;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Siero gamma: ti trasforma in Hulk per 5 minuti. */
public class GammaSerumItem extends Item {
    public GammaSerumItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (level.isClientSide || !(p instanceof ServerPlayer sp)) return InteractionResultHolder.success(st);
        if (Hulk.isHulk(sp)) {
            SuitData.msg(sp, "msg.ironmanmod.hulk_already");
            return InteractionResultHolder.fail(st);
        }
        Hulk.transform(sp);
        if (!p.isCreative()) {
            st.shrink(1);
            ItemStack empty = new ItemStack(ModContent.EMPTY_SYRINGE.get());
            if (!p.getInventory().add(empty)) p.drop(empty, false);
        }
        return InteractionResultHolder.success(st);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("tooltip.ironmanmod.gamma").withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
