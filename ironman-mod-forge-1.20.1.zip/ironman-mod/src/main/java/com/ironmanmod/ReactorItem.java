package com.ironmanmod;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;

import java.util.function.Consumer;

/** Reattore Arc: si indossa nello slot del petto. Da indossato permette la trasformazione nanotech. */
public class ReactorItem extends ArmorItem {
    public final SuitMark mark;

    public ReactorItem(SuitMark mark) {
        super(ReactorMaterial.of(mark), ArmorItem.Type.CHESTPLATE,
                new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
        this.mark = mark;
    }

    public static boolean suitOn(ItemStack s) {
        return s.getTag() != null && s.getTag().getBoolean("Suit");
    }

    @Override
    public String getArmorTexture(ItemStack stack, net.minecraft.world.entity.Entity entity, net.minecraft.world.entity.EquipmentSlot slot, String type) {
        return suitOn(stack) ? "ironmanmod:textures/models/armor/" + mark.id + "_model.png" : null;
    }

    @Override
    public void initializeClient(Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer) {
        consumer.accept(new net.minecraftforge.client.extensions.common.IClientItemExtensions() {
            @Override
            public net.minecraft.client.model.HumanoidModel<?> getHumanoidArmorModel(LivingEntity e, ItemStack st,
                    net.minecraft.world.entity.EquipmentSlot slot, net.minecraft.client.model.HumanoidModel<?> original) {
                if (!suitOn(st)) return original;
                var m = com.ironmanmod.client.SuitModels.getFull(mark.id);
                m.leftArm.visible = !com.ironmanmod.client.ArmorHands.leftBusy(e);
                return m;
            }
        });
    }

    @Override
    public <T extends LivingEntity> int damageItem(ItemStack stack, int amount, T entity, Consumer<T> onBroken) {
        return 0;
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return false;
    }

    @Override
    public boolean isBookEnchantable(ItemStack stack, ItemStack book) {
        return false;
    }
}
