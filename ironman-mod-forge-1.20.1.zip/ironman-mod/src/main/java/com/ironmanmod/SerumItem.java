package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** Siero del dio del tuono (diventi Thor) o del super soldato (diventi Captain America): si inietta con il tasto destro, restituisce la siringa vuota. */
public class SerumItem extends Item {
    private final String key;

    public SerumItem(String key) {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
        this.key = key;
    }

    private boolean thor() {
        return key.equals(Worthy.THOR);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (p.getPersistentData().getBoolean(key)) {
            if (!level.isClientSide) p.displayClientMessage(Component.translatable("msg.ironmanmod.serum_already"), true);
            return InteractionResultHolder.fail(st);
        }
        if (!level.isClientSide && level instanceof ServerLevel sl) {
            p.getPersistentData().putBoolean(key, true);
            p.heal(p.getMaxHealth());
            if (thor()) {
                LightningBolt lb = EntityType.LIGHTNING_BOLT.create(sl);
                if (lb != null) {
                    lb.moveTo(p.getX(), p.getY(), p.getZ());
                    lb.setVisualOnly(true);
                    sl.addFreshEntity(lb);
                }
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 80, 0.6, 1.0, 0.6, 0.4);
                p.displayClientMessage(Component.translatable("msg.ironmanmod.serum_thor"), false);
            } else {
                sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1.0, p.getZ(), 60, 0.5, 1.0, 0.5, 0.3);
                p.displayClientMessage(Component.translatable("msg.ironmanmod.serum_soldier", Worthy.KILLS_NEEDED), false);
            }
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2f, 1.2f);
            if (!p.isCreative()) {
                st.shrink(1);
                ItemStack empty = new ItemStack(ModContent.EMPTY_SYRINGE.get());
                if (!p.getInventory().add(empty)) p.drop(empty, false);
            }
        }
        return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable(thor() ? "tooltip.ironmanmod.serum_thor" : "tooltip.ironmanmod.serum_soldier")
                .withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
