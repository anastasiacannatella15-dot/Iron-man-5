package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Lo scudo di Captain America lanciato: colpisce, rimbalza sui bersagli vicini e sui muri, poi torna da te. */
public class ShieldEntity extends Entity {
    private static final EntityDataAccessor<ItemStack> STACK = SynchedEntityData.defineId(ShieldEntity.class, EntityDataSerializers.ITEM_STACK);
    private static final float DMG_MOB = 12f, DMG_PLAYER = 8f;
    private static final int MAX_TARGET_BOUNCES = 4, MAX_WALL_BOUNCES = 5;

    private UUID owner;
    private boolean returning;
    private int bounces, life;
    private final Set<Integer> hit = new HashSet<>();

    public ShieldEntity(EntityType<? extends ShieldEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(STACK, ItemStack.EMPTY);
    }

    public ItemStack getStack() {
        return entityData.get(STACK);
    }

    public UUID owner() {
        return owner;
    }

    /** Lancia lo scudo che hai in mano nella direzione in cui guardi. */
    public static void throwFrom(ServerPlayer p) {
        ItemStack st = p.getMainHandItem();
        ShieldEntity s = new ShieldEntity(IronManMod.SHIELD.get(), p.level());
        s.entityData.set(STACK, st.copy());
        s.owner = p.getUUID();
        Vec3 look = p.getLookAngle();
        Vec3 pos = p.getEyePosition().add(look.scale(0.8)).subtract(0, 0.3, 0);
        s.setPos(pos.x, pos.y, pos.z);
        s.setDeltaMovement(look.scale(1.8));
        s.setNoGravity(true);
        p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        p.level().addFreshEntity(s);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 1.0f, 1.4f);
    }

    public void recall() {
        startReturn();
    }

    private void startReturn() {
        returning = true;
        noPhysics = true;
        hit.clear();
        life = 0;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        Player p = owner == null ? null : level().getPlayerByUUID(owner);
        if (p == null || !p.isAlive()) { // senza proprietario lo scudo cade a terra come oggetto
            spawnAtLocation(getStack());
            discard();
            return;
        }
        life++;
        if (returning) {
            flyBack(p);
            return;
        }
        Vec3 dm = getDeltaMovement();
        AABB sweep = getBoundingBox().expandTowards(dm).inflate(0.6);
        move(MoverType.SELF, dm);
        boolean redirected = false;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, sweep.minmax(getBoundingBox().inflate(0.6)),
                x -> x.isAlive() && x != p && !hit.contains(x.getId()))) {
            hit.add(e.getId());
            e.hurt(damageSources().thrown(this, p), e instanceof Player ? DMG_PLAYER : DMG_MOB);
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0f, 1.3f);
            if (level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.CRIT, e.getX(), e.getY() + 1, e.getZ(), 15, 0.3, 0.4, 0.3, 0.2);
            LivingEntity next = null;
            double best = 100.0; // al massimo 10 blocchi
            for (LivingEntity c : level().getEntitiesOfClass(LivingEntity.class, e.getBoundingBox().inflate(10),
                    x -> x.isAlive() && x != p && x != e && !hit.contains(x.getId()))) {
                double d = c.distanceToSqr(e);
                if (d < best) {
                    best = d;
                    next = c;
                }
            }
            if (next != null && bounces < MAX_TARGET_BOUNCES) {
                bounces++;
                Vec3 dir = next.position().add(0, next.getBbHeight() / 2, 0).subtract(position()).normalize();
                setDeltaMovement(dir.scale(1.8));
            } else {
                startReturn();
            }
            redirected = true;
            break;
        }
        if (!redirected && !returning) {
            Vec3 now = getDeltaMovement();
            double x = now.x, y = now.y, z = now.z;
            boolean wall = false;
            if (horizontalCollision) {
                if (Math.abs(now.x) < 1e-4 && Math.abs(dm.x) > 1e-4) {
                    x = -dm.x;
                    wall = true;
                }
                if (Math.abs(now.z) < 1e-4 && Math.abs(dm.z) > 1e-4) {
                    z = -dm.z;
                    wall = true;
                }
            }
            if (verticalCollision && Math.abs(now.y) < 1e-4 && Math.abs(dm.y) > 1e-4) {
                y = -dm.y;
                wall = true;
            }
            if (wall) {
                setDeltaMovement(x, y, z);
                hit.clear();
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 0.8f, 0.9f);
                if (++bounces > MAX_WALL_BOUNCES) startReturn();
            }
        }
        if (life > 80 && !returning) startReturn();
        if (level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.CRIT, getX(), getY(), getZ(), 2, 0.2, 0.2, 0.2, 0.02);
    }

    private void flyBack(Player p) {
        Vec3 to = p.position().add(0, p.getBbHeight() * 0.5, 0).subtract(position());
        double d = to.length();
        if (d < 1.3 || life > 200) {
            giveTo(p);
            return;
        }
        Vec3 v = to.scale(1.0 / d).scale(Math.min(1.8, Math.max(0.6, d * 0.5)));
        setDeltaMovement(v);
        setPos(getX() + v.x, getY() + v.y, getZ() + v.z);
    }

    private void giveTo(Player p) {
        ItemStack s = getStack().copy();
        if (p.getMainHandItem().isEmpty()) p.setItemInHand(InteractionHand.MAIN_HAND, s);
        else if (!p.getInventory().add(s)) p.drop(s, false);
        level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.TRIDENT_RETURN, SoundSource.PLAYERS, 1.0f, 1.4f);
        discard();
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag t) {
        entityData.set(STACK, ItemStack.of(t.getCompound("Stack")));
        if (t.hasUUID("Owner")) owner = t.getUUID("Owner");
        returning = t.getBoolean("Returning");
        noPhysics = returning;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag t) {
        t.put("Stack", getStack().save(new CompoundTag()));
        if (owner != null) t.putUUID("Owner", owner);
        t.putBoolean("Returning", returning);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(net.minecraft.world.damagesource.DamageSource src) {
        return true;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
