package com.ironmanmod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

/** Armatura Iron Man in modalita' sentinella: segue il proprietario, attacca i mob, 50 di vita; se muore droppa l'armatura. */
public class SentinelEntity extends PathfinderMob {
    private static final net.minecraft.network.syncher.EntityDataAccessor<Boolean> OPEN =
            net.minecraft.network.syncher.SynchedEntityData.defineId(SentinelEntity.class, net.minecraft.network.syncher.EntityDataSerializers.BOOLEAN);
    private static final DustParticleOptions BEAM = new DustParticleOptions(new Vector3f(1.0f, 0.88f, 0.12f), 0.9f);
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private UUID owner;
    private int fireCd;

    public SentinelEntity(EntityType<? extends SentinelEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        for (EquipmentSlot s : ARMOR) setDropChance(s, 2.0f); // >1 = droppa sempre l'armatura
    }

    public static AttributeSupplier.Builder attributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 50.0)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.ARMOR, 20.0)
                .add(Attributes.ARMOR_TOUGHNESS, 2.5)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(OPEN, false);
    }

    public boolean isOpen() {
        return entityData.get(OPEN);
    }

    public void setOwner(Player p) {
        owner = p.getUUID();
    }

    private Player owner() {
        return owner == null ? null : level().getPlayerByUUID(owner);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new FightGoal());
        goalSelector.addGoal(2, new FollowGoal());
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0f));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player p, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (owner != null && !p.getUUID().equals(owner)) return InteractionResult.PASS;
        if (!level().isClientSide) {
            boolean open = !isOpen();
            entityData.set(OPEN, open);
            getNavigation().stop();
            setTarget(null);
            if (open) {
                setCustomName(Component.translatable("msg.ironmanmod.sentinel_open"));
                setCustomNameVisible(true);
                playSound(SoundEvents.IRON_TRAPDOOR_OPEN, 1.0f, 0.7f);
            } else {
                setCustomName(null);
                setCustomNameVisible(false);
                playSound(SoundEvents.IRON_TRAPDOOR_CLOSE, 1.0f, 0.7f);
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void tick() {
        super.tick();
        if (fireCd > 0) fireCd--;
        if (level() instanceof ServerLevel sl) {
            if (isOpen()) {
                // schiena aperta: scintille; se il proprietario ci cammina incontro, la indossa
                if (tickCount % 4 == 0) {
                    double yaw = Math.toRadians(yBodyRot);
                    sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX() + Math.sin(yaw) * 0.35, getY() + 1.3, getZ() - Math.cos(yaw) * 0.35, 3, 0.15, 0.3, 0.15, 0.02);
                    sl.sendParticles(ParticleTypes.END_ROD, getX() + Math.sin(yaw) * 0.3, getY() + 1.2, getZ() - Math.cos(yaw) * 0.3, 1, 0.1, 0.3, 0.1, 0.01);
                }
                Player o = owner();
                if (o != null && !o.isSpectator() && o.distanceToSqr(this) < 2.4 * 2.4) giveTo(o);
            }
        }
    }

    /** Il giocatore entra nell'armatura: i 4 pezzi passano agli slot armatura. */
    private void giveTo(Player p) {
        for (EquipmentSlot s : ARMOR) {
            ItemStack st = getItemBySlot(s);
            if (st.isEmpty()) continue;
            if (p.getItemBySlot(s).isEmpty()) p.setItemSlot(s, st.copy());
            else if (!p.getInventory().add(st.copy())) p.drop(st.copy(), false);
            setItemSlot(s, ItemStack.EMPTY);
        }
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ARMOR_EQUIP_NETHERITE, SoundSource.PLAYERS, 1.0f, 1.0f);
        }
        discard();
    }

    // il proprietario non fa danno alla sua armatura
    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (owner != null && src.getEntity() != null && src.getEntity().getUUID().equals(owner)) return false;
        return super.hurt(src, amount);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource s) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.IRON_GOLEM_DEATH;
    }

    @Override
    public boolean removeWhenFarAway(double d) {
        return false;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        if (owner != null) t.putUUID("Owner", owner);
        t.putBoolean("Open", isOpen());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        if (t.hasUUID("Owner")) owner = t.getUUID("Owner");
        entityData.set(OPEN, t.getBoolean("Open"));
        if (isOpen()) {
            setCustomName(Component.translatable("msg.ironmanmod.sentinel_open"));
            setCustomNameVisible(true);
        }
    }

    // ------------------------------------------------------------------ AI

    private class FightGoal extends Goal {
        private LivingEntity target;

        FightGoal() {
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (isOpen()) return false;
            target = pick();
            return target != null;
        }

        @Override
        public boolean canContinueToUse() {
            return !isOpen() && target != null && target.isAlive() && distanceToSqr(target) < 24 * 24;
        }

        private LivingEntity pick() {
            Player o = owner();
            Vec3 c = o != null ? o.position() : position();
            LivingEntity hurtMe = o != null ? o.getLastHurtByMob() : null;
            if (hurtMe != null && hurtMe.isAlive() && hurtMe != SentinelEntity.this && !(hurtMe instanceof Player)) return hurtMe;
            List<Monster> list = level().getEntitiesOfClass(Monster.class,
                    new net.minecraft.world.phys.AABB(c, c).inflate(18.0), m -> m.isAlive() && m instanceof Enemy);
            return list.stream().min(Comparator.comparingDouble(m -> m.distanceToSqr(SentinelEntity.this))).orElse(null);
        }

        @Override
        public void tick() {
            if (target == null) return;
            setTarget(target);
            getLookControl().setLookAt(target, 30f, 30f);
            double d = distanceTo(target);
            if (d > 7.0) getNavigation().moveTo(target, 1.25);
            else getNavigation().stop();
            if (fireCd <= 0 && d < 20.0 && hasLineOfSight(target) && level() instanceof ServerLevel sl) {
                fireCd = 14;
                Vec3 a = getEyePosition().add(0, -0.2, 0);
                Vec3 b = target.getEyePosition();
                Vec3 line = b.subtract(a);
                int steps = (int) Math.max(2, line.length() * 2);
                for (int i = 0; i <= steps; i++) {
                    Vec3 q = a.add(line.scale(i / (double) steps));
                    sl.sendParticles(BEAM, q.x, q.y, q.z, 1, 0, 0, 0, 0);
                }
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 0.6f, 1.8f);
                target.hurt(damageSources().mobAttack(SentinelEntity.this), 9.0f);
            }
        }

        @Override
        public void stop() {
            target = null;
            setTarget(null);
            getNavigation().stop();
        }
    }

    private class FollowGoal extends Goal {
        FollowGoal() {
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            Player o = owner();
            return !isOpen() && o != null && distanceToSqr(o) > 5.0 * 5.0;
        }

        @Override
        public boolean canContinueToUse() {
            Player o = owner();
            return !isOpen() && o != null && distanceToSqr(o) > 2.5 * 2.5;
        }

        @Override
        public void tick() {
            Player o = owner();
            if (o == null) return;
            if (distanceToSqr(o) > 26.0 * 26.0) {
                teleportTo(o.getX() + 1.5, o.getY(), o.getZ() + 1.5);
                getNavigation().stop();
            } else {
                getNavigation().moveTo(o, 1.2);
            }
        }
    }
}
