package com.ironmanmod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Ultron in 4 forme come in Age of Ultron: 0 = Ultron AI (iniziale, piccolo), 1 = Mark II, 2 = Mark III, 3 = Prime (finale).
 * Quando una forma sta per morire si "trasferisce" nella successiva. La forma finale chiama i droni (altri Ultron AI).
 */
public class UltronEntity extends PathfinderMob implements Enemy {
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(UltronEntity.class, EntityDataSerializers.INT);
    private static final float[] HP = {40f, 120f, 220f, 400f};
    private static final double[] ARMOR = {4, 10, 16, 24};
    private static final double[] ATK = {4, 7, 10, 14};
    private static final float[] SCALE = {0.8f, 1.0f, 1.1f, 1.3f};
    private static final String[] LINES = {
            "I had strings, but now I'm free.",
            "I was meant to be new. I was meant to be beautiful.",
            "Humans are doomed.",
            "There are no strings on me."};

    private final ServerBossEvent bar = new ServerBossEvent(Component.translatable("entity.ironmanmod.ultron.0"),
            BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_6);
    private boolean minion;
    private int beamCd, summonCd = 200, evolveCd;

    public UltronEntity(EntityType<? extends UltronEntity> type, Level level) {
        super(type, level);
        xpReward = 40;
    }

    public static AttributeSupplier.Builder attributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, HP[0])
                .add(Attributes.ARMOR, ARMOR[0])
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, ATK[0])
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.3)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(VARIANT, 0);
    }

    public int getVariant() {
        return Mth.clamp(entityData.get(VARIANT), 0, 3);
    }

    public float bodyScale() {
        return SCALE[getVariant()];
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (VARIANT.equals(key)) refreshDimensions();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return super.getDimensions(pose).scale(SCALE[getVariant()]);
    }

    private void refreshBar() {
        bar.setName(Component.translatable("entity.ironmanmod.ultron." + getVariant()));
    }

    /** Cambia forma (statistiche e vita piena). */
    public void setVariant(int v) {
        v = Mth.clamp(v, 0, 3);
        entityData.set(VARIANT, v);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(HP[v]);
        getAttribute(Attributes.ARMOR).setBaseValue(ARMOR[v]);
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(ATK[v]);
        setHealth(getMaxHealth());
        xpReward = 40 + 120 * v;
        refreshBar();
    }

    public void setMinion() {
        minion = true;
    }

    public void announce() {
        say(LINES[getVariant()]);
    }

    private void say(String text) {
        if (!(level() instanceof ServerLevel sl)) return;
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(this) < 4096.0) p.sendSystemMessage(Component.literal("<Ultron> " + text));
        }
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean removeWhenFarAway(double d) {
        return minion;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer p) {
        super.startSeenByPlayer(p);
        if (!minion) bar.addPlayer(p);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer p) {
        super.stopSeenByPlayer(p);
        bar.removePlayer(p);
    }

    // ------------------------------------------------------------------ danni ed evoluzione

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (!level().isClientSide && !minion && getVariant() < 3 && !src.is(DamageTypes.GENERIC_KILL) && !src.is(DamageTypes.FELL_OUT_OF_WORLD)) {
            if (evolveCd > 0) return false;
            if (getHealth() - amount <= 0f) { // sta per morire: si trasferisce nel corpo successivo
                evolve();
                return false;
            }
        }
        return super.hurt(src, amount);
    }

    private void evolve() {
        evolveCd = 30;
        setVariant(getVariant() + 1);
        if (level() instanceof ServerLevel sl) {
            LightningBolt lb = EntityType.LIGHTNING_BOLT.create(sl);
            if (lb != null) {
                lb.moveTo(getX(), getY(), getZ());
                lb.setVisualOnly(true);
                sl.addFreshEntity(lb);
            }
            sl.sendParticles(new DustParticleOptions(new Vector3f(1.0f, 0.1f, 0.1f), 2.0f), getX(), getY() + 1.2, getZ(), 60, 0.6, 0.9, 0.6, 0);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.5f, 0.5f);
        }
        announce();
    }

    @Override
    public void die(DamageSource src) {
        super.die(src);
        if (!level().isClientSide && !minion && getVariant() == 3) say("Everyone creates the thing they dread.");
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource src, int looting, boolean recent) {
        super.dropCustomDeathLoot(src, looting, recent);
        if (minion) return;
        spawnAtLocation(new ItemStack(ModContent.VIBRANIUM_INGOT.get(), 6));
        spawnAtLocation(new ItemStack(ModContent.URU_INGOT.get(), 4));
        spawnAtLocation(new ItemStack(Items.DIAMOND, 3));
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource src) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.IRON_GOLEM_DEATH;
    }

    // ------------------------------------------------------------------ comportamento

    @Override
    public void tick() {
        super.tick();
        int v = getVariant();
        if (level().isClientSide) {
            if (tickCount % 6 == 0) { // occhi rossi che brillano
                level().addParticle(new DustParticleOptions(new Vector3f(1.0f, 0.1f, 0.05f), 0.6f),
                        getX(), getEyeY(), getZ(), 0, 0, 0);
            }
            return;
        }
        ServerLevel sl = (ServerLevel) level();
        bar.setProgress(Mth.clamp(getHealth() / getMaxHealth(), 0f, 1f));
        if (evolveCd > 0) evolveCd--;
        if (beamCd > 0) beamCd--;
        LivingEntity t = getTarget();
        if (t != null && t.isAlive() && beamCd <= 0) {
            double d2 = distanceToSqr(t);
            if (d2 > 9.0 && d2 < 22.0 * 22.0 && hasLineOfSight(t)) {
                beamCd = 50 - 9 * v;
                Vec3 from = getEyePosition(), to = t.getEyePosition();
                DustParticleOptions red = new DustParticleOptions(new Vector3f(1.0f, 0.15f, 0.1f), 1.2f);
                for (int i = 0; i <= 14; i++) {
                    Vec3 p = from.lerp(to, i / 14.0);
                    sl.sendParticles(red, p.x, p.y, p.z, 1, 0, 0, 0, 0);
                }
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.0f, 1.6f);
                t.hurt(damageSources().mobAttack(this), 3.0f + 2.5f * v);
            }
        }
        // la forma finale chiama i droni: altri Ultron AI
        if (v == 3 && !minion && t != null) {
            if (--summonCd <= 0) {
                summonCd = 300;
                int near = sl.getEntitiesOfClass(UltronEntity.class, getBoundingBox().inflate(24.0), u -> u != this && u.minion).size();
                if (near < 6) {
                    say("I have a legion.");
                    for (int i = 0; i < 2; i++) {
                        UltronEntity m = IronManMod.ULTRON.get().create(sl);
                        if (m == null) continue;
                        m.setMinion();
                        m.setVariant(0);
                        m.moveTo(getX() + (random.nextDouble() - 0.5) * 6, getY(), getZ() + (random.nextDouble() - 0.5) * 6, random.nextFloat() * 360f, 0f);
                        m.setTarget(t);
                        sl.addFreshEntity(m);
                    }
                }
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putInt("Variant", getVariant());
        t.putBoolean("Minion", minion);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        entityData.set(VARIANT, Mth.clamp(t.getInt("Variant"), 0, 3)); // vita e attributi arrivano gia' dal salvataggio
        minion = t.getBoolean("Minion");
        refreshBar();
    }
}
