package com.ironmanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;

/**
 * Il pianeta Titano (dimensione ironmanmod:titan). Si apre un portale con la Gemma dello Spazio o il Tesseract in mano:
 * Maiusc + tasto destro, resta fermo vicino al portale per 4 secondi. Lo stesso gesto su Titano ti riporta indietro.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public final class Titan {
    public static final ResourceKey<Level> TITAN = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(IronManMod.MODID, "titan"));
    private static final String PORTAL = "titan_portal";
    private static final String ORIGIN = "titan_origin";
    private static final int OPEN_TICKS = 80;

    private Titan() {
    }

    private static boolean isKey(ItemStack s) {
        if (s.isEmpty()) return false;
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        return k != null && k.getNamespace().equals("infinity") && (k.getPath().equals("space_stone") || k.getPath().equals("tesseract"));
    }

    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickItem e) {
        Player p = e.getEntity();
        if (p.level().isClientSide || e.getHand() != InteractionHand.MAIN_HAND || !p.isShiftKeyDown()) return;
        if (!isKey(p.getMainHandItem()) || p.getOffhandItem().getItem() instanceof MjolnirItem) return; // con il martello in mano la gemma si incastona
        CompoundTag d = p.getPersistentData();
        if (d.getLong(PORTAL) > 0) return;
        double yaw = Math.toRadians(p.getYRot());
        d.putLong(PORTAL, p.level().getGameTime() + OPEN_TICKS);
        d.putDouble("titan_cx", p.getX() - Math.sin(yaw) * 2.0);
        d.putDouble("titan_cy", p.getY() + 1.2);
        d.putDouble("titan_cz", p.getZ() + Math.cos(yaw) * 2.0);
        d.putDouble("titan_yaw", yaw);
        if (p instanceof ServerPlayer sp) SuitData.msg(sp, "msg.ironmanmod.portal_open");
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.2f, 0.6f);
        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide || !(e.player instanceof ServerPlayer sp)) return;
        CompoundTag d = sp.getPersistentData();
        long end = d.getLong(PORTAL);
        if (end == 0) return;
        ServerLevel sl = sp.serverLevel();
        double cx = d.getDouble("titan_cx"), cy = d.getDouble("titan_cy"), cz = d.getDouble("titan_cz"), yaw = d.getDouble("titan_yaw");
        if (sp.distanceToSqr(cx, cy, cz) > 36.0) { // si e' allontanato: il portale si chiude
            d.remove(PORTAL);
            SuitData.msg(sp, "msg.ironmanmod.portal_closed");
            return;
        }
        // anello verticale di particelle davanti a te
        double rx = Math.cos(yaw), rz = Math.sin(yaw);
        DustParticleOptions orange = new DustParticleOptions(new Vector3f(1.0f, 0.55f, 0.1f), 1.5f);
        for (int i = 0; i < 28; i++) {
            double a = Math.PI * 2 * i / 28 + sp.tickCount * 0.1;
            double u = Math.cos(a) * 1.3, v = Math.sin(a) * 1.7;
            double x = cx + rx * u, y = cy + v, z = cz + rz * u;
            sl.sendParticles(i % 2 == 0 ? orange : new DustParticleOptions(new Vector3f(0.4f, 0.6f, 1.0f), 1.4f), x, y, z, 1, 0, 0, 0, 0);
        }
        if (sp.tickCount % 5 == 0) sl.sendParticles(ParticleTypes.PORTAL, cx, cy, cz, 12, 0.6, 0.8, 0.6, 0.3);
        if (sl.getGameTime() >= end) {
            d.remove(PORTAL);
            travel(sp);
        }
    }

    /** Titano <-> mondo di partenza. */
    public static void travel(ServerPlayer p) {
        MinecraftServer srv = p.server;
        ServerLevel from = p.serverLevel();
        CompoundTag d = p.getPersistentData();
        if (from.dimension().equals(TITAN)) {
            ServerLevel dest = srv.overworld();
            double x, y, z;
            CompoundTag o = d.getCompound(ORIGIN);
            ServerLevel saved = o.contains("dim") ? srv.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(o.getString("dim")))) : null;
            if (saved != null) {
                dest = saved;
                x = o.getDouble("x");
                y = o.getDouble("y");
                z = o.getDouble("z");
            } else {
                BlockPos sp = dest.getSharedSpawnPos();
                x = sp.getX() + 0.5;
                z = sp.getZ() + 0.5;
                y = dest.getHeight(Heightmap.Types.MOTION_BLOCKING, sp.getX(), sp.getZ()) + 1.0;
            }
            p.teleportTo(dest, x, y, z, p.getYRot(), p.getXRot());
            SuitData.msg(p, "msg.ironmanmod.titan_back");
        } else {
            ServerLevel dest = srv.getLevel(TITAN);
            if (dest == null) {
                SuitData.msg(p, "msg.ironmanmod.titan_missing");
                return;
            }
            CompoundTag o = new CompoundTag();
            o.putString("dim", from.dimension().location().toString());
            o.putDouble("x", p.getX());
            o.putDouble("y", p.getY());
            o.putDouble("z", p.getZ());
            d.put(ORIGIN, o);
            int bx = p.getBlockX(), bz = p.getBlockZ();
            int h = dest.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
            p.teleportTo(dest, bx + 0.5, h + 1.0, bz + 0.5, p.getYRot(), p.getXRot());
            SuitData.msg(p, "msg.ironmanmod.titan_arrive");
            meetThanos(p, dest, bx, bz);
        }
        p.fallDistance = 0f;
        p.getPersistentData().putLong("mj_nofall", p.level().getGameTime() + 100);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 0.7f);
    }

    /** La prima volta che arrivi su Titano, Thanos ti aspetta poco lontano. */
    private static void meetThanos(ServerPlayer p, ServerLevel dest, int bx, int bz) {
        if (p.getPersistentData().getBoolean("thanos_met")) return;
        if (!dest.getEntitiesOfClass(ThanosEntity.class, p.getBoundingBox().inflate(150.0)).isEmpty()) return;
        p.getPersistentData().putBoolean("thanos_met", true);
        spawnThanos(dest, bx + 24, bz + 24, p.getYRot());
    }

    public static ThanosEntity spawnThanos(ServerLevel level, int x, int z, float yaw) {
        ThanosEntity t = IronManMod.THANOS.get().create(level);
        if (t == null) return null;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        t.moveTo(x + 0.5, y, z + 0.5, yaw + 180f, 0f);
        level.addFreshEntity(t);
        return t;
    }

    /** /titan (operatori): ti porta su Titano e ti riporta indietro. /titan thanos: fa comparire Thanos davanti a te. */
    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(net.minecraft.commands.Commands.literal("titan")
                .requires(s -> s.hasPermission(2))
                .executes(c -> {
                    travel(c.getSource().getPlayerOrException());
                    return 1;
                })
                .then(net.minecraft.commands.Commands.literal("thanos").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    double yaw = Math.toRadians(p.getYRot());
                    spawnThanos(p.serverLevel(), (int) (p.getX() - Math.sin(yaw) * 12), (int) (p.getZ() + Math.cos(yaw) * 12), p.getYRot());
                    p.sendSystemMessage(Component.literal("Thanos e' comparso"));
                    return 1;
                })));
    }
}
