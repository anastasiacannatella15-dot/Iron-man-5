package com.ironmanmod;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** I tre modelli di armatura. Funge anche da materiale armatura. */
public enum SuitMark implements ArmorMaterial {
    // num id  energia volo  boost  repulsore unibeam missili dannoSubito difesa(stivali,gambali,petto,casco)  tough  kb
    // Armor: tutte e tre 20 punti come diamante/netherite. Differenze: tenacia e riduzione extra del danno.
    MARK_42(42, "mark42", 3800, 0.082f, 1.9, 13f, 20f, 6, 0.78f, new int[]{3, 6, 8, 3}, 4.5f, 0.3f, true), // "Armatura Iron Man" generica: a meta' fra la Mark 8 e la Mark 50
    MARK_50(50, "mark50", 4500, 0.085f, 2.0, 13f, 30f, 6, 1.00f, new int[]{2, 5, 6, 2}, 5.0f, 0.5f, false),
    MARK_85(85, "mark85", 9000, 0.110f, 2.6, 16f, 40f, 8, 0.25f, new int[]{3, 6, 8, 3}, 6.0f, 0.5f, false),
    // armature "normali" (pezzi veri, niente nanotech, niente reattore), dopo le altre per non cambiare l'ordine
    MARK_2(2, "mark2", 800, 0.045f, 1.0, 6f, 0f, 0, 1.00f, new int[]{2, 5, 6, 2}, 1.0f, 0.0f, true),
    MARK_3(3, "mark3", 1400, 0.055f, 1.2, 8f, 0f, 2, 0.95f, new int[]{3, 5, 7, 3}, 2.0f, 0.0f, true),
    MARK_5(5, "mark5", 1700, 0.060f, 1.3, 9f, 0f, 3, 0.93f, new int[]{3, 6, 7, 3}, 2.0f, 0.0f, true),
    MARK_4(4, "mark4", 1100, 0.050f, 1.1, 7f, 0f, 1, 0.98f, new int[]{2, 5, 6, 2}, 1.5f, 0.0f, true),
    MARK_6(6, "mark6", 2200, 0.068f, 1.5, 11f, 0f, 4, 0.88f, new int[]{3, 6, 8, 3}, 3.0f, 0.0f, true),
    MARK_7(7, "mark7", 3000, 0.075f, 1.7, 12f, 0f, 6, 0.85f, new int[]{3, 6, 8, 3}, 3.5f, 0.1f, true),
    MARK_8(8, "mark8", 3200, 0.078f, 1.8, 13f, 0f, 6, 0.82f, new int[]{3, 6, 8, 3}, 4.0f, 0.2f, true),
    // Hulkbuster: niente volo, molto resistente (salto + onda d'urto). War Machine: missili e repulsori forti. Hulk: pelle verde (solo col siero gamma).
    MARK_44(44, "mark44", 500, 0.0f, 1.0, 0f, 0f, 0, 0.50f, new int[]{4, 7, 9, 4}, 8.0f, 1.0f, true),
    WAR_MACHINE(100, "warmachine", 2500, 0.060f, 1.4, 12f, 0f, 10, 0.85f, new int[]{3, 6, 8, 3}, 3.0f, 0.1f, true),
    HULK(101, "hulk", 0, 0.0f, 1.0, 0f, 0f, 0, 1.00f, new int[]{0, 0, 0, 0}, 0.0f, 0.0f, true);

    public final int number;
    public final String id;
    public final int maxEnergy;
    public final float flySpeed;
    public final double boost;
    public final float repulsorDamage;
    public final float unibeamDamage;
    public final int missiles;
    /** true = armatura normale (pezzi veri da indossare), false = nanotech col Reattore Arc. */
    public final boolean classic;
    /** Moltiplicatore del danno subito (dopo la protezione normale): 1.0 = nessun extra, 0.25 = prendi un quarto. */
    public final float damageTaken;
    private final int[] defense;
    private final float toughness;
    private final float knockback;

    SuitMark(int number, String id, int maxEnergy, float flySpeed, double boost, float repulsorDamage,
             float unibeamDamage, int missiles, float damageTaken, int[] defense, float toughness, float knockback, boolean classic) {
        this.classic = classic;
        this.number = number;
        this.id = id;
        this.maxEnergy = maxEnergy;
        this.flySpeed = flySpeed;
        this.boost = boost;
        this.repulsorDamage = repulsorDamage;
        this.unibeamDamage = unibeamDamage;
        this.missiles = missiles;
        this.damageTaken = damageTaken;
        this.defense = defense;
        this.toughness = toughness;
        this.knockback = knockback;
    }

    public static SuitMark byNumber(int n) {
        for (SuitMark m : values()) {
            if (m.number == n) return m;
        }
        return null;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        if (!classic) return 9999; // nanotech: non si rompe
        int base = switch (type) {
            case BOOTS -> 13;
            case LEGGINGS -> 15;
            case CHESTPLATE -> 16;
            case HELMET -> 11;
        };
        return base * 40; // un po' piu' del diamante (x33)
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case BOOTS -> defense[0];
            case LEGGINGS -> defense[1];
            case CHESTPLATE -> defense[2];
            case HELMET -> defense[3];
        };
    }

    @Override
    public int getEnchantmentValue() {
        return classic ? 10 : 0;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_NETHERITE;
    }

    @Override
    public Ingredient getRepairIngredient() {
        if (!classic) return Ingredient.EMPTY;
        return switch (this) {
            case MARK_2 -> Ingredient.of(net.minecraft.world.item.Items.IRON_INGOT);
            case MARK_3 -> Ingredient.of(net.minecraft.world.item.Items.GOLD_INGOT);
            case MARK_4, WAR_MACHINE -> Ingredient.of(net.minecraft.world.item.Items.IRON_INGOT);
            default -> Ingredient.of(net.minecraft.world.item.Items.DIAMOND);
        };
    }

    @Override
    public String getName() {
        return IronManMod.MODID + ":" + id;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockback;
    }
}
