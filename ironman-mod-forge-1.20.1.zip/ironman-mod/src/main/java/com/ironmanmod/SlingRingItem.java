package com.ironmanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.List;

/**
 * Anello di Doctor Strange. Shift + tasto destro: salva il punto in cui sei come destinazione dell'anello.
 * Tasto destro: apre un portale di scintille arancioni davanti a te; restando fermo 3 secondi attraversi e arrivi alla destinazione
 * (senza destinazione salvata: il tuo letto o lo spawn del mondo). Se sei gia' vicino alla destinazione, il portale ti riporta da dove eri partito.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class SlingRingItem extends Item {
    private static final String END = "sr_end", BACK = "sr_back";
    private static final int OPEN_TICKS = 260;

    public SlingRingItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
    }

    /** Cerca l'anello: mano principale, mano secondaria o Curios (slot hands/ring/curio). */
    public static ItemStack find(Player p) {
        if (p.getMainHandItem().getItem() instanceof SlingRingItem) return p.getMainHandItem();
        if (p.getOffhandItem().getItem() instanceof SlingRingItem) return p.getOffhandItem();
        return ReactorLookup.curios(p, s -> s.getItem() instanceof SlingRingItem);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (level.isClientSide) {
            if (p.isShiftKeyDown()) {
                net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(net.minecraftforge.api.distmarker.Dist.CLIENT,
                        () -> () -> com.ironmanmod.client.SlingRingScreen.open());
            }
            return InteractionResultHolder.success(st);
        }
        if (!(p instanceof ServerPlayer sp)) return InteractionResultHolder.success(st);
        if (!sp.isShiftKeyDown()) openPortal(sp, st);
        return InteractionResultHolder.success(st);
    }

    // ---- waypoint (salvati nell'anello) ----
    private static ListTag wps(ItemStack ring) {
        CompoundTag t = ring.getOrCreateTag();
        if (!t.contains("WP", 9)) t.put("WP", new ListTag());
        return t.getList("WP", 10);
    }

    /** Operazioni del menu: 0 salva qui, 1 scegli, 2 rinomina, 3 elimina, 4 apri il portale. */
    public static void handlePacket(ServerPlayer sp, int op, int idx, String name) {
        if (op == 10 || op == 11) {
            BraceletItem.key(sp, op == 11);
            return;
        }
        ItemStack ring = find(sp);
        if (ring.isEmpty()) return;
        ListTag l = wps(ring);
        CompoundTag t = ring.getOrCreateTag();
        name = name == null ? "" : name.trim();
        if (name.length() > 20) name = name.substring(0, 20);
        switch (op) {
            case 0 -> {
                if (l.size() >= 24) {
                    SuitData.msg(sp, "msg.ironmanmod.sr_full");
                    return;
                }
                if (name.isEmpty()) name = "Punto " + (l.size() + 1);
                CompoundTag w = new CompoundTag();
                w.putString("Name", name);
                w.putString("Dim", sp.level().dimension().location().toString());
                w.putDouble("X", sp.getX());
                w.putDouble("Y", sp.getY());
                w.putDouble("Z", sp.getZ());
                l.add(w);
                t.putInt("Sel", l.size() - 1);
                SuitData.msg(sp, "msg.ironmanmod.sr_saved", name);
                sp.serverLevel().sendParticles(new DustParticleOptions(new Vector3f(1.0f, 0.55f, 0.1f), 1.5f), sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.5, 0.8, 0.5, 0);
                sp.serverLevel().playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0f, 1.2f);
            }
            case 1 -> {
                if (idx < 0 || idx >= l.size()) return;
                t.putInt("Sel", idx);
                SuitData.msg(sp, "msg.ironmanmod.sr_selected", l.getCompound(idx).getString("Name"));
            }
            case 2 -> {
                if (idx < 0 || idx >= l.size() || name.isEmpty()) return;
                l.getCompound(idx).putString("Name", name);
            }
            case 3 -> {
                if (idx < 0 || idx >= l.size()) return;
                l.remove(idx);
                int sel = t.getInt("Sel");
                if (sel >= idx && sel > 0) t.putInt("Sel", sel - 1);
            }
            case 4 -> openPortal(sp, ring);
            default -> {
            }
        }
    }

    public static void openPortal(ServerPlayer sp, ItemStack st) {
        CompoundTag d = sp.getPersistentData();
        if (d.getLong(END) > 0) return;
        Level level = sp.level();
        // calcola dove porta il portale
        CompoundTag dest = new CompoundTag();
        MinecraftServer srv = sp.getServer();
        String curDim = sp.level().dimension().location().toString();
        ListTag l = wps(st);
        int sel = st.getOrCreateTag().getInt("Sel");
        String aDim;
        double ax, ay, az;
        if (sel >= 0 && sel < l.size()) {
            CompoundTag w = l.getCompound(sel);
            aDim = w.getString("Dim");
            ax = w.getDouble("X");
            ay = w.getDouble("Y");
            az = w.getDouble("Z");
        } else { // niente waypoint: letto o spawn del mondo
            BlockPos rp = sp.getRespawnPosition();
            if (rp != null) {
                aDim = sp.getRespawnDimension().location().toString();
                ax = rp.getX() + 0.5;
                ay = rp.getY() + 1.0;
                az = rp.getZ() + 0.5;
            } else {
                ServerLevel ow = srv.overworld();
                BlockPos s = ow.getSharedSpawnPos();
                aDim = ow.dimension().location().toString();
                ax = s.getX() + 0.5;
                az = s.getZ() + 0.5;
                ay = ow.getHeight(Heightmap.Types.MOTION_BLOCKING, s.getX(), s.getZ()) + 1.0;
            }
        }
        boolean near = curDim.equals(aDim) && sp.distanceToSqr(ax, ay, az) < 64.0;
        if (near) { // sei gia' alla destinazione: il portale riporta indietro
            CompoundTag b = d.getCompound(BACK);
            if (!b.contains("dim")) {
                SuitData.msg(sp, "msg.ironmanmod.sr_nowhere");
                return;
            }
            dest = b.copy();
        } else {
            dest.putString("dim", aDim);
            dest.putDouble("x", ax);
            dest.putDouble("y", ay);
            dest.putDouble("z", az);
        }
        double yaw = Math.toRadians(sp.getYRot());
        d.putLong(END, level.getGameTime() + OPEN_TICKS);
        d.putLong("sr_start", level.getGameTime());
        d.put("sr_dest", dest);
        d.putDouble("sr_cx", sp.getX() - Math.sin(yaw) * 2.0);
        d.putDouble("sr_cy", sp.getY() + 1.6);
        d.putDouble("sr_cz", sp.getZ() + Math.cos(yaw) * 2.0);
        d.putDouble("sr_yaw", yaw);
        SuitData.msg(sp, "msg.ironmanmod.sr_open");
        sp.swing(InteractionHand.MAIN_HAND, true);
        sp.serverLevel().playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.2f, 0.7f);
    }

    private static void ring(ServerLevel sl, DustParticleOptions o, double cx, double cy, double cz, double rx, double rz, double r, int n, double spin) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n + spin;
            double u = Math.cos(a) * r, v = Math.sin(a) * r;
            sl.sendParticles(o, cx + rx * u, cy + v, cz + rz * u, 1, 0, 0, 0, 0);
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide || !(e.player instanceof ServerPlayer sp)) return;
        CompoundTag d = sp.getPersistentData();
        ServerLevel sl = sp.serverLevel();
        DustParticleOptions orange = new DustParticleOptions(new Vector3f(1.0f, 0.5f, 0.05f), 1.3f);
        DustParticleOptions gold = new DustParticleOptions(new Vector3f(1.0f, 0.8f, 0.2f), 0.9f);
        long now = sl.getGameTime();
        // il portale d'uscita: si chiude dietro di te
        long arr = d.getLong("sr_arr");
        if (arr > 0) {
            long left = arr - now;
            if (left <= 0) d.remove("sr_arr");
            else {
                double yw = d.getDouble("sr_ayaw"), r = 1.5 * left / 50.0;
                ring(sl, orange, d.getDouble("sr_ax"), d.getDouble("sr_ay"), d.getDouble("sr_az"), Math.cos(yw), Math.sin(yw), r, 40, -sp.tickCount * 0.3);
                ring(sl, gold, d.getDouble("sr_ax"), d.getDouble("sr_ay"), d.getDouble("sr_az"), Math.cos(yw), Math.sin(yw), r * 0.8, 24, sp.tickCount * 0.2);
            }
        }
        long end = d.getLong(END);
        if (end == 0) return;
        double cx = d.getDouble("sr_cx"), cy = d.getDouble("sr_cy"), cz = d.getDouble("sr_cz"), yaw = d.getDouble("sr_yaw");
        if (sp.distanceToSqr(cx, cy, cz) > 100.0 || end - now <= 0) { // lontano o scaduto: si chiude
            d.remove(END);
            SuitData.msg(sp, "msg.ironmanmod.sr_closed");
            return;
        }
        double rx = Math.cos(yaw), rz = Math.sin(yaw);
        long age = now - d.getLong("sr_start");
        double r = Math.min(1.5, 1.5 * age / 30.0);
        double spin = sp.tickCount * 0.3;
        if (age < 30) { // l'anello gira sulla mano e le scintille disegnano il cerchio
            double fx = -Math.sin(yaw), fz = Math.cos(yaw);
            ring(sl, orange, sp.getX() + fx * 0.6 + rx * 0.4, sp.getY() + 1.1, sp.getZ() + fz * 0.6 + rz * 0.4, rx, rz, 0.3, 12, spin * 2);
            for (int i = 0; i < 6; i++) { // scintille che volano dalla mano al portale
                double f = (age * 0.6 + i * 3) % 18 / 18.0;
                sl.sendParticles(ParticleTypes.FLAME, sp.getX() + fx * 0.6 + (cx - sp.getX() - fx * 0.6) * f, sp.getY() + 1.1 + (cy - sp.getY() - 1.1) * f,
                        sp.getZ() + fz * 0.6 + (cz - sp.getZ() - fz * 0.6) * f, 1, 0.05, 0.05, 0.05, 0.0);
            }
        }
        ring(sl, orange, cx, cy, cz, rx, rz, r, 48, spin);
        ring(sl, gold, cx, cy, cz, rx, rz, r * 0.82, 30, -spin * 1.3);
        for (int i = 0; i < 4; i++) { // scintille che schizzano via dal bordo
            double a = sl.random.nextDouble() * Math.PI * 2;
            sl.sendParticles(ParticleTypes.FLAME, cx + rx * Math.cos(a) * r, cy + Math.sin(a) * r, cz + rz * Math.cos(a) * r, 0,
                    Math.cos(a - 1.57) * rx, Math.sin(a - 1.57), Math.cos(a - 1.57) * rz, 0.25);
        }
        if (age == 30) sl.playSound(null, cx, cy, cz, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 0.6f);
        if (age < 30) return;
        // dentro il portale: attraversi
        double dx = sp.getX() - cx, dz = sp.getZ() - cz;
        if (dx * dx + dz * dz < 0.8 * 0.8 && Math.abs(sp.getY() + 1.0 - cy) < 1.6) {
            d.remove(END);
            CompoundTag dest = d.getCompound("sr_dest");
            ServerLevel to = sp.getServer().getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(dest.getString("dim"))));
            if (to == null) {
                SuitData.msg(sp, "msg.ironmanmod.sr_nowhere");
                return;
            }
            CompoundTag b = new CompoundTag(); // da dove sei partito, per tornare
            b.putString("dim", sl.dimension().location().toString());
            b.putDouble("x", sp.getX());
            b.putDouble("y", sp.getY());
            b.putDouble("z", sp.getZ());
            d.put(BACK, b);
            sl.sendParticles(orange, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.5, 0.8, 0.5, 0);
            sp.teleportTo(to, dest.getDouble("x"), dest.getDouble("y"), dest.getDouble("z"), sp.getYRot(), sp.getXRot());
            sp.fallDistance = 0f;
            d.putLong("mj_nofall", to.getGameTime() + 100);
            double fx = -Math.sin(yaw), fz = Math.cos(yaw);
            d.putDouble("sr_ax", sp.getX() - fx * 1.3);
            d.putDouble("sr_ay", sp.getY() + 1.6);
            d.putDouble("sr_az", sp.getZ() - fz * 1.3);
            d.putDouble("sr_ayaw", yaw);
            d.putLong("sr_arr", to.getGameTime() + 50);
            to.sendParticles(orange, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.5, 0.8, 0.5, 0);
            to.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 0.7f);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("tooltip.ironmanmod.sling_ring").withStyle(net.minecraft.ChatFormatting.GRAY));
        CompoundTag t = stack.getTag();
        if (t != null && t.contains("WP", 9)) {
            ListTag l = t.getList("WP", 10);
            int sel = t.getInt("Sel");
            if (sel >= 0 && sel < l.size()) {
                CompoundTag w = l.getCompound(sel);
                tip.add(Component.translatable("tooltip.ironmanmod.sling_dest", w.getString("Name"), (int) w.getDouble("X"), (int) w.getDouble("Y"), (int) w.getDouble("Z"))
                        .withStyle(net.minecraft.ChatFormatting.GOLD));
            }
        }
    }
}
