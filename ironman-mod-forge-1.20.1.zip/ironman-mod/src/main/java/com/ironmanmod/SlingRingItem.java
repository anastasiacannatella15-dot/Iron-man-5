package com.ironmanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.List;

/**
 * Anello di Doctor Strange. Shift + tasto destro: salva il punto in cui sei come destinazione dell'anello.
 * Tasto destro: apre un portale di scintille arancioni davanti a te; restando fermo 3 secondi attraversi e arrivi alla destinazione
 * (senza destinazione salvata: il tuo letto o lo spawn del mondo). Se sei gia' vicino alla destinazione, il portale ti riporta da dove eri partito.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class SlingRingItem extends Item {
    private static final String END = "sr_end", BACK = "sr_back";
    private static final int OPEN_TICKS = 60;

    public SlingRingItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (level.isClientSide || !(p instanceof ServerPlayer sp)) return InteractionResultHolder.success(st);
        CompoundTag d = sp.getPersistentData();
        if (d.getLong(END) > 0) return InteractionResultHolder.fail(st);
        if (sp.isShiftKeyDown()) { // salva la destinazione
            CompoundTag t = st.getOrCreateTag();
            t.putString("ADim", sp.level().dimension().location().toString());
            t.putDouble("AX", sp.getX());
            t.putDouble("AY", sp.getY());
            t.putDouble("AZ", sp.getZ());
            SuitData.msg(sp, "msg.ironmanmod.sr_set", (int) sp.getX(), (int) sp.getY(), (int) sp.getZ());
            sp.serverLevel().sendParticles(new DustParticleOptions(new Vector3f(1.0f, 0.55f, 0.1f), 1.5f), sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.5, 0.8, 0.5, 0);
            sp.serverLevel().playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0f, 1.2f);
            return InteractionResultHolder.success(st);
        }
        // calcola dove porta il portale
        CompoundTag dest = new CompoundTag();
        MinecraftServer srv = sp.getServer();
        String curDim = sp.level().dimension().location().toString();
        CompoundTag t = st.getTag();
        String aDim;
        double ax, ay, az;
        if (t != null && t.contains("ADim")) {
            aDim = t.getString("ADim");
            ax = t.getDouble("AX");
            ay = t.getDouble("AY");
            az = t.getDouble("AZ");
        } else { // niente destinazione salvata: letto o spawn del mondo
            BlockPos rp = sp.getRespawnPosition();
            if (rp != null) {
                aDim = sp.getRespawnDimension().location().toString();
                ax = rp.getX() + 0.5;
                ay = rp.getY() + 1.0;
                az = rp.getZ() + 0.5;
            } else {
                ServerLevel ow = srv.overworld();
                BlockPos s = ow.getSharedSpawnPos();
                aDim = ow.dimension().location().toString();
                ax = s.getX() + 0.5;
                az = s.getZ() + 0.5;
                ay = ow.getHeight(Heightmap.Types.MOTION_BLOCKING, s.getX(), s.getZ()) + 1.0;
            }
        }
        boolean near = curDim.equals(aDim) && sp.distanceToSqr(ax, ay, az) < 64.0;
        if (near) { // sei gia' alla destinazione: il portale riporta indietro
            CompoundTag b = d.getCompound(BACK);
            if (!b.contains("dim")) {
                SuitData.msg(sp, "msg.ironmanmod.sr_nowhere");
                return InteractionResultHolder.fail(st);
            }
            dest = b.copy();
        } else {
            dest.putString("dim", aDim);
            dest.putDouble("x", ax);
            dest.putDouble("y", ay);
            dest.putDouble("z", az);
        }
        double yaw = Math.toRadians(sp.getYRot());
        d.putLong(END, level.getGameTime() + OPEN_TICKS);
        d.put("sr_dest", dest);
        d.putDouble("sr_cx", sp.getX() - Math.sin(yaw) * 2.0);
        d.putDouble("sr_cy", sp.getY() + 1.2);
        d.putDouble("sr_cz", sp.getZ() + Math.cos(yaw) * 2.0);
        d.putDouble("sr_yaw", yaw);
        SuitData.msg(sp, "msg.ironmanmod.sr_open");
        sp.serverLevel().playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.2f, 0.7f);
        return InteractionResultHolder.success(st);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide || !(e.player instanceof ServerPlayer sp)) return;
        CompoundTag d = sp.getPersistentData();
        long end = d.getLong(END);
        if (end == 0) return;
        ServerLevel sl = sp.serverLevel();
        double cx = d.getDouble("sr_cx"), cy = d.getDouble("sr_cy"), cz = d.getDouble("sr_cz"), yaw = d.getDouble("sr_yaw");
        if (sp.distanceToSqr(cx, cy, cz) > 36.0) { // si e' allontanato: il portale si chiude
            d.remove(END);
            SuitData.msg(sp, "msg.ironmanmod.sr_closed");
            return;
        }
        double rx = Math.cos(yaw), rz = Math.sin(yaw);
        DustParticleOptions orange = new DustParticleOptions(new Vector3f(1.0f, 0.5f, 0.05f), 1.3f);
        long t = end - sl.getGameTime();
        double spin = sp.tickCount * 0.25;
        for (int i = 0; i < 36; i++) { // cerchio di scintille che ruota
            double a = Math.PI * 2 * i / 36 + spin;
            double u = Math.cos(a) * 1.4, v = Math.sin(a) * 1.4;
            sl.sendParticles(orange, cx + rx * u, cy + v, cz + rz * u, 1, 0, 0, 0, 0);
        }
        if (sp.tickCount % 3 == 0) sl.sendParticles(ParticleTypes.FLAME, cx, cy, cz, 3, 0.9, 0.9, 0.9, 0.01);
        if (t <= 0) {
            d.remove(END);
            CompoundTag dest = d.getCompound("sr_dest");
            ServerLevel to = sp.getServer().getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(dest.getString("dim"))));
            if (to == null) {
                SuitData.msg(sp, "msg.ironmanmod.sr_nowhere");
                return;
            }
            CompoundTag b = new CompoundTag(); // da dove sei partito, per tornare
            b.putString("dim", sl.dimension().location().toString());
            b.putDouble("x", sp.getX());
            b.putDouble("y", sp.getY());
            b.putDouble("z", sp.getZ());
            d.put(BACK, b);
            sl.sendParticles(orange, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.5, 0.8, 0.5, 0);
            sp.teleportTo(to, dest.getDouble("x"), dest.getDouble("y"), dest.getDouble("z"), sp.getYRot(), sp.getXRot());
            sp.fallDistance = 0f;
            d.putLong("mj_nofall", to.getGameTime() + 100);
            to.sendParticles(orange, sp.getX(), sp.getY() + 1, sp.getZ(), 40, 0.5, 0.8, 0.5, 0);
            to.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 0.7f);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("tooltip.ironmanmod.sling_ring").withStyle(net.minecraft.ChatFormatting.GRAY));
        CompoundTag t = stack.getTag();
        if (t != null && t.contains("ADim")) {
            tip.add(Component.translatable("tooltip.ironmanmod.sling_dest", (int) t.getDouble("AX"), (int) t.getDouble("AY"), (int) t.getDouble("AZ"))
                    .withStyle(net.minecraft.ChatFormatting.GOLD));
        }
    }
}
