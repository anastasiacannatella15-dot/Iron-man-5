package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * La valigetta posata a terra davanti a te (Iron Man 2): si apre e i pezzi volano dalla valigetta al tuo corpo,
 * stivali, gambali, petto, casco. A fine scena si chiude e la valigetta vuota torna a te.
 */
public class BriefcaseEntity extends Entity {
    private static final EntityDataAccessor<Boolean> OPEN = SynchedEntityData.defineId(BriefcaseEntity.class, EntityDataSerializers.BOOLEAN);
    private static final int OPEN_AT = 20, END = 112;
    private static final int[] AT = {44, 60, 78, 96}; // quando arriva ogni pezzo: stivali, gambali, petto, casco
    private static final double[] HEIGHT = {0.2, 0.7, 1.3, 1.75};

    private UUID owner;
    private ItemStack held = ItemStack.EMPTY;
    private int t;

    public BriefcaseEntity(EntityType<? extends BriefcaseEntity> type, Level level) {
        super(type, level);
    }

    public boolean isOpen() {
        return entityData.get(OPEN);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(OPEN, false);
    }

    /** Il giocatore e' occupato con una valigetta? */
    public static boolean busy(ServerPlayer p) {
        return !p.level().getEntitiesOfClass(BriefcaseEntity.class, p.getBoundingBox().inflate(6), b -> p.getUUID().equals(b.owner)).isEmpty();
    }

    public static void place(ServerPlayer p, ItemStack heldCase) {
        BriefcaseEntity b = new BriefcaseEntity(IronManMod.BRIEFCASE_ENTITY.get(), p.level());
        b.owner = p.getUUID();
        b.held = heldCase;
        Vec3 dir = new Vec3(-Math.sin(Math.toRadians(p.getYRot())), 0, Math.cos(Math.toRadians(p.getYRot())));
        Vec3 from = new Vec3(p.getX(), p.getY() + 0.5, p.getZ());
        BlockHitResult bh = p.level().clip(new ClipContext(from, from.add(dir.scale(1.7)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 at = bh.getType() != HitResult.Type.MISS ? bh.getLocation().subtract(dir.scale(0.4)) : from.add(dir.scale(1.7));
        b.moveTo(at.x, p.getY(), at.z, p.getYRot(), 0f);
        p.level().addFreshEntity(b);
        p.level().playSound(null, at.x, p.getY(), at.z, SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 0.7f);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        Player p = owner == null ? null : level().getPlayerByUUID(owner);
        if (!(p instanceof ServerPlayer sp) || !sp.isAlive()) { // senza proprietario la valigetta resta a terra come oggetto
            if (!held.isEmpty()) spawnAtLocation(held);
            discard();
            return;
        }
        ServerLevel sl = sp.serverLevel();
        t++;
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 6, false, false, false)); // resti fermo
        Vec3 caseTop = new Vec3(getX(), getY() + 0.3, getZ());
        if (t == OPEN_AT) {
            entityData.set(OPEN, true);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.PLAYERS, 1.2f, 0.6f);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.PISTON_EXTEND, SoundSource.PLAYERS, 1.0f, 0.8f);
            sl.sendParticles(ParticleTypes.END_ROD, caseTop.x, caseTop.y, caseTop.z, 20, 0.3, 0.1, 0.3, 0.05);
        }
        if (isOpen() && t % 3 == 0) sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, caseTop.x, caseTop.y, caseTop.z, 3, 0.3, 0.1, 0.3, 0.05);
        for (int i = 0; i < 4; i++) {
            int a = AT[i];
            if (t >= a - 12 && t < a) { // il pezzo vola dalla valigetta al corpo
                double f = (t - (a - 12)) / 12.0;
                Vec3 target = new Vec3(sp.getX(), sp.getY() + HEIGHT[i], sp.getZ());
                Vec3 pos = caseTop.lerp(target, f).add(0, Math.sin(f * Math.PI) * 0.8, 0); // arco
                sl.sendParticles(ParticleTypes.CRIT, pos.x, pos.y, pos.z, 6, 0.1, 0.1, 0.1, 0.02);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 2, 0.08, 0.08, 0.08, 0.02);
            }
            if (t == a) {
                BriefcaseItem.equip(sp, i);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + HEIGHT[i], sp.getZ(), 25, 0.35, 0.2, 0.35, 0.2);
                sl.sendParticles(ParticleTypes.CRIT, sp.getX(), sp.getY() + HEIGHT[i], sp.getZ(), 15, 0.4, 0.2, 0.4, 0.3);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 0.5f, 1.4f);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 1.0f);
            }
        }
        if (t == END - 8) {
            entityData.set(OPEN, false);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 0.8f);
        }
        if (t >= END) {
            sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.8f);
            sl.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1, sp.getZ(), 25, 0.4, 0.9, 0.4, 0.05);
            SuitData.msg(sp, "msg.ironmanmod.bc_on");
            if (!sp.getInventory().add(held)) sp.drop(held, false); // la valigetta vuota torna a te
            held = ItemStack.EMPTY;
            discard();
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
        held = ItemStack.of(tag.getCompound("Held"));
        t = tag.getInt("T");
        entityData.set(OPEN, tag.getBoolean("Open"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        if (owner != null) tag.putUUID("Owner", owner);
        tag.put("Held", held.save(new CompoundTag()));
        tag.putInt("T", t);
        tag.putBoolean("Open", isOpen());
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(net.minecraft.world.damagesource.DamageSource src) {
        return true;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
