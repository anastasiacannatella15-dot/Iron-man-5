package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * La valigetta della Mark 5 (Iron Man 2). Clic destro: la valigetta si apre e i pezzi dell'armatura volano addosso uno alla volta
 * (stivali, gambali, petto, casco). Shift + clic destro mentre porti la Mark 5: l'armatura si smonta e rientra nella valigetta.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class BriefcaseItem extends Item {
    private static final String T = "bc_t";
    private static final int[] AT = {14, 28, 44, 60}; // tick in cui arriva ogni pezzo: stivali, gambali, petto, casco
    private static final int END = 74;
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
    private static final ArmorItem.Type[] TYPES = {ArmorItem.Type.BOOTS, ArmorItem.Type.LEGGINGS, ArmorItem.Type.CHESTPLATE, ArmorItem.Type.HELMET};
    private static final double[] HEIGHT = {0.2, 0.7, 1.3, 1.75};

    public BriefcaseItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
    }

    private static boolean isEmptyCase(ItemStack s) {
        return s.getTag() != null && s.getTag().getBoolean("Empty");
    }

    private static ItemStack piece(int i) {
        return new ItemStack(IronManMod.ARMOR.get(SuitMark.MARK_5).get(TYPES[i]).get());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player p, InteractionHand hand) {
        ItemStack st = p.getItemInHand(hand);
        if (level.isClientSide || !(p instanceof ServerPlayer sp)) return InteractionResultHolder.success(st);
        CompoundTag d = sp.getPersistentData();
        if (d.getInt(T) > 0) return InteractionResultHolder.fail(st);
        boolean wearing = SuitData.classicSet(sp) == SuitMark.MARK_5;
        if (sp.isShiftKeyDown()) {
            if (!isEmptyCase(st)) {
                SuitData.msg(sp, "msg.ironmanmod.bc_full");
            } else if (!wearing) {
                SuitData.msg(sp, "msg.ironmanmod.bc_nosuit");
            } else {
                for (EquipmentSlot s : SLOTS) sp.setItemSlot(s, ItemStack.EMPTY); // l'armatura rientra nella valigetta
                st.getOrCreateTag().remove("Empty");
                ServerLevel sl = sp.serverLevel();
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 1, sp.getZ(), 60, 0.5, 0.9, 0.5, 0.3);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 0.7f);
                sl.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PISTON_CONTRACT, SoundSource.PLAYERS, 1.0f, 1.2f);
                SuitData.msg(sp, "msg.ironmanmod.bc_off");
            }
            return InteractionResultHolder.success(st);
        }
        if (isEmptyCase(st)) {
            SuitData.msg(sp, "msg.ironmanmod.bc_empty");
            return InteractionResultHolder.fail(st);
        }
        if (wearing) {
            SuitData.msg(sp, "msg.ironmanmod.bc_already");
            return InteractionResultHolder.fail(st);
        }
        st.getOrCreateTag().putBoolean("Empty", true); // la valigetta resta in mano, aperta e vuota
        d.putInt(T, 1);
        return InteractionResultHolder.success(st);
    }

    /** Il pezzo arriva addosso: quello che indossavi finisce nell'inventario. */
    private static void equip(ServerPlayer p, int i) {
        EquipmentSlot s = SLOTS[i];
        ItemStack old = p.getItemBySlot(s);
        if (!old.isEmpty()) {
            if (!p.getInventory().add(old.copy())) p.drop(old.copy(), false);
        }
        p.setItemSlot(s, piece(i));
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide || !(e.player instanceof ServerPlayer p)) return;
        CompoundTag d = p.getPersistentData();
        int t = d.getInt(T);
        if (t <= 0) return;
        t++;
        d.putInt(T, t);
        ServerLevel sl = p.serverLevel();
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 6, false, false, false)); // resti fermo mentre l'armatura si monta
        if (t == 2) {
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.PLAYERS, 1.2f, 0.6f);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PISTON_EXTEND, SoundSource.PLAYERS, 1.0f, 0.8f);
        }
        for (int i = 0; i < 4; i++) {
            int a = AT[i];
            if (t >= a - 10 && t < a && t % 2 == 0) { // i pezzi volano verso il corpo da fuori
                for (int k = 0; k < 4; k++) {
                    double ang = p.getRandom().nextDouble() * Math.PI * 2;
                    double dx = Math.cos(ang) * 3.0, dz = Math.sin(ang) * 3.0;
                    double y = p.getY() + HEIGHT[i];
                    sl.sendParticles(ParticleTypes.CRIT, p.getX() + dx, y, p.getZ() + dz, 0, -dx * 0.2, 0, -dz * 0.2, 1.0);
                }
            }
            if (t == a) {
                equip(p, i);
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + HEIGHT[i], p.getZ(), 25, 0.35, 0.2, 0.35, 0.2);
                sl.sendParticles(ParticleTypes.CRIT, p.getX(), p.getY() + HEIGHT[i], p.getZ(), 15, 0.4, 0.2, 0.4, 0.3);
                sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 0.5f, 1.4f);
                sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 1.0f, 1.0f);
            }
        }
        if (t >= END) {
            d.remove(T);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.8f);
            sl.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 25, 0.4, 0.9, 0.4, 0.05);
            SuitData.msg(p, "msg.ironmanmod.bc_on");
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable(isEmptyCase(stack) ? "tooltip.ironmanmod.bc_empty" : "tooltip.ironmanmod.bc_full")
                .withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
