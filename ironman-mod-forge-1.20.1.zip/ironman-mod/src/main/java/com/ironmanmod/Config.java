package com.ironmanmod;

import net.minecraftforge.common.ForgeConfigSpec;

/** File: config/ironmanmod-common.toml */
public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue TRANSFORM_TICKS;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_REACTOR;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        TRANSFORM_TICKS = b.comment("Durata della trasformazione nanotech in tick (20 tick = 1 secondo). Default 10 = 0,5 secondi.")
                .defineInRange("nanotechTicks", 10, 4, 400);

        REQUIRE_REACTOR = b.comment("Se true serve avere il Reattore Arc del modello nell'inventario per trasformarsi.")
                .define("requireReactor", true);

        SPEC = b.build();
    }

    private Config() {
    }
}
