package com.ironmanmod;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;

import java.util.function.Supplier;

/** Aggiunge la Matrice del Mjolnir al loot (le condizioni stanno nel json: forgia dei villaggi). */
public class CastLootModifier extends LootModifier {
    public static final Supplier<Codec<CastLootModifier>> CODEC =
            () -> RecordCodecBuilder.create(inst -> codecStart(inst).apply(inst, CastLootModifier::new));

    public CastLootModifier(LootItemCondition[] conditions) {
        super(conditions);
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext context) {
        loot.add(new ItemStack(ModContent.MJOLNIR_CAST.get()));
        if (context.getRandom().nextFloat() < 0.5f) loot.add(new ItemStack(ModContent.STORMBREAKER_CAST.get()));
        return loot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
