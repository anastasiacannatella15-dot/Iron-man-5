package com.ironmanmod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

/**
 * Stormbreaker + il raggio della Gemma del Potere.
 * - Raggio viola (energy beam di Palladium, lanciato da un giocatore) su chi tiene il Mjolnir: ogni secondo di raggio
 *   consuma 1 di durabilita' (10 in tutto): dopo 10 secondi il Mjolnir si spezza.
 * - Lo stesso raggio su chi tiene lo Stormbreaker: non fa danno, l'ascia incanala il potere (particelle di fulmine
 *   intorno al giocatore); dopo 5 secondi esplodono e si sblocca il SUPER FULMINE (fulmini a danno x10).
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public final class Stormbreaker {
    public static final int A_BIFROST = 17;
    public static final float SUPER_MULT = 10f;
    private static final int CHANNEL_TICKS = 100; // 5 secondi

    private Stormbreaker() {}

    public static boolean isAction(int a) {
        return a == A_BIFROST;
    }

    public static boolean isSuper(Player p) {
        return p.getPersistentData().getBoolean("sb_super");
    }

    private static boolean holds(ServerPlayer p) {
        if (p.getMainHandItem().getItem() instanceof StormbreakerItem) return true;
        SuitData.msg(p, "msg.ironmanmod.sb_hold");
        return false;
    }

    // ---------------------------------------------------------------- tasti

    public static void handleAction(ServerPlayer p, int a) {
        ServerLevel lvl = p.serverLevel();
        switch (a) {
            case A_BIFROST -> bifrost(p, lvl);
            default -> { }
        }
    }

    /** Fulmine dello Stormbreaker: normale = danno del fulmine del Mjolnir, con il Super Fulmine sbloccato x10. */
    public static void lightning(ServerPlayer owner, Vec3 pos) {
        boolean sup = isSuper(owner);
        Mjolnir.bolt(owner, pos, Mjolnir.BOLT_DAMAGE * (sup ? SUPER_MULT : 1f));
        if (sup) {
            ServerLevel sl = owner.serverLevel();
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 1, pos.z, 120, 1.5, 2.0, 1.5, 0.6);
            sl.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y + 0.5, pos.z, 3, 1.0, 0.3, 1.0, 0);
        }
    }

    private static float[] rainbow(double t) {
        double h = (t - Math.floor(t)) * 6.0; // arcobaleno HSV (senza java.awt, non c'e' su Android)
        int i = (int) h;
        float f = (float) (h - i), q = 1f - f;
        return switch (i % 6) {
            case 0 -> new float[]{1f, f, 0f};
            case 1 -> new float[]{q, 1f, 0f};
            case 2 -> new float[]{0f, 1f, f};
            case 3 -> new float[]{0f, q, 1f};
            case 4 -> new float[]{f, 0f, 1f};
            default -> new float[]{1f, 0f, q};
        };
    }

    /** Bifrost: raggio arcobaleno verso dove guardi, e ti ritrovi li'. */
    private static void bifrost(ServerPlayer p, ServerLevel lvl) {
        if (!holds(p) || !SuitData.ready(p, "sbb")) return;
        SuitData.setCooldown(p, "sbb", 50);
        Vec3 eye = p.getEyePosition();
        Vec3 end = eye.add(p.getLookAngle().scale(120));
        Vec3 miss = eye.add(p.getLookAngle().scale(60)); // se non guardi niente di solido non ti mando oltre i chunk caricati
        BlockHitResult bh = lvl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 dest;
        if (bh.getType() != HitResult.Type.MISS) {
            var n = bh.getDirection().getNormal();
            dest = bh.getLocation().add(n.getX() * 0.6, n.getY() * 0.6 - (n.getY() < 0 ? 1.6 : 0), n.getZ() * 0.6);
        } else {
            dest = miss;
        }
        Vec3 from = p.position().add(0, 1.0, 0);
        Vec3 to = dest.add(0, 1.0, 0);
        double len = from.distanceTo(to);
        int steps = (int) Math.min(160, Math.max(6, len / 0.8));
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            Vec3 q = from.lerp(to, t);
            float[] c = rainbow(t * 1.5);
            lvl.sendParticles(new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), 2.2f), q.x, q.y, q.z, 4, 0.25, 0.25, 0.25, 0);
            if (i % 3 == 0) lvl.sendParticles(ParticleTypes.END_ROD, q.x, q.y, q.z, 1, 0.1, 0.1, 0.1, 0.02);
        }
        burstRainbow(lvl, from);
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 1.2f, 1.6f);
        p.getPersistentData().putLong("mj_nofall", lvl.getGameTime() + 100);
        p.fallDistance = 0f;
        p.teleportTo(lvl, dest.x, dest.y, dest.z, p.getYRot(), p.getXRot());
        p.fallDistance = 0f;
        burstRainbow(lvl, dest.add(0, 1.0, 0));
        lvl.playSound(null, dest.x, dest.y, dest.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.2f, 1.4f);
    }

    private static void burstRainbow(ServerLevel lvl, Vec3 at) {
        for (int k = 0; k < 7; k++) {
            float[] c = rainbow(k / 7.0);
            lvl.sendParticles(new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), 2.5f), at.x, at.y, at.z, 25, 1.0, 1.2, 1.0, 0);
        }
        lvl.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0);
    }

    // ---------------------------------------------------------------- raggio della Gemma del Potere

    /** Il raggio energetico di Palladium (usato dal Power Blast di Infinity) lanciato da un giocatore. */
    public static boolean isBeam(DamageSource s) {
        return s.getEntity() instanceof Player && s.getMsgId() != null && s.getMsgId().contains("energy_beam");
    }

    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !isBeam(e.getSource())) return;
        ItemStack main = p.getMainHandItem();
        ItemStack off = p.getOffhandItem();
        if (main.getItem() instanceof StormbreakerItem || off.getItem() instanceof StormbreakerItem) {
            e.setCanceled(true); // lo Stormbreaker incanala il potere, non si fa male
            channel(p);
        } else if (main.getItem() instanceof MjolnirItem) {
            beamOnHammer(p, main, p.serverLevel(), p.position());
        } else if (off.getItem() instanceof MjolnirItem) {
            beamOnHammer(p, off, p.serverLevel(), p.position());
        }
    }

    /** Un secondo di raggio (20 colpi) = 1 di durabilita'; a 10 il Mjolnir si spezza. Ritorna true se si e' rotto. */
    public static boolean beamOnHammer(Player holder, ItemStack hammer, ServerLevel sl, Vec3 at) {
        var tag = hammer.getOrCreateTag();
        int acc = tag.getInt("BeamAcc") + 1;
        if (acc < 20) {
            tag.putInt("BeamAcc", acc);
            return false;
        }
        tag.putInt("BeamAcc", 0);
        int dmg = hammer.getDamageValue() + 1;
        sl.sendParticles(ParticleTypes.CRIT, at.x, at.y + 1.2, at.z, 25, 0.5, 0.5, 0.5, 0.3);
        sl.playSound(null, at.x, at.y, at.z, SoundEvents.ANVIL_PLACE, SoundSource.PLAYERS, 0.8f, 0.5f);
        if (dmg >= hammer.getMaxDamage()) {
            sl.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y + 1, at.z, 4, 0.6, 0.6, 0.6, 0);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y + 1, at.z, 80, 0.8, 0.8, 0.8, 0.5);
            sl.playSound(null, at.x, at.y, at.z, SoundEvents.ITEM_BREAK, SoundSource.PLAYERS, 1.5f, 0.6f);
            // le gemme incastonate non vanno perse: tornano al proprietario
            if (holder != null) {
                for (ItemStack g = MjolnirGems.removeLast(hammer); !g.isEmpty(); g = MjolnirGems.removeLast(hammer)) {
                    if (!holder.getInventory().add(g)) holder.drop(g, false);
                }
                if (holder instanceof ServerPlayer sp) SuitData.msg(sp, "msg.ironmanmod.mj_broken");
            }
            hammer.shrink(1);
            return true;
        }
        hammer.setDamageValue(dmg);
        return false;
    }

    private static void channel(ServerPlayer p) {
        long now = p.level().getGameTime();
        var d = p.getPersistentData();
        if (!d.contains("sb_start") || now - d.getLong("sb_last") > 20) d.putLong("sb_start", now);
        d.putLong("sb_last", now);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        var d = p.getPersistentData();
        if (!d.contains("sb_start")) return;
        long now = p.level().getGameTime();
        if (now - d.getLong("sb_last") > 10) { // il raggio e' finito prima dei 5 secondi
            d.remove("sb_start");
            return;
        }
        ServerLevel sl = p.serverLevel();
        long t = now - d.getLong("sb_start");
        // particelle di fulmine sempre piu' fitte intorno al giocatore
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 4 + (int) (t / 10), 0.7, 0.9, 0.7, 0.2);
        if (t % 20 == 0) sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 0.4f, 1.0f + t / 100f);
        if (t >= CHANNEL_TICKS) {
            d.remove("sb_start");
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 4, false, false, false));
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 500, 2.5, 2.0, 2.5, 0.9);
            sl.explode(null, p.getX(), p.getY() + 0.5, p.getZ(), 3.0f, Level.ExplosionInteraction.NONE);
            sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 3.0f, 0.8f);
            if (!d.getBoolean("sb_super")) {
                d.putBoolean("sb_super", true);
                SuitData.msg(p, "msg.ironmanmod.sb_unlock");
            }
        }
    }

    /** /stormbreaker super: attiva/disattiva il Super Fulmine (per provarlo senza il raggio). */
    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(net.minecraft.commands.Commands.literal("stormbreaker")
                .then(net.minecraft.commands.Commands.literal("super").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    boolean now = !p.getPersistentData().getBoolean("sb_super");
                    p.getPersistentData().putBoolean("sb_super", now);
                    p.sendSystemMessage(net.minecraft.network.chat.Component.literal("Super Fulmine: " + (now ? "SBLOCCATO" : "bloccato")));
                    return 1;
                })));
    }
}
