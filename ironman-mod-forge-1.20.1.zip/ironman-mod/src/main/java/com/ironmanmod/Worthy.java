package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityStruckByLightningEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Chi puo' tenere in mano Mjolnir e Stormbreaker, sieri e progressi del giocatore.
 * Mjolnir: solo i degni (siero del dio del tuono, oppure siero del super soldato + 50 mob ostili uccisi).
 * Stormbreaker: forgiato quando Odino era gia' morto, quindi lo regge solo chi ha un potere enorme (armatura Iron Man o siero del dio del tuono).
 * I dati stanno nei dati persistenti del giocatore e passano alla nuova vita dopo la morte.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public final class Worthy {
    public static final String THOR = "serum_thor";
    public static final String SOLDIER = "serum_soldier";
    public static final String KILLS = "hostile_kills";
    public static final int KILLS_NEEDED = 50;
    private static final String[] KEYS = {THOR, SOLDIER, KILLS, "sb_super", "thanos_met"};

    private Worthy() {
    }

    public static boolean thor(Player p) {
        return p.getPersistentData().getBoolean(THOR);
    }

    public static boolean soldier(Player p) {
        return p.getPersistentData().getBoolean(SOLDIER);
    }

    public static int kills(Player p) {
        return p.getPersistentData().getInt(KILLS);
    }

    /** Degno del Mjolnir. */
    public static boolean deserving(Player p) {
        return p.isCreative() || thor(p) || (soldier(p) && kills(p) >= KILLS_NEEDED);
    }

    /** Abbastanza potente per lo Stormbreaker. */
    public static boolean mighty(Player p) {
        return p.isCreative() || thor(p); // solo il siero del dio del tuono
    }

    /** Sul client i dati non ci sono: decide il server (vale true), altrimenti il giro del martello non partirebbe. */
    public static boolean canHold(ItemStack s, Player p) {
        if (!(s.getItem() instanceof MjolnirItem) || p.level().isClientSide) return true;
        return s.getItem() instanceof StormbreakerItem ? mighty(p) : deserving(p);
    }

    public static String refuseKey(ItemStack s) {
        return s.getItem() instanceof StormbreakerItem ? "msg.ironmanmod.not_mighty" : "msg.ironmanmod.not_deserving";
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide || !(e.player instanceof ServerPlayer p)) return;
        if (p.tickCount % 10 == 0) enforce(p);
        if (p.tickCount % 20 == 0) passives(p);
        if (p.tickCount % 10 == 0 && thor(p) && p.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 5, 0.4, 0.7, 0.4, 0.05);
        }
    }

    /** Chi non e' degno non riesce a tenere il martello: gli cade di mano. */
    private static void enforce(ServerPlayer p) {
        for (InteractionHand h : InteractionHand.values()) {
            ItemStack s = p.getItemInHand(h);
            if (s.getItem() instanceof MjolnirItem && !canHold(s, p)) {
                p.stopUsingItem();
                p.setItemInHand(h, ItemStack.EMPTY);
                p.drop(s, false);
                SuitData.msg(p, refuseKey(s));
            }
        }
    }

    private static void passives(ServerPlayer p) {
        if (thor(p)) { // super elettrico: forza, velocita' e salto
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 80, 0, false, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 1, false, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.JUMP, 80, 1, false, false, true));
        }
        if (soldier(p)) { // super soldato
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 80, 1, false, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 0, false, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 80, 0, false, false, true));
            p.addEffect(new MobEffectInstance(MobEffects.HEALTH_BOOST, 80, 2, false, false, true));
        }
    }

    /** Il dio del tuono colpisce con una scarica in piu'. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity().level().isClientSide) return;
        if (e.getSource().getEntity() instanceof Player p && e.getSource().getDirectEntity() == p && thor(p)) {
            e.setAmount(e.getAmount() + 4f);
            if (e.getEntity().level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, e.getEntity().getX(), e.getEntity().getY() + 1.0, e.getEntity().getZ(), 14, 0.4, 0.6, 0.4, 0.2);
            }
        }
    }

    @SubscribeEvent
    public static void onStruck(EntityStruckByLightningEvent e) {
        if (e.getEntity() instanceof Player p && thor(p)) e.setCanceled(true);
    }

    /** Con il siero del super soldato i mob ostili uccisi si contano: a 50 diventi degno. */
    @SubscribeEvent
    public static void onKill(LivingDeathEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer p) || !(e.getEntity() instanceof Enemy) || !soldier(p)) return;
        int before = kills(p);
        if (before >= KILLS_NEEDED) return;
        int n = before + 1;
        p.getPersistentData().putInt(KILLS, n);
        if (n == KILLS_NEEDED) SuitData.msg(p, "msg.ironmanmod.worthy_unlocked");
        else if (n % 10 == 0) p.displayClientMessage(Component.translatable("msg.ironmanmod.kills", n, KILLS_NEEDED), true);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        var from = e.getOriginal().getPersistentData();
        var to = e.getEntity().getPersistentData();
        for (String k : KEYS) {
            if (from.contains(k)) to.put(k, from.get(k).copy());
        }
    }

    /** /serum thor|soldier|reset: per provare (serve essere operatori). */
    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(net.minecraft.commands.Commands.literal("serum")
                .requires(s -> s.hasPermission(2))
                .then(net.minecraft.commands.Commands.literal("thor").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    p.getPersistentData().putBoolean(THOR, true);
                    p.sendSystemMessage(Component.literal("Siero del dio del tuono: attivo"));
                    return 1;
                }))
                .then(net.minecraft.commands.Commands.literal("soldier").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    p.getPersistentData().putBoolean(SOLDIER, true);
                    p.sendSystemMessage(Component.literal("Siero del super soldato: attivo (uccisioni ostili: " + kills(p) + "/" + KILLS_NEEDED + ")"));
                    return 1;
                }))
                .then(net.minecraft.commands.Commands.literal("reset").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    p.getPersistentData().remove(THOR);
                    p.getPersistentData().remove(SOLDIER);
                    p.getPersistentData().remove(KILLS);
                    p.sendSystemMessage(Component.literal("Sieri e uccisioni azzerati"));
                    return 1;
                })));
    }
}
