package com.ironmanmod;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.crafting.Ingredient;

/** Occhiali E.D.I.T.H.: si indossano nello slot dell'elmo e mostrano il visore (bussola, coordinate, scansione dei mob). */
public class EdithGlassesItem extends ArmorItem {
    public static final ArmorMaterial MATERIAL = new ArmorMaterial() {
        @Override public int getDurabilityForType(ArmorItem.Type t) { return 120; }
        @Override public int getDefenseForType(ArmorItem.Type t) { return 0; }
        @Override public int getEnchantmentValue() { return 15; }
        @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_GENERIC; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(net.minecraft.world.item.Items.DIAMOND); }
        @Override public String getName() { return IronManMod.MODID + ":edith"; }
        @Override public float getToughness() { return 0f; }
        @Override public float getKnockbackResistance() { return 0f; }
    };

    public EdithGlassesItem() {
        super(MATERIAL, ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.RARE));
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return IronManMod.MODID + ":textures/models/armor/edith_glasses.png";
    }
}
