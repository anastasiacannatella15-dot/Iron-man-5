package com.ironmanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import java.util.List;

/** Nucleo di Ultron: clicca su un blocco e Ultron nasce. La forma dipende dal nucleo (0 AI, 1 Mark II, 2 Mark III, 3 Prime). Solo l'AI si crafta. */
public class UltronCoreItem extends Item {
    private final int variant;

    public UltronCoreItem(int variant) {
        super(new Item.Properties().stacksTo(16).rarity(variant >= 3 ? Rarity.EPIC : Rarity.RARE));
        this.variant = variant;
    }

    @Override
    public InteractionResult useOn(UseOnContext c) {
        Level l = c.getLevel();
        if (!(l instanceof ServerLevel sl)) return InteractionResult.SUCCESS;
        UltronEntity u = IronManMod.ULTRON.get().create(sl);
        if (u == null) return InteractionResult.PASS;
        BlockPos pos = c.getClickedPos().relative(c.getClickedFace());
        u.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, c.getRotation() + 180f, 0f);
        u.setVariant(variant);
        sl.addFreshEntity(u);
        LightningBolt lb = EntityType.LIGHTNING_BOLT.create(sl);
        if (lb != null) {
            lb.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            lb.setVisualOnly(true);
            sl.addFreshEntity(lb);
        }
        sl.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 1.5f, 0.5f);
        u.announce();
        Player p = c.getPlayer();
        if (p == null || !p.isCreative()) c.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("tooltip.ironmanmod.ultron_core").withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
