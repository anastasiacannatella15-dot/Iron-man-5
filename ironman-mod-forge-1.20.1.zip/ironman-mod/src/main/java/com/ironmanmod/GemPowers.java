package com.ironmanmod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.List;

/**
 * Poteri nativi delle gemme incastonate nel Mjolnir / Stormbreaker (non dipendono da Palladium).
 * Tasto K = usa il potere della gemma scelta, Shift + K = cambia gemma. Il raggio del Potere parte dalla testa del martello e si allarga.
 */
public final class GemPowers {
    public static final int A_GEM = 18, A_GEM_CYCLE = 19;
    private static final String SEL = "GemSel";

    private GemPowers() {
    }

    public static boolean isAction(int a) {
        return a == A_GEM || a == A_GEM_CYCLE;
    }

    /** Gemma scelta in questo momento (null se il martello non ne ha). */
    public static String selected(ItemStack hammer) {
        List<String> l = MjolnirGems.list(hammer);
        if (l.isEmpty()) return null;
        return l.get(Math.floorMod(hammer.getOrCreateTag().getInt(SEL), l.size()));
    }

    private static DustParticleOptions dust(String stone, float size) {
        float[] c = MjolnirGems.color(stone);
        return new DustParticleOptions(new Vector3f(c[0], c[1], c[2]), size);
    }

    public static void handle(ServerPlayer p, int a) {
        ItemStack h = p.getMainHandItem();
        if (!(h.getItem() instanceof MjolnirItem)) {
            SuitData.msg(p, "msg.ironmanmod.mj_hold");
            return;
        }
        if (!MjolnirItem.worthy(h, p)) return;
        List<String> gl = MjolnirGems.list(h);
        if (gl.isEmpty()) {
            SuitData.msg(p, "msg.ironmanmod.gem_none");
            return;
        }
        var tag = h.getOrCreateTag();
        if (a == A_GEM_CYCLE) {
            tag.putInt(SEL, Math.floorMod(tag.getInt(SEL) + 1, gl.size()));
            p.displayClientMessage(Component.translatable("msg.ironmanmod.gem_selected", Component.translatable("gem.ironmanmod." + selected(h))), true);
            return;
        }
        if (!SuitData.ready(p, "gem")) return;
        String g = selected(h);
        ServerLevel sl = p.serverLevel();
        switch (g) {
            case "power" -> {
                SuitData.setCooldown(p, "gem", 60);
                powerBeam(p, sl);
            }
            case "space" -> {
                SuitData.setCooldown(p, "gem", 40);
                space(p, sl);
            }
            case "reality" -> {
                SuitData.setCooldown(p, "gem", 60);
                reality(p, sl);
            }
            case "time" -> {
                SuitData.setCooldown(p, "gem", 100);
                time(p, sl);
            }
            case "soul" -> {
                SuitData.setCooldown(p, "gem", 80);
                soul(p, sl);
            }
            case "mind" -> {
                SuitData.setCooldown(p, "gem", 100);
                mind(p, sl);
            }
            default -> {
            }
        }
    }

    private static Vec3 hammerTip(ServerPlayer p) {
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        return p.getEyePosition().add(look.scale(0.9)).add(right.scale(0.35)).subtract(0, 0.35, 0);
    }

    /** Raggio viola della Gemma del Potere: parte dal martello e si disperde, piu' e' lontano piu' e' largo. */
    private static void powerBeam(ServerPlayer p, ServerLevel sl) {
        Vec3 look = p.getLookAngle();
        Vec3 from = hammerTip(p);
        Vec3 eye = p.getEyePosition();
        Vec3 far = eye.add(look.scale(40));
        BlockHitResult bh = sl.clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 end = bh.getType() != HitResult.Type.MISS ? bh.getLocation() : far;
        double len = Math.max(1.0, from.distanceTo(end));
        DustParticleOptions purple = dust("power", 1.7f);
        for (double d = 0; d <= len; d += 0.6) {
            Vec3 pt = from.add(look.scale(d));
            double spread = 0.04 + d * 0.035;
            sl.sendParticles(purple, pt.x, pt.y, pt.z, 2 + (int) (d / 8), spread, spread, spread, 0);
        }
        sl.sendParticles(dust("power", 3.0f), end.x, end.y, end.z, 90, 1.3, 1.3, 1.3, 0); // nube che si disperde all'arrivo
        sl.sendParticles(ParticleTypes.FLASH, from.x, from.y, from.z, 1, 0, 0, 0, 0);
        sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.0f, 1.3f);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, new AABB(from, end).inflate(5), t -> t != p && t.isAlive())) {
            Vec3 rel = e.position().add(0, e.getBbHeight() / 2, 0).subtract(from);
            double t = rel.dot(look);
            if (t < 0 || t > len + 1) continue;
            if (rel.subtract(look.scale(t)).length() > 0.8 + 0.06 * t) continue; // il raggio si allarga con la distanza
            e.hurt(sl.damageSources().playerAttack(p), 30f /* uguale per giocatori e mob */);
            e.push(look.x * 1.2, 0.3, look.z * 1.2);
            e.hurtMarked = true;
        }
    }

    private static void space(ServerPlayer p, ServerLevel sl) {
        Vec3 look = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        Vec3 far = eye.add(look.scale(14));
        BlockHitResult bh = sl.clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 end = bh.getType() != HitResult.Type.MISS ? bh.getLocation().subtract(look.scale(0.9)) : far;
        DustParticleOptions blue = dust("space", 1.5f);
        for (double d = 0; d <= eye.distanceTo(end); d += 0.7) {
            Vec3 pt = eye.add(look.scale(d));
            sl.sendParticles(blue, pt.x, pt.y, pt.z, 2, 0.1, 0.1, 0.1, 0);
        }
        p.teleportTo(end.x, end.y - p.getEyeHeight(), end.z);
        p.fallDistance = 0f;
        p.getPersistentData().putLong("mj_nofall", sl.getGameTime() + 60);
        sl.sendParticles(blue, end.x, end.y, end.z, 60, 0.6, 0.8, 0.6, 0);
        sl.playSound(null, end.x, end.y, end.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0f, 1.2f);
    }

    private static void reality(ServerPlayer p, ServerLevel sl) {
        Vec3 look = p.getLookAngle();
        Vec3 from = hammerTip(p);
        for (double d = 1; d <= 10; d += 0.7) {
            Vec3 pt = from.add(look.scale(d));
            double s = 0.1 + d * 0.1;
            sl.sendParticles(dust("reality", 1.6f), pt.x, pt.y, pt.z, 4, s, s, s, 0);
            sl.sendParticles(ParticleTypes.FLAME, pt.x, pt.y, pt.z, 1, s, s, s, 0.01);
        }
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(10), t -> t != p && t.isAlive())) {
            Vec3 rel = e.position().add(0, e.getBbHeight() / 2, 0).subtract(from);
            double dist = rel.length();
            if (dist > 10 || dist < 0.1 || rel.normalize().dot(look) < 0.7) continue;
            e.setSecondsOnFire(10);
            e.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
            e.hurt(sl.damageSources().magic(), 6f);
        }
        sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0f, 0.7f);
    }

    private static void ring(ServerLevel sl, ServerPlayer p, String stone, double r) {
        for (int i = 0; i < 48; i++) {
            double a = Math.PI * 2 * i / 48;
            sl.sendParticles(dust(stone, 1.6f), p.getX() + Math.cos(a) * r, p.getY() + 0.3, p.getZ() + Math.sin(a) * r, 1, 0, 0.2, 0, 0);
        }
    }

    private static void time(ServerPlayer p, ServerLevel sl) {
        ring(sl, p, "time", 10);
        sl.sendParticles(dust("time", 2.0f), p.getX(), p.getY() + 1, p.getZ(), 60, 3, 1.2, 3, 0);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(10), t -> t != p && t.isAlive())) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 4));
            e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 160, 2));
        }
        sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 0.5f);
    }

    private static void soul(ServerPlayer p, ServerLevel sl) {
        ring(sl, p, "soul", 8);
        float dealt = 0f;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(8), t -> t != p && t.isAlive())) {
            float before = e.getHealth();
            e.hurt(sl.damageSources().magic(), 5f);
            dealt += Math.max(0f, before - e.getHealth());
            sl.sendParticles(ParticleTypes.SOUL, e.getX(), e.getY() + 1, e.getZ(), 8, 0.3, 0.5, 0.3, 0.05);
        }
        p.heal(dealt * 0.5f);
        sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.SOUL_ESCAPE, SoundSource.PLAYERS, 1.0f, 0.8f);
    }

    private static void mind(ServerPlayer p, ServerLevel sl) {
        ring(sl, p, "mind", 14);
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(14), t -> t != p && t.isAlive())) {
            if (e instanceof Mob m) m.setTarget(null);
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
            e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
        }
        sl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0f, 1.6f);
    }
}
