package com.ironmanmod;

import com.mojang.serialization.Codec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.common.SoundActions;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fluids.FluidType;
import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Consumer;

/** Uru (blocco, lingotto, fluido fuso), matrice del Mjolnir, meteorite e loot dei villaggi. */
public final class ModContent {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, IronManMod.MODID);
    public static final DeferredRegister<FluidType> FLUID_TYPES = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, IronManMod.MODID);
    public static final DeferredRegister<Fluid> FLUIDS = DeferredRegister.create(ForgeRegistries.FLUIDS, IronManMod.MODID);
    public static final DeferredRegister<net.minecraft.world.level.levelgen.structure.StructureType<?>> STRUCTURE_TYPES =
            DeferredRegister.create(net.minecraft.core.registries.Registries.STRUCTURE_TYPE, IronManMod.MODID);
    public static final DeferredRegister<net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType> STRUCTURE_PIECES =
            DeferredRegister.create(net.minecraft.core.registries.Registries.STRUCTURE_PIECE, IronManMod.MODID);
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, IronManMod.MODID);

    public static final RegistryObject<Block> URU_BLOCK = BLOCKS.register("uru_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(50f, 1200f)
                    .requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK).lightLevel(s -> 5)));
    public static final RegistryObject<Item> URU_BLOCK_ITEM = IronManMod.ITEMS.register("uru_block",
            () -> new BlockItem(URU_BLOCK.get(), new Item.Properties().fireResistant().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> URU_INGOT = IronManMod.ITEMS.register("uru_ingot",
            () -> new Item(new Item.Properties().fireResistant().rarity(Rarity.RARE)));
    public static final RegistryObject<Block> TITANIUM_ORE = BLOCKS.register("titanium_ore",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(4.0f, 6.0f)
                    .requiresCorrectToolForDrops().sound(SoundType.STONE)));
    public static final RegistryObject<Item> TITANIUM_ORE_ITEM = IronManMod.ITEMS.register("titanium_ore",
            () -> new BlockItem(TITANIUM_ORE.get(), new Item.Properties()));
    public static final RegistryObject<Item> TITANIUM_INGOT = IronManMod.ITEMS.register("titanium_ingot",
            () -> new Item(new Item.Properties()));

    // ---- vibranio, siringhe e sieri
    public static final RegistryObject<Block> VIBRANIUM_ORE = BLOCKS.register("vibranium_ore",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(8.0f, 12.0f)
                    .requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE)));
    public static final RegistryObject<Item> VIBRANIUM_ORE_ITEM = IronManMod.ITEMS.register("vibranium_ore",
            () -> new BlockItem(VIBRANIUM_ORE.get(), new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> VIBRANIUM_INGOT = IronManMod.ITEMS.register("vibranium_ingot",
            () -> new Item(new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> VIBRANIUM_SHIELD = IronManMod.ITEMS.register("vibranium_shield",
            VibraniumShieldItem::new);
    public static final RegistryObject<Item> EMPTY_SYRINGE = IronManMod.ITEMS.register("empty_syringe",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> THOR_SERUM = IronManMod.ITEMS.register("thor_serum",
            () -> new SerumItem(Worthy.THOR));
    public static final RegistryObject<Item> SOLDIER_SERUM = IronManMod.ITEMS.register("soldier_serum",
            () -> new SerumItem(Worthy.SOLDIER));

    public static final RegistryObject<Item> MJOLNIR_CAST = IronManMod.ITEMS.register("mjolnir_cast",
            () -> new Item(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> STORMBREAKER_CAST = IronManMod.ITEMS.register("stormbreaker_cast",
            () -> new Item(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC)));

    // ---- Uru fuso
    public static final RegistryObject<FluidType> MOLTEN_URU_TYPE = FLUID_TYPES.register("molten_uru",
            () -> new FluidType(FluidType.Properties.create().density(3000).viscosity(6000).temperature(1300).lightLevel(13)
                    .canSwim(false).canDrown(false).supportsBoating(false)
                    .sound(SoundActions.BUCKET_FILL, SoundEvents.BUCKET_FILL_LAVA)
                    .sound(SoundActions.BUCKET_EMPTY, SoundEvents.BUCKET_EMPTY_LAVA)) {
                @Override
                public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer) {
                    consumer.accept(new IClientFluidTypeExtensions() {
                        private final ResourceLocation still = new ResourceLocation(IronManMod.MODID, "block/molten_uru_still");
                        private final ResourceLocation flow = new ResourceLocation(IronManMod.MODID, "block/molten_uru_flow");

                        @Override
                        public ResourceLocation getStillTexture() {
                            return still;
                        }

                        @Override
                        public ResourceLocation getFlowingTexture() {
                            return flow;
                        }
                    });
                }
            });
    public static final RegistryObject<FlowingFluid> MOLTEN_URU = FLUIDS.register("molten_uru",
            () -> new ForgeFlowingFluid.Source(ModContent.fluidProps()));
    public static final RegistryObject<FlowingFluid> MOLTEN_URU_FLOWING = FLUIDS.register("flowing_molten_uru",
            () -> new ForgeFlowingFluid.Flowing(ModContent.fluidProps()));
    public static final RegistryObject<LiquidBlock> MOLTEN_URU_BLOCK = BLOCKS.register("molten_uru",
            () -> new LiquidBlock(ModContent.MOLTEN_URU, BlockBehaviour.Properties.copy(net.minecraft.world.level.block.Blocks.LAVA).noLootTable()));
    public static final RegistryObject<Item> MOLTEN_URU_BUCKET = IronManMod.ITEMS.register("molten_uru_bucket",
            () -> new BucketItem(ModContent.MOLTEN_URU, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));

    // ---- worldgen e loot
    public static final RegistryObject<net.minecraft.world.level.levelgen.structure.StructureType<?>> METEORITE_STRUCTURE =
            STRUCTURE_TYPES.register("meteorite", () -> (net.minecraft.world.level.levelgen.structure.StructureType<MeteoriteStructure>) () -> MeteoriteStructure.CODEC);
    public static final RegistryObject<net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType> METEORITE_PIECE =
            STRUCTURE_PIECES.register("meteorite", () -> (net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType.ContextlessType) MeteoritePiece::new);
    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> ADD_CAST = LOOT_MODIFIERS.register("add_mjolnir_cast",
            CastLootModifier.CODEC);

    private ModContent() {
    }

    private static ForgeFlowingFluid.Properties fluidProps() {
        return new ForgeFlowingFluid.Properties(MOLTEN_URU_TYPE, MOLTEN_URU, MOLTEN_URU_FLOWING)
                .bucket(MOLTEN_URU_BUCKET).block(MOLTEN_URU_BLOCK).slopeFindDistance(2).levelDecreasePerBlock(2);
    }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        FLUID_TYPES.register(bus);
        FLUIDS.register(bus);
        STRUCTURE_TYPES.register(bus);
        STRUCTURE_PIECES.register(bus);
        LOOT_MODIFIERS.register(bus);
    }
}
