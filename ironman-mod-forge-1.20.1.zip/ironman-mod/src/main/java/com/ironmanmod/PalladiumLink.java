package com.ironmanmod;

import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.ModList;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Collega il Mjolnir e lo Stormbreaker a Palladium: le gemme inserite danno i poteri veri della mod Infinity di
 * Pugmeowla finche' tieni l'arma in mano; quando la lasci i poteri vengono tolti.
 * Le abilita' di Infinity pretendono la pietra in mano (o il Guanto): per questo la mod include copie dei poteri
 * (data/ironmanmod/palladium/powers/mj_*.json e sb_*.json) dove "la pietra in mano" e' sostituita dall'arma in mano.
 * Usa il comando /superpower di Palladium (sintassi verificata sul suo codice).
 */
public final class PalladiumLink {
    private static final String KEY = "MjGranted";   // vecchio formato: solo nomi di gemma (Mjolnir)
    private static final String KEY2 = "WeaponPowers"; // nuovo formato: id completi dei poteri

    private PalladiumLink() {}

    public static boolean present() {
        return ModList.get().isLoaded("palladium");
    }

    /** Id dei poteri Palladium per le gemme inserite nell'arma. */
    public static List<String> ids(ItemStack weapon) {
        String pre = weapon.getItem() instanceof StormbreakerItem ? "sb_" : "mj_";
        List<String> out = new ArrayList<>();
        for (String g : MjolnirGems.list(weapon)) out.add(IronManMod.MODID + ":" + pre + g + "_stone");
        return out;
    }

    private static boolean run(ServerPlayer p, String op, String id) {
        var server = p.getServer();
        if (server == null) return false;
        var src = p.createCommandSourceStack().withPermission(4).withSuppressedOutput();
        try {
            // sintassi verificata sul codice di Palladium 4.5.9: /superpower <add|remove> <potere> [entita']
            return server.getCommands().performPrefixedCommand(src, "superpower " + op + " " + id) > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** Allinea i poteri Palladium del giocatore a quelli dell'arma che ha in mano (lista vuota = togli tutto). */
    public static void sync(ServerPlayer p, List<String> ids) {
        if (!present()) return;
        var data = p.getPersistentData();
        Set<String> have = new HashSet<>();
        if (data.contains(KEY)) { // migra dal vecchio formato
            ListTag old = data.getList(KEY, 8);
            for (int i = 0; i < old.size(); i++) have.add(IronManMod.MODID + ":mj_" + old.getString(i) + "_stone");
            data.remove(KEY);
        }
        ListTag cur = data.getList(KEY2, 8);
        for (int i = 0; i < cur.size(); i++) have.add(cur.getString(i));
        Set<String> want = new HashSet<>(ids);
        if (have.equals(want)) return;
        List<String> now = new ArrayList<>(have);
        for (String id : want) {
            if (!have.contains(id) && run(p, "add", id)) now.add(id);
        }
        for (String id : have) {
            if (!want.contains(id)) {
                run(p, "remove", id);
                now.remove(id);
            }
        }
        ListTag out = new ListTag();
        for (String id : now) out.add(StringTag.valueOf(id));
        data.put(KEY2, out);
    }
}
