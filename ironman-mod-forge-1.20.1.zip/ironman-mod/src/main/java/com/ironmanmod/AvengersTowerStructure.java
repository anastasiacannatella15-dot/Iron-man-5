package com.ironmanmod;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

import java.util.Optional;

/** La Avengers Tower come vera struttura: /locate structure ironmanmod:avengers_tower e Explorer's Compass. */
public class AvengersTowerStructure extends Structure {
    public static final Codec<AvengersTowerStructure> CODEC = simpleCodec(AvengersTowerStructure::new);

    public AvengersTowerStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext ctx) {
        ChunkPos cp = ctx.chunkPos();
        int x = cp.getMiddleBlockX(), z = cp.getMiddleBlockZ();
        var g = ctx.chunkGenerator();
        var ha = ctx.heightAccessor();
        var rs = ctx.randomState();
        int y = g.getFirstOccupiedHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, ha, rs);
        if (y + AvengersTowerPiece.H + 2 > ha.getMaxBuildHeight()) return Optional.empty();
        if (!g.getBaseColumn(x, z, ha, rs).getBlock(y - 1).getFluidState().isEmpty()) return Optional.empty(); // niente acqua
        int[][] off = {{12, 12}, {-12, 12}, {12, -12}, {-12, -12}};
        for (int[] o : off) {
            int yy = g.getFirstOccupiedHeight(x + o[0], z + o[1], Heightmap.Types.WORLD_SURFACE_WG, ha, rs);
            if (Math.abs(yy - y) > 6) return Optional.empty(); // terreno abbastanza piano
            if (!g.getBaseColumn(x + o[0], z + o[1], ha, rs).getBlock(yy - 1).getFluidState().isEmpty()) return Optional.empty();
        }
        final int gy = y - 1;
        return Optional.of(new Structure.GenerationStub(new BlockPos(x, gy, z),
                builder -> builder.addPiece(new AvengersTowerPiece(x, gy, z))));
    }

    @Override
    public StructureType<?> type() {
        return ModContent.TOWER_STRUCTURE.get();
    }
}
