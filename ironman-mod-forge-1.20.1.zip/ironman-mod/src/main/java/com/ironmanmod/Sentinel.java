package com.ironmanmod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Attiva la modalita' sentinella: l'armatura esce dal giocatore e combatte da sola. */
public final class Sentinel {
    private Sentinel() {
    }

    public static void activate(ServerPlayer p) {
        CompoundTag r = SuitData.root(p);
        if (r.getInt("phase") != 0 || r.getInt("active") > 0 || !SuitData.hasMk42Set(p)) {
            SuitData.msg(p, "msg.ironmanmod.sentinel_need");
            return;
        }
        ServerLevel lvl = p.serverLevel();
        SentinelEntity e = IronManMod.SENTINEL.get().create(lvl);
        if (e == null) return;
        e.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), 0f);
        e.setOwner(p);
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack st = p.getItemBySlot(s);
            e.setItemSlot(s, st.copy());
            p.setItemSlot(s, ItemStack.EMPTY);
        }
        lvl.addFreshEntity(e);
        lvl.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.4f);
        SuitData.msg(p, "msg.ironmanmod.sentinel_on");
    }
}
