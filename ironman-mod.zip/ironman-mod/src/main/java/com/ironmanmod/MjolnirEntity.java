package com.ironmanmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Il Mjolnir nel mondo: in piedi a terra (sulla testa), lanciato, o in volo verso il proprietario. */
public class MjolnirEntity extends Entity {
    private static final EntityDataAccessor<ItemStack> STACK = SynchedEntityData.defineId(MjolnirEntity.class, EntityDataSerializers.ITEM_STACK);
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(MjolnirEntity.class, EntityDataSerializers.INT);
    public static final int STANDING = 0, THROWN = 1, RETURNING = 2;
    public static final float THROW_DAMAGE = 16f;

    private UUID target;
    private int life;
    private final Set<Integer> hit = new HashSet<>();

    public MjolnirEntity(EntityType<? extends MjolnirEntity> type, Level level) {
        super(type, level);
    }

    public MjolnirEntity(Level level) {
        this(IronManMod.MJOLNIR_ENTITY.get(), level);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(STACK, new ItemStack(IronManMod.MJOLNIR.get()));
        entityData.define(STATE, STANDING);
    }

    public ItemStack getStack() {
        return entityData.get(STACK);
    }

    public void setStack(ItemStack s) {
        entityData.set(STACK, s);
    }

    public int getState() {
        return entityData.get(STATE);
    }

    public void setState(int s) {
        entityData.set(STATE, s);
        noPhysics = s == RETURNING;
        life = 0;
        hit.clear();
    }

    public void recall(Player p) {
        target = p.getUUID();
        setState(RETURNING);
        setNoGravity(true);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag t) {
        setStack(ItemStack.of(t.getCompound("Stack")));
        entityData.set(STATE, t.getInt("State"));
        noPhysics = getState() == RETURNING;
        if (t.hasUUID("Target")) target = t.getUUID("Target");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag t) {
        t.put("Stack", getStack().save(new CompoundTag()));
        t.putInt("State", getState());
        if (target != null) t.putUUID("Target", target);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        switch (getState()) {
            case THROWN -> thrown();
            case RETURNING -> returning();
            default -> standing();
        }
        if (getY() < level().getMinBuildHeight() - 10) {
            UUID o = MjolnirItem.owner(getStack());
            if (o != null) {
                target = o;
                setState(RETURNING);
            } else {
                discard();
            }
        }
    }

    private void standing() {
        Vec3 dm = getDeltaMovement();
        if (!onGround()) dm = dm.add(0, -0.08, 0); // gravita' normale: cade subito
        setDeltaMovement(dm);
        move(MoverType.SELF, getDeltaMovement());
        dm = getDeltaMovement();
        float f = onGround() ? 0.5f : 0.98f;
        setDeltaMovement(dm.x * f, onGround() ? 0 : dm.y * 0.98, dm.z * f);
    }

    private Player ownerPlayer() {
        UUID o = MjolnirItem.owner(getStack());
        return o == null ? null : level().getPlayerByUUID(o);
    }

    private void thrown() {
        life++;
        Player owner = ownerPlayer();
        move(MoverType.SELF, getDeltaMovement());
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(0.8),
                x -> x.isAlive() && x != owner && !hit.contains(x.getId()))) {
            hit.add(e.getId());
            DamageSource src = damageSources().thrown(this, owner);
            if (e.hurt(src, THROW_DAMAGE)) {
                Vec3 d = getDeltaMovement().normalize();
                e.push(d.x * 1.2, 0.3, d.z * 1.2);
                e.hurtMarked = true;
            }
            e.setSecondsOnFire(5);
            if (level() instanceof ServerLevel sl) {
                LightningBolt lb = EntityType.LIGHTNING_BOLT.create(sl);
                if (lb != null) {
                    lb.moveTo(e.getX(), e.getY(), e.getZ());
                    lb.setVisualOnly(true);
                    sl.addFreshEntity(lb);
                }
            }
        }
        if (level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.4, getZ(), 3, 0.2, 0.2, 0.2, 0.05);
        if (horizontalCollision || verticalCollision || life > 30) {
            setDeltaMovement(Vec3.ZERO);
            setState(STANDING);
            setNoGravity(false);
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.8f, 1.2f);
        }
    }

    private void returning() {
        Player p = target == null ? null : level().getPlayerByUUID(target);
        if (p == null || !p.isAlive()) {
            setNoGravity(false);
            setState(STANDING);
            return;
        }
        life++;
        Vec3 to = p.position().add(0, p.getBbHeight() * 0.5, 0).subtract(position());
        double d = to.length();
        if (d < 1.3) {
            giveTo(p);
            return;
        }
        Vec3 v = to.scale(1.0 / d).scale(Math.min(1.8, Math.max(0.6, d * 0.5)));
        setDeltaMovement(v);
        setPos(getX() + v.x, getY() + v.y, getZ() + v.z);
        if (level() instanceof ServerLevel sl) sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.4, getZ(), 3, 0.2, 0.2, 0.2, 0.05);
        if (life > 200) { // non riesce ad arrivare
            setNoGravity(false);
            setState(STANDING);
        }
    }

    private void giveTo(Player p) {
        ItemStack s = getStack().copy();
        if (p.getMainHandItem().isEmpty()) {
            p.setItemInHand(InteractionHand.MAIN_HAND, s);
        } else if (!p.getInventory().add(s)) {
            setNoGravity(false);
            setState(STANDING);
            setPos(p.getX(), p.getY(), p.getZ());
            return;
        }
        level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.TRIDENT_RETURN, SoundSource.PLAYERS, 1.0f, 1.0f);
        discard();
    }

    /** Tasto destro: lo prendi (solo il proprietario se e' legato). Passandoci sopra non succede niente. */
    @Override
    public InteractionResult interact(Player p, InteractionHand hand) {
        if (getState() != STANDING) return InteractionResult.PASS;
        if (!MjolnirItem.worthy(getStack(), p)) {
            if (!level().isClientSide) p.displayClientMessage(Component.translatable("msg.ironmanmod.mj_unworthy", MjolnirItem.ownerName(getStack())), true);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (!level().isClientSide) giveTo(p);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource src) {
        return true;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
