package com.ironmanmod;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** I tre modelli di armatura. Funge anche da materiale armatura. */
public enum SuitMark implements ArmorMaterial {
    // num id  energia volo  boost  repulsore unibeam missili dannoSubito difesa(stivali,gambali,petto,casco)  tough  kb
    // Armor: tutte e tre 20 punti come diamante/netherite. Differenze: tenacia e riduzione extra del danno.
    MARK_42(42, "mark42", 2000, 0.065f, 1.4, 10f, 0f, 4, 0.90f, new int[]{3, 6, 8, 3}, 2.5f, 0.0f),
    MARK_50(50, "mark50", 4500, 0.085f, 2.0, 13f, 30f, 6, 1.00f, new int[]{2, 5, 6, 2}, 5.0f, 0.5f),
    MARK_85(85, "mark85", 9000, 0.110f, 2.6, 16f, 40f, 8, 0.25f, new int[]{3, 6, 8, 3}, 6.0f, 0.5f);

    public final int number;
    public final String id;
    public final int maxEnergy;
    public final float flySpeed;
    public final double boost;
    public final float repulsorDamage;
    public final float unibeamDamage;
    public final int missiles;
    /** Moltiplicatore del danno subito (dopo la protezione normale): 1.0 = nessun extra, 0.25 = prendi un quarto. */
    public final float damageTaken;
    private final int[] defense;
    private final float toughness;
    private final float knockback;

    SuitMark(int number, String id, int maxEnergy, float flySpeed, double boost, float repulsorDamage,
             float unibeamDamage, int missiles, float damageTaken, int[] defense, float toughness, float knockback) {
        this.number = number;
        this.id = id;
        this.maxEnergy = maxEnergy;
        this.flySpeed = flySpeed;
        this.boost = boost;
        this.repulsorDamage = repulsorDamage;
        this.unibeamDamage = unibeamDamage;
        this.missiles = missiles;
        this.damageTaken = damageTaken;
        this.defense = defense;
        this.toughness = toughness;
        this.knockback = knockback;
    }

    public static SuitMark byNumber(int n) {
        for (SuitMark m : values()) {
            if (m.number == n) return m;
        }
        return null;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        if (this != MARK_42) return 9999; // nanotech: non si rompe
        int base = switch (type) {
            case BOOTS -> 13;
            case LEGGINGS -> 15;
            case CHESTPLATE -> 16;
            case HELMET -> 11;
        };
        return base * 40; // un po' piu' del diamante (x33)
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case BOOTS -> defense[0];
            case LEGGINGS -> defense[1];
            case CHESTPLATE -> defense[2];
            case HELMET -> defense[3];
        };
    }

    @Override
    public int getEnchantmentValue() {
        return this == MARK_42 ? 10 : 0;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_NETHERITE;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this == MARK_42 ? Ingredient.of(net.minecraft.world.item.Items.DIAMOND) : Ingredient.EMPTY;
    }

    @Override
    public String getName() {
        return IronManMod.MODID + ":" + id;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockback;
    }
}
