package com.ironmanmod;

import com.ironmanmod.net.Net;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

@Mod(IronManMod.MODID)
public class IronManMod {
    public static final String MODID = "ironmanmod";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<net.minecraft.world.entity.EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<SuitMark, Map<ArmorItem.Type, RegistryObject<Item>>> ARMOR = new EnumMap<>(SuitMark.class);
    public static final Map<SuitMark, RegistryObject<Item>> REACTORS = new EnumMap<>(SuitMark.class);

    static {
        for (SuitMark m : SuitMark.values()) {
            Map<ArmorItem.Type, RegistryObject<Item>> pieces = new EnumMap<>(ArmorItem.Type.class);
            for (ArmorItem.Type t : ArmorItem.Type.values()) {
                if (m == SuitMark.MARK_42) {
                    pieces.put(t, ITEMS.register(m.id + "_" + t.getName(), () -> new HeroArmorItem(m, t)));
                } else {
                    pieces.put(t, ITEMS.register(m.id + "_" + t.getName(), () -> new SuitArmorItem(m, t)));
                }
            }
            ARMOR.put(m, pieces);
            if (m != SuitMark.MARK_42) { // la Mark 42 non ha nanotech, quindi niente reattore
                REACTORS.put(m, ITEMS.register("arc_reactor_" + m.id, () -> new ReactorItem(m)));
            }
        }
    }

    public static final RegistryObject<Item> MJOLNIR = ITEMS.register("mjolnir", MjolnirItem::new);
    public static final RegistryObject<net.minecraft.world.entity.EntityType<MjolnirEntity>> MJOLNIR_ENTITY = ENTITIES.register("mjolnir",
            () -> net.minecraft.world.entity.EntityType.Builder.<MjolnirEntity>of(MjolnirEntity::new, net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.7f, 1.0f).clientTrackingRange(10).updateInterval(1).fireImmune().build("mjolnir"));

    public static final RegistryObject<net.minecraft.world.entity.EntityType<SentinelEntity>> SENTINEL = ENTITIES.register("sentinel",
            () -> net.minecraft.world.entity.EntityType.Builder.<SentinelEntity>of(SentinelEntity::new, net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.6f, 1.9f).clientTrackingRange(10).fireImmune().build("sentinel"));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.ironmanmod"))
                    .icon(() -> new ItemStack(REACTORS.get(SuitMark.MARK_85).get()))
                    .displayItems((params, out) -> {
                        for (RegistryObject<Item> a : ARMOR.get(SuitMark.MARK_42).values()) out.accept(a.get());
                        for (RegistryObject<Item> r : REACTORS.values()) out.accept(r.get());
                        out.accept(MJOLNIR.get());
                        out.accept(ModContent.MJOLNIR_CAST.get());
                        out.accept(ModContent.URU_INGOT.get());
                        out.accept(ModContent.TITANIUM_INGOT.get());
                        out.accept(ModContent.TITANIUM_ORE_ITEM.get());
                        out.accept(ModContent.URU_BLOCK_ITEM.get());
                        out.accept(ModContent.MOLTEN_URU_BUCKET.get());
                    })
                    .build());

    public IronManMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModContent.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        ENTITIES.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::init));
    }
}
