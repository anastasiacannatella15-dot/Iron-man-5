package com.ironmanmod.client;

import com.ironmanmod.HeroArmorItem;
import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitArmorItem;
import com.ironmanmod.SuitData;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Animazioni dell'armatura: braccio destro alzato quando spara il repulsore, volo "da film" (corpo inclinato in avanti
 * in base alla velocita') e fiamme dei repulsori nelle gambe.
 */
@Mod.EventBusSubscriber(modid = IronManMod.MODID, value = Dist.CLIENT)
public final class FlightRender {
    private static final Map<Integer, Float> LEAN = new HashMap<>();
    private static final Set<Integer> PUSHED = new HashSet<>();

    private FlightRender() {
    }

    /** Il modello di armatura indossato (nanotech o set Mark 42 completo), altrimenti null. */
    static com.ironmanmod.SuitMark suitMark(Player p) {
        ItemStack c = p.getItemBySlot(EquipmentSlot.CHEST);
        if (c.getItem() instanceof SuitArmorItem sa) return sa.mark;
        if (c.getItem() instanceof HeroArmorItem ha && SuitData.hasMk42Set(p)) return ha.mark;
        return null;
    }

    private static boolean suited(Player p) {
        return suitMark(p) != null;
    }

    private static boolean flying(Player p) {
        if (!suited(p) || p.onGround() || p.isInWater() || p.isPassenger() || p.isFallFlying()) return false;
        if (p.getAbilities().flying) return true;
        Vec3 v = p.getDeltaMovement();
        return p != Minecraft.getInstance().player && v.x * v.x + v.z * v.z > 0.0025;
    }

    @SubscribeEvent
    public static void onPre(RenderLivingEvent.Pre<?, ?> e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (e.getRenderer().getModel() instanceof PlayerModel<?> pm && ClientState.isArmUp(p.getId())) {
            pm.rightArmPose = HumanoidModel.ArmPose.SPYGLASS; // braccio destro alzato in avanti
        } else if (e.getRenderer().getModel() instanceof PlayerModel<?> pm2 && ClientState.isTouch(p.getId())) {
            pm2.rightArmPose = HumanoidModel.ArmPose.BLOCK; // la mano va sul reattore arc al centro del petto
        }
        float target = 0f;
        if (flying(p)) {
            Vec3 v = p.getDeltaMovement();
            double yaw = Math.toRadians(p.yBodyRot);
            double fwd = -v.x * Math.sin(yaw) + v.z * Math.cos(yaw);
            target = (float) Mth.clamp(fwd * 260.0, 0.0, 80.0);
        }
        float lean = LEAN.getOrDefault(p.getId(), 0f);
        lean += (target - lean) * 0.08f;
        if (lean < 0.3f && target == 0f) {
            LEAN.remove(p.getId());
            return;
        }
        LEAN.put(p.getId(), lean);

        float a = 180f - Mth.rotLerp(e.getPartialTick(), p.yBodyRotO, p.yBodyRot);
        var ps = e.getPoseStack();
        ps.pushPose();
        PUSHED.add(p.getId());
        ps.translate(0, 0.9, 0);
        ps.mulPose(Axis.YP.rotationDegrees(a));
        ps.mulPose(Axis.XP.rotationDegrees(-lean));
        ps.mulPose(Axis.YP.rotationDegrees(-a));
        ps.translate(0, -0.9, 0);
    }

    @SubscribeEvent
    public static void onPost(RenderLivingEvent.Post<?, ?> e) {
        if (PUSHED.remove(e.getEntity().getId())) e.getPoseStack().popPose();
    }

    /** Fiamme dei repulsori nelle gambe (stivali) mentre si vola. */
    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.isPaused()) return;
        for (Player p : mc.level.players()) {
            if (!flying(p)) continue;
            double lean = Math.toRadians(LEAN.getOrDefault(p.getId(), 0f));
            double yaw = Math.toRadians(p.yBodyRot);
            double fx = -Math.sin(yaw), fz = Math.cos(yaw);
            double dx = -fx * Math.sin(lean), dy = -Math.cos(lean), dz = -fz * Math.sin(lean); // asse delle gambe
            double bx = p.getX() + dx * 0.95, by = p.getY() + 0.9 + dy * 0.95, bz = p.getZ() + dz * 0.95;
            for (int side = -1; side <= 1; side += 2) {
                double x = bx + Math.cos(yaw) * 0.13 * side, z = bz + Math.sin(yaw) * 0.13 * side;
                mc.level.addParticle(ParticleTypes.SOUL_FIRE_FLAME, x, by, z, dx * 0.12, dy * 0.12, dz * 0.12);
                mc.level.addParticle(ParticleTypes.END_ROD, x, by, z, dx * 0.2, dy * 0.2, dz * 0.2);
                if (p.tickCount % 2 == 0) mc.level.addParticle(ParticleTypes.CLOUD, x, by, z, dx * 0.08, dy * 0.08, dz * 0.08);
            }
        }
    }
}
