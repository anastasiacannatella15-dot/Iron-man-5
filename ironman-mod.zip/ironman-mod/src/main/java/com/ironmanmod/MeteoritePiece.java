package com.ironmanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/** Cratere + roccia con cuore di Uru e vene di titanio. Tutto deterministico (hash della posizione): ok tra chunk diversi. */
public class MeteoritePiece extends StructurePiece {
    private static final int R = 8;
    private final int cx, gy, cz;

    public MeteoritePiece(int x, int groundY, int z) {
        super(ModContent.METEORITE_PIECE.get(), 0, new BoundingBox(x - R - 1, groundY - 12, z - R - 1, x + R + 1, groundY + 8, z + R + 1));
        cx = x;
        gy = groundY;
        cz = z;
    }

    public MeteoritePiece(CompoundTag t) {
        super(ModContent.METEORITE_PIECE.get(), t);
        cx = t.getInt("cx");
        gy = t.getInt("gy");
        cz = t.getInt("cz");
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext ctx, CompoundTag t) {
        t.putInt("cx", cx);
        t.putInt("gy", gy);
        t.putInt("cz", cz);
    }

    private static float h(int x, int y, int z, int salt) {
        long v = x * 3129871L ^ z * 116129781L ^ y * 42317861L ^ salt * 0x9E3779B97F4AL;
        v = v * v * 42317861L + v * 11L;
        return ((v >> 16) & 0xFFFF) / 65536f;
    }

    private static void set(WorldGenLevel l, BoundingBox box, BlockPos p, BlockState s) {
        if (box.isInside(p)) l.setBlock(p, s, 2);
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager sm, ChunkGenerator gen, RandomSource rnd,
                            BoundingBox box, ChunkPos cp, BlockPos pivot) {
        BlockState air = Blocks.AIR.defaultBlockState();
        // cratere
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                double d2 = dx * dx + dz * dz;
                if (d2 > R * R) continue;
                int x = cx + dx, z = cz + dz;
                if (x < box.minX() || x > box.maxX() || z < box.minZ() || z > box.maxZ()) continue;
                int depth = (int) Math.round(4.0 * (1.0 - d2 / (R * R)));
                int floor = gy - depth;
                for (int y = gy + 5; y > floor; y--) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (box.isInside(p) && !level.getBlockState(p).isAir()) set(level, box, p, air);
                }
                float f = h(x, floor, z, 1);
                BlockState burnt = f < 0.35f ? Blocks.BLACKSTONE.defaultBlockState()
                        : f < 0.6f ? Blocks.COARSE_DIRT.defaultBlockState()
                        : f < 0.8f ? Blocks.GRAVEL.defaultBlockState()
                        : f < 0.92f ? Blocks.BASALT.defaultBlockState() : Blocks.MAGMA_BLOCK.defaultBlockState();
                set(level, box, new BlockPos(x, floor, z), burnt);
                if (d2 > (R - 2) * (R - 2) && h(x, gy, z, 2) < 0.33f) {
                    BlockPos rim = new BlockPos(x, floor + 1, z);
                    if (box.isInside(rim) && level.getBlockState(rim).isAir()) {
                        set(level, box, rim, (h(x, gy, z, 3) < 0.5f ? Blocks.BLACKSTONE : Blocks.BASALT).defaultBlockState());
                    }
                }
            }
        }
        // roccia mezza sepolta
        int my = gy - 2;
        int rad = 3;
        for (int dx = -rad - 1; dx <= rad + 1; dx++) {
            for (int dy = -rad - 1; dy <= rad + 1; dy++) {
                for (int dz = -rad - 1; dz <= rad + 1; dz++) {
                    int x = cx + dx, y = my + dy, z = cz + dz;
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz) + h(x, y, z, 4) * 0.5;
                    if (d > rad + 0.4) continue;
                    float f = h(x, y, z, 5);
                    BlockState s;
                    int man = Math.abs(dx) + Math.abs(dy) + Math.abs(dz);
                    if (man == 0 || (man == 1 && f > 0.25f) || (man == 2 && f > 0.8f)) {
                        s = ModContent.URU_BLOCK.get().defaultBlockState();
                    } else if (d > 1.5 && h(x, y, z, 6) < 0.17f) {
                        s = ModContent.TITANIUM_ORE.get().defaultBlockState();
                    } else if (d > 2.0) {
                        s = f < 0.5f ? Blocks.BLACKSTONE.defaultBlockState() : f < 0.8f ? Blocks.BASALT.defaultBlockState()
                                : f < 0.92f ? Blocks.MAGMA_BLOCK.defaultBlockState() : Blocks.OBSIDIAN.defaultBlockState();
                    } else {
                        s = f < 0.6f ? Blocks.DEEPSLATE.defaultBlockState() : f < 0.85f ? Blocks.BLACKSTONE.defaultBlockState()
                                : Blocks.CRYING_OBSIDIAN.defaultBlockState();
                    }
                    set(level, box, new BlockPos(x, y, z), s);
                }
            }
        }
    }
}
