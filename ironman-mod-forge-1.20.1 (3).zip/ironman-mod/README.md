# Iron Man 2.4.3 — Mark 42 / Mark 50 / Mark 85

Minecraft **1.20.1** · Forge **47.3.0** · Java **17**

La versione si cambia in `gradle.properties` (`mod_version`): il .jar si chiama `iron-man-<versione>.jar`.

## Come ottenere il .jar

**Metodo consigliato (con il wrapper Gradle ufficiale):**
1. Scarica il "Mdk" di Forge 1.20.1 (47.3.0) da https://files.minecraftforge.net e scompattalo.
2. Copia dentro la sua cartella il mio `src/` e il mio `build.gradle` (sovrascrivi quelli dell'MDK).
3. Apri un terminale nella cartella ed esegui:
   - Windows: `gradlew build`
   - Linux/Mac: `./gradlew build`
4. Il file finito è in `build/libs/iron-man-2.4.3.jar` → mettilo nella cartella `mods` di Minecraft.

**Alternativa:** con JDK 17 e Gradle 8.1.x installati, esegui `gradle build` direttamente in questa cartella.

## Modello 3D
Le armature usano un vero modello 3D (spalline, pettorali, ginocchiere, stivali, casco con mento e orecchie che sporgono dal corpo), senza librerie extra. Texture in `textures/models/armor/markXX_model.png`.

## Come si gioca

**Mark 42 — armatura normale, senza nanotech.** Si craftta pezzo per pezzo (diamanti + oro, stessa forma dell'armatura di diamante)
e si indossa a mano. Con tutti e 4 i pezzi addosso hai volo, repulsori e missili. Ha 20 punti armor, tenacia 2,5 e il 10% di danno in meno:
un po' meglio del diamante.

**Mark 50 e Mark 85 — nanotech.** Servono gli item **Mark 50** / **Mark 85** (hanno l'icona del reattore Arc della tuta),
da **indossare nello slot del petto** oppure in **Curios (slot body)**. Il bottone di trasformazione compare in alto a sinistra solo quando lo indossi.
- Mark 50: diamanti + oro + stella del Nether al centro (`DGD / GRG / DGD`)
- Mark 85: lingotti di netherite + stelle del Nether + blocchi di diamante + Mark 50 al centro (`NSN / DRD / NSN`)
- Trasformazione in stile Infinity War: le nanoparticelle partono dal petto e corrono fino a mani, piedi e testa (0,5 secondi, la tuta compare tutta insieme).

**Tasti** (modificabili in Opzioni → Controlli → Iron Man):

| Tasto | Azione |
|-------|--------|
| **G** | Trasformati / rimuovi l'armatura (0,5 secondi) |
| **R** | Repulsore: braccio destro alzato, raggio giallo di 1,5 s (tienilo premuto per continuare a sparare) |
| **V** | Unibeam dal petto, dura 1,5 s (solo Mark 50 e 85, non la 42) |
| **B** | Micro-missili di fuoco (4 / 6 / 8 bersagli) |

**Volo**: doppio salto per volare. Vai avanti e il corpo si inclina come nei film, con i repulsori accesi nelle gambe. Tieni **Sprint + W** mentre voli per il volo supersonico. L'energia si consuma volando e sparando e si ricarica a terra.

## Protezione e danno

| | Mark 42 | Mark 50 | Mark 85 |
|---|---|---|---|
| Armor (casco/petto/gambali/stivali) | 3/8/6/3 = 20 | 2/6/5/2 = 15 | 3/8/6/3 = 20 |
| Tenacia (per pezzo) | 2,5 | 5 | 6 |
| Resistenza al knockback (totale) | 0 | 2 | 2 |
| Danno subito (extra) | -10% | normale | -75% (circa il doppio della netherite con Protezione IV) |
| Repulsore (fuoco) | 10 | 13 | 16 |
| Unibeam (totale in 1,5 s) | no | 30 | 40 |
| Micro-missili | 4 | 6 | 8 |

I raggi danno fuoco. Nota: in Minecraft diamante e netherite hanno entrambi 20 punti armor,
le differenze tra i modelli vengono quindi da tenacia e riduzione del danno.

## Mjölnir (martello)
Ricetta: 5 lingotti di netherite, 1 stella del Nether, 1 blaze rod (`NNN / NSN / .R.`).
- **Tieni premuto il tasto destro**: il martello gira. **Salta** mentre tieni premuto e voli nella direzione in cui guardi (Sprint per andare piu' veloce). Niente danni da caduta.
- **Maiusc + tasto destro**: lo leghi a te, il tuo nome compare sotto il nome del martello. Solo tu puoi usarlo e sollevarlo.
- **Se lo droppi** resta in piedi a terra. Passandoci sopra non lo prendi: devi fare **tasto destro** sopra di lui.
- **Z** lancia · **X** richiama (torna da solo nel tuo inventario, anche attraverso i blocchi) · **C** fulmine dove guardi · **H** tempesta di fulmini tutto intorno a te.
- Sei immune ai suoi fulmini. Danno in mischia 14, lancio 16, fulmine 14 piu' fuoco.

## Morte
Se muori senza keepInventory, l'armatura nanotech sparisce e droppa la tua armatura originale.

## Uru, meteorite e Matrice del Mjölnir (2.4.3)
- **Meteorite**: ora è una vera struttura (2.4.3): funziona con `/locate structure ironmanmod:meteorite` e con Explorer's Compass. Cratere bruciato con roccia dal cuore di Blocchi di Uru e vene di titanio. Compare solo nei chunk NUOVI.
- **Matrice del Mjölnir** (`mjolnir_cast`): si trova nelle casse del **fabbro (weaponsmith) dei villaggi** (50% di probabilità).
- **Con Tinkers' Construct**: fondi Uru (lingotti/blocchi) nella fonderia, poi versa **3 secchi (3000 mB) di Uru fuso** sul tavolo di colata con la Matrice → ottieni il **Mjölnir**.
- **Senza Tinkers**: ricetta a banco `uru_block ×5 + matrice + blaze rod`.
- Nota: le ricette Tinkers sono scritte a memoria e non testate; se non funzionano mandami il `latest.log`.

## 2.4.3 — Spider, Iron Man (sentinella), FRIDAY/JARVIS
- **Texture armature**: Mark 50, Mark 85 e Iron Man usano le tue skin 64x64 (`textures/models/armor/*_model.png`, layout skin base). Per cambiarle sostituisci i PNG.
- **Armatura "Iron Man"** (ex Mark 42, classica rosso/oro, craft con lingotti di **titanio**): con tutti e 4 i pezzi hai volo/repulsore/missili e **JARVIS**.
- **Sentinella** (tasto J con l'armatura Iron Man completa): l'armatura esce da te, ti segue e spara ai mostri, 50 di vita; se muore droppa i pezzi. **Tasto destro** = si apre la schiena; **cammina verso di lei** e la indossi.
- **FRIDAY** (Mark 50/85) / **JARVIS** (Iron Man): schermata HUD in prima persona. **Shift+V** accende/spegne; **Shift+F** scansione dei mob; tenendo **Shift** i tasti in alto a sinistra si nascondono.
- **Titanio**: Titanio Grezzo si trova nei meteoriti insieme all'Uru (si fonde in lingotti).
- **Trasformazione**: onda + spirale di nanoparticelle dal reattore; in prima persona il braccio scende verso il reattore, in terza persona la mano va al petto.

## 2.4.3
- Corretto il reattore indossato (texture mancante: busto nero/viola) e messe le tue icone per Mark 50 / Mark 85; Mark 85 con la tua versione "mask".
- Seconda mano occupata (offhand o Curios "hands"): l'armatura lascia libero il braccio sinistro.
- Mjölnir: cade subito (gravità normale). Con il Mjölnir in mano: **F** = lancio istantaneo (60 di danno, torna subito nella mano), **Shift+F** = blocca/sblocca (solo tu puoi prenderlo). Senza Mjölnir: Shift+F = scan mob.

## 2.4.3
- Corretto il reattore indossato (texture mancante: busto nero/viola) e messe le tue icone per Mark 50 / Mark 85; Mark 85 con la tua versione "mask".
- Seconda mano occupata (offhand o Curios "hands"): l'armatura lascia libero il braccio sinistro.
- Mjölnir: cade subito (gravità normale). Con il Mjölnir in mano: **F** = lancio istantaneo (60 di danno, torna subito nella mano), **Shift+F** = blocca/sblocca (solo tu puoi prenderlo). Senza Mjölnir: Shift+F = scan mob.

## 2.4.3
- Rimossa la tuta ragno, il Web Shooter e tutto ciò che era collegato.

## 2.4.3
- Le tue nuove immagini sono nei posti giusti: icone Iron Man in `textures/item/mark42_*.png`, texture armature in `textures/models/armor/mark42_model.png`, `mark50_model.png`, `mark85_model.png`.
- **Reattore Arc nello slot petto**: alla trasformazione NON compaiono più elmo/pettorale/ecc.; il reattore resta e disegna l'armatura intera. Protezione del reattore: **Mark 85 = 30 armor, Mark 50 = 27 armor** (si legge sotto il nome). Con il reattore in Curios (body) resta il vecchio sistema a pezzi.

## 2.4.3
- La Mark 50/85 non fa più comparire nessun pezzo (nemmeno il pettorale) né con il reattore nel petto né in Curios: il reattore resta dov'è e l'armatura si vede intera addosso (nuovo layer di rendering). Con il reattore in Curios la protezione (30 / 27) arriva da modificatori e sparisce a tuta ritirata.

## 2.4.3 — Gemme dell'Infinito nel Mjölnir
- Serve "Pugmeowla's Infinity Stone Core" (mod `infinity`). **Shift + tasto destro** con il Mjölnir in mano: una Gemma (mano secondaria o inventario) viene incastonata nel martello (1 per tipo, max 6). Se non hai gemme da inserire e il martello non ha ancora il tuo nome, mette il tuo nome come prima.
- Per togliere l'ultima gemma: Shift + tasto destro con mano secondaria vuota e il martello già con il tuo nome.
- Effetti tenendo il Mjölnir in mano: Power = Forza II (e danno di F ×1,5), Space = Velocità II (e portata di F ×2), Reality = Resistenza II, Time = Fretta II, Soul = Rigenerazione II, Mind = Visione notturna. Le gemme si leggono nel tooltip.

## 2.4.3
- **F** con il Mjölnir in mano: il martello vola davvero verso dove guardi, fa 60 di danno (x1,5 con la gemma Power, velocità maggiore con Space) e appena colpisce un mob (o un blocco, o a fine corsa) torna subito nella tua mano. **Z** resta il lancio normale.

## 2.4.3 — Gemme potenziate
- **Danno di F:** senza gemme 60 (mob) / 8 (giocatori). **Power** da sola 250 / 20; ogni altra gemma aggiunge +20 / +2; con tutte e 6: 350 mob / 30 giocatori (esplosione TNT esclusa).
- **Inserire Power:** costa metà vita (non uccide), particelle viola entro 10 blocchi ed esplosione da 5 TNT (senza rompere i blocchi). Le altre gemme: solo particelle del loro colore.
- **Tutte e 6:** particelle di tutti i colori entro 15 blocchi e metà vita a chiunque entro 15 blocchi (anche chi regge il martello, ma non muore).
- Le pietre inserite si vedono sulla testa del martello (6 colori).

## 2.4.3 — Bilanciamento
- Danno F: senza gemme 20 (mob) / 4 (giocatori); solo Power 70 / 10; ogni altra gemma +6 / +1; tutte e 6 = 100 mob / 15 giocatori.

## 2.4.3
- Danno F: senza gemme 14 (mob e giocatori); solo Power 100 mob / 25 giocatori; solo un'altra gemma 40 / 20; ogni gemma in più +10 / +5; tutte e 6 = 150 mob / 50 giocatori.

## 2.4.3 — Abilità delle gemme
Con il Mjölnir in mano (passive) e quando colpisce (lancio o mischia):
- **Potere:** Forza II + onda d'urto che respinge i mob vicini e lancia in alto il bersaglio.
- **Spazio:** Velocità II + Salto II; il bersaglio viene sbalzato lontano.
- **Realtà:** Resistenza II + resistenza al fuoco; il bersaglio brucia e viene avvelenato (Wither).
- **Tempo:** Fretta II + Velocità; il bersaglio è rallentato fortemente.
- **Anima:** Rigenerazione II + sazietà; chi colpisce si cura del 30% del danno.
- **Mente:** Visione notturna; il bersaglio diventa debole, luminoso e cieco per un attimo.

## 2.4.3 — Collegamento a Palladium
Se Palladium è installato, le gemme inserite nel Mjölnir danno i **poteri veri** della mod Infinity (infinity:power_stone, space_stone, reality_stone, time_stone, soul_stone, mind_stone) finché tieni il martello in mano; li togli lasciandolo. Usa il comando `/superpower add/remove` di Palladium. Senza Palladium restano le abilità semplici della 2.3.0.

## 2.4.3
- Velocità del martello lanciato con F: nessuna gemma 1.0, una gemma 0.8, due o più 0.7, tutte e 6 = 0.5 (moltiplicatore della velocità base).

## 2.4.3
- Lancio F: il numero indica il tempo di volo (più basso = più veloce): 1.0 / 0.8 / 0.7 / 0.5 con 0 / 1 / 2+ / 6 gemme. Velocità = base ÷ fattore.
- Armatura Iron Man (Mk42): maschera chiusa, il viso non si vede più (occhi bianchi luminosi).
